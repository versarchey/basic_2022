from django.conf.urls.defaults import patterns, include
from django.contrib import admin
from django.utils.importlib import import_module
import settings

# Uncomment the next two lines to enable the admin:
admin.autodiscover()

urlpatterns = patterns('',
  (r'^(robots.txt)$', 'django.views.static.serve', { 'document_root': settings.STATIC_DIR }),            
  (r'^(favicon.ico)$', 'django.views.static.serve', { 'document_root': settings.STATIC_DIR }),
  (r'^static/(?P<path>.*)$', 'django.views.static.serve', { 'document_root': settings.STATIC_DIR }),

  (r'^admin/', include(admin.site.urls)),
)

urlpatterns += patterns('',
  (r'^basic/browser/', include('browser.urls')),
  (r'^basic/fserve/', include('fserve.urls')),
)

urlpatterns += patterns('basic.browser.views',
  (r'^$', 'main_default'),
  (r'^basic/main/([A-Za-z0-9_]+?)/$', 'main'),
  
  (r'^basic/services/(.+)/$', 'basic_service_manager'), # service modules
  (r'^basic/sources/(.+)/$', 'basic_source_manager'), # track data modules

  # auth
  (r'^accounts/login/$',  'auth_login'),
  (r'^accounts/logout/$', 'auth_logout'),
)
