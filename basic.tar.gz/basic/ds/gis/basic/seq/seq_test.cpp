#include "seq_access.h"
#include <string>
#include <iostream>
#include "../_mmap/utils.h"

using namespace std;

int main() {
	string path = "Y:/gb/temp";
	//string path = "/home/hoang/gb/temp/";
	try {
		string p1 = pathadd(path, "input.fasta");
		string p2 = pathadd(path, "seq.xml");
		string p3 = pathadd(path, ".");
		build(p1.c_str(), p2.c_str(), p3.c_str());
		SAHandle h = load(p2.c_str());
		char * rstr = substring(h, 1, 40);
		cout << rstr << endl;
		delete[] rstr;
		unload(h);
	}catch(std::exception & e) {
		cout << "Exception: " << e.what() << endl;
		throw;
	}
	return 0;
}
