#include "utils.h"
using namespace std;

std::string pathadd(const std::string& prefix, const std::string& suffix) {
	if (prefix.length() > 0 && prefix[prefix.length() - 1] != '/')
		return prefix + '/' + suffix;
	else
		return prefix + suffix;
}