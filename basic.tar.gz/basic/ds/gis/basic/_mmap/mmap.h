#ifndef _MYMMAP_H_
#define _MYMMAP_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


#ifdef WIN32
#include <windows.h>
#else
#endif

#ifdef WIN32
#endif

typedef struct {
	void * addr;
	size_t len;
#ifdef WIN32
	HANDLE h1,h2;
#else
	int fd;
#endif
} MMAP;

MMAP *mymmap (const char *fname);
MMAP *mymmap_w (const char *fname, uint64_t len);

int mymunmap (MMAP *m);

/*
MMAP *mymmap_anom (size_t len);
void *mymremap(MMAP *m, size_t new_len);
*/



#endif
