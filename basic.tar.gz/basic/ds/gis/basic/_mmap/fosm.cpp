#include "fosm.h"
#include "logger.h"
#include "pugixml.hpp"
#include "utils.h"


DataGroup::DataGroup() { root = this;  }
DataGroup::DataGroup(const std::string& name, const std::string& _gtype, DataGroup* yparent): pname(name), gtype(_gtype), parent(yparent) {
	if (yparent) {
		root = yparent->root;
	}
}

void DataGroup::set_datatype(const std::string& tpname) {
	gtype = tpname;
}
void DataGroup::rename(const std::string& newname) {
	pname = newname;
}

DataGroup::~DataGroup() {}

sptr<DataGroup> DataGroup::new_subgroup(const std::string& name, const std::string& _gtype) {
	sptr<DataGroup> val = sptr<DataGroup>(new DataGroup(name, _gtype, this));
	children.push_back(val);
	return val;
}

void DataGroup::add_file(const std::string& name, const std::string& fullpath, const std::string& type) {
	vars[name] = DataItemDetail::makeFile(fullpath, type);
}

void DataGroup::add_str(const std::string& name, const std::string& value) {
	vars[name] = DataItemDetail::makeStr(value);
}

void DataGroup::add_uint64(const std::string& name, const uint64_t& value) {
	vars[name] = DataItemDetail::makeInt64(value);
}

sptr<DataGroup> DataGroup::get_subgroup(const std::string& name) {
	for (ChildLstTp::iterator it = children.begin(); it != children.end(); ++it) {
		if ((*it)->group_name() == name) 
			return *it;
	}
	return sptr<DataGroup>();
}

uint64_t DataGroup::get_uint64(const std::string& name) {
	VarsLstTp::iterator it = vars.find(name);
	if (it == vars.end()) throw std::runtime_error(("cannot find variable: " + name).c_str());
	if (it->second.type != UINT64_VAR) throw std::runtime_error("wrong type");
	return it->second.intval;
}

std::string DataGroup::get_str(const std::string& name) {
	VarsLstTp::iterator it = vars.find(name);
	if (it == vars.end()) throw std::runtime_error(("cannot find variable: " + name).c_str());
	if (it->second.type != STR_VAR) throw std::runtime_error("wrong type");
	return it->second.value;
}

std::pair<std::string, std::string> DataGroup::get_file(const std::string& name) {
	VarsLstTp::iterator it = vars.find(name);
	if (it == vars.end()) throw std::runtime_error(("cannot find variable: " + name).c_str());
	if (it->second.type != DATA_FILE) throw std::runtime_error("wrong type");
	return make_pair(it->second.value, it->second.ext);
}

void DataGroup::close() {}


using namespace std;
#include <stack>

std::string DataGroup::group_path() {
	stack<string> st;
	DataGroup * pt = this;
	while (pt != NULL) {
		st.push(pt->group_name());
		pt = pt->parent;
	}
	std::ostringstream ss(st.top());
	st.pop();
	while (!st.empty()) 
		ss << '.' << st.top();
	return ss.str();
}

const std::string& DataGroup::group_type() { return gtype; }

UI64ExtBArr DataGroup::new_uint64arr(const std::string& name, const uint64_t& len, int mode) {
	UI64ExtBArr a;
	std::string fullpath = pathadd(root->get_str("$FILE_PATH"), name + '_' + tostr(rand() % 10000));
	a.create(fullpath.c_str(), len, mode);
	vars[name] = DataItemDetail::makeFile(fullpath, "uint64arr");
	return a;
}

UI64ExtBArr DataGroup::open_uint64arr(const std::string& name, int mode) {
	UI64ExtBArr a;
	//std::string fullpath = root.lock()->get_str("$FILE_PATH") + name;
	VarsLstTp::iterator it = vars.find(name);
	if (it == vars.end()) throw std::runtime_error(("cannot find variable: " + name).c_str());
	if (it->second.type != DATA_FILE) throw std::runtime_error("wrong type");
	std::string fullpath = it->second.value;
	a.open(fullpath.c_str(), mode);
	return a;
}

std::string escapeXml(const std::string &sSrc) {
	ostringstream sRet;
	for( string::const_iterator iter = sSrc.begin(); iter!=sSrc.end(); iter++ ) {
		unsigned char c = (unsigned char)*iter;
		switch( c ) {
		case '&': sRet << "&amp;"; break;
		case '<': sRet << "&lt;"; break;
		case '>': sRet << "&gt;"; break;
		case '"': sRet << "&quot;"; break;
		case '\'': sRet << "&apos;"; break;
		default:
			if (c<32 || c>127){
				sRet << "&#" << (unsigned int)c << ";";
			} else {
				sRet << c;
			}
		}
	}
    return sRet.str();
}

void find_replace(string& str, const string& searchString, const string& replaceString) {
	string::size_type pos = 0;
    while ( (pos = str.find(searchString, pos)) != string::npos ) {
        str.replace( pos, searchString.size(), replaceString );
        pos++;
    }
}

std::string unescapeXml(const std::string &sSrc) {
	string ret = sSrc;
	find_replace(ret, "&apos;", "\'");
	find_replace(ret, "&quot;", "\"");
	find_replace(ret, "&gt;", ">");
	find_replace(ret, "&lt;", "<");
	find_replace(ret, "&amp;", "&");
	return ret;
}

void DataGroup::write_properties(const std::string& fname, sptr<DataGroup> gr) {
	std::ofstream fo(fname.c_str());
	if (!fo.good()) throw std::runtime_error(("cannot open file to write: " + fname).c_str());
	write_properties(fo, gr);
	fo.close();
}

void DataGroup::write_properties(std::ostream& fo, sptr<DataGroup> gr) {
	fo << "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" << endl;
	fo << "<root>" << endl;
	write_properties_rec(gr, fo, "");
	fo << "</root>" << endl;
}

void DataGroup::write_properties_rec(sptr<DataGroup> node, std::ostream& fo, const std::string& indent) {
	fo << indent;
	fo << "<group name=\'" << escapeXml(node->group_name()) << '\'';
	fo << " type=\'" << escapeXml(node->group_type()) << '\'';
	fo << ">\n";

	string nindent = indent;
	if (indent.length() < 12) nindent += "  ";	
	for (VarsLstTp::iterator jt = node->vars.begin(); jt != node->vars.end(); ++jt) {
		fo << nindent;
		if (jt->second.type == UINT64_VAR) {
			fo << "<variable key=\'" << jt->first << '\''; 
			fo << " value=\'" << jt->second.intval << '\'';
			fo << " type=\'uint64\'";
			fo << " />" << endl;
		}
		if (jt->second.type == STR_VAR) {
			fo << "<variable key=\'" << jt->first << '\''; 
			fo << " value=\'" << jt->second.value << '\'';
			fo << " type=\'string\'";
			fo << " />" << endl;
		}
		if (jt->second.type == DATA_FILE) {
			fo << "<file name='" << escapeXml(jt->first) << '\'';
			fo << " fullpath='" << escapeXml(jt->second.value) << '\'';
			fo << " filetype='" << escapeXml(jt->second.ext) << '\'';
			fo << " />" << endl;
		}
	}
	for (ChildLstTp::iterator it = node->children.begin(); it != node->children.end(); ++it) {
		write_properties_rec(*it, fo, nindent);
	}
	fo << indent;
	fo << "</group>" << endl;
}

#include <cstring>
using namespace pugi;

void parse(const xml_node& node, sptr<DataGroup> u) {
	u->rename(node.attribute("name").value());
	u->set_datatype(node.attribute("type").value());
	for (xml_node_iterator it = node.begin(); it != node.end(); ++it) {
		if (strcmp(it->name(), "variable") == 0) {
			if (strcmp(it->attribute("type").value(), "uint64") == 0) {
				u->add_uint64(it->attribute("key").value(), strto<uint64_t>(it->attribute("value").value()));
			}else {
				u->add_str(it->attribute("key").value(), it->attribute("value").value());
			}
		}else if (strcmp(it->name(), "file") == 0) {
			u->add_file(it->attribute("name").value(), it->attribute("fullpath").value(), it->attribute("filetype").value());
		} else
		if (strcmp(it->name(), "group") == 0) {
			sptr<DataGroup> v = u->new_subgroup("", "");
			parse(*it, v);
		}else {
			ERRORM(it->name());
			throw std::runtime_error("unknown element");
		}
	}
}

sptr<DataGroup> DataGroup::read_properties(const std::string& fname) {
	ifstream fi(fname.c_str());
	if (!fi.good()) throw runtime_error((string("cannot open file") + fname).c_str());
	sptr<DataGroup> ret = read_properties(fi);
	fi.close();
	return ret;
}

sptr<DataGroup> DataGroup::read_properties(std::istream& fi) {
	xml_document doc;
	xml_parse_result result = doc.load(fi);
	if (!result) {
		std::cout << "XML parsed with errors, attr value: [" << doc.child("node").attribute("attr").value() << "]\n";
		std::cout << "Error description: " << result.description() << "\n";
		std::cout << "Error offset: " << result.offset << " (error at [" << result.offset << "]\n\n";
	}
	if (strcmp(doc.root().name(), "") != 0) {
		std::cerr << "wrong " << doc.root().name();
	}
	sptr<DataGroup> nroot(new DataGroup());
	parse(doc.root().child("root").child("group"), nroot);
	return nroot;
}

