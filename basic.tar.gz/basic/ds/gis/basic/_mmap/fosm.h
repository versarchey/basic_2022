#include <stdint.h>
#include <fstream>
#include <map>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <stdexcept>
#include "extarr.h"

#ifdef __GNUC__
#include <tr1/memory>
#define sptr std::tr1::shared_ptr 
#define wptr std::tr1::weak_ptr
#define ES_this std::tr1::enable_shared_from_this
#else
#include <memory>
#define sptr std::shared_ptr 
#define wptr std::weak_ptr
#define ES_this std::enable_shared_from_this
#endif



class DataGroup: public ES_this<DataGroup> {
public:
	DataGroup();
	DataGroup(const std::string& name, const std::string& gtype, DataGroup* yparent);

	~DataGroup();
	sptr<DataGroup> new_subgroup(const std::string& name, const std::string& gtype);
	sptr<DataGroup> get_subgroup(const std::string& name);
	void add_subgroup(sptr<DataGroup> grp);

	void add_str(const std::string& name, const std::string& value);
	std::string get_str(const std::string& name);

	void add_uint64(const std::string& name, const uint64_t& value);
	uint64_t get_uint64(const std::string& name);

	UI64ExtBArr new_uint64arr(const std::string& name, const uint64_t& len, int mode = 0);
	UI64ExtBArr open_uint64arr(const std::string& name, int mode = 0);

	void add_file(const std::string& name, const std::string& fullpath, const std::string& type);
	std::pair<std::string, std::string> get_file(const std::string& name);

	void close();

	const std::string& group_name() {return pname;}
	std::string group_path();

	static sptr<DataGroup> read_properties(std::istream& fi);
	static sptr<DataGroup> read_properties(const std::string& fname);
	static void write_properties(std::ostream& fo, sptr<DataGroup> gr);
	static void write_properties(const std::string& fname, sptr<DataGroup> gr);

	const std::string& group_type();

	void set_datatype(const std::string& tpname);
	void rename(const std::string& newname);
protected:
	static void write_properties_rec(sptr<DataGroup> node, std::ostream& fo, const std::string& indent);

protected:

	enum DataItemType {UNKNOWN, UINT64_VAR, STR_VAR, DATA_FILE};

	struct DataItemDetail {
		std::string value;
		uint64_t intval;
		std::string ext;
		DataItemType type;

		static DataItemDetail makeStr(const std::string& val) {
			DataItemDetail d;
			d.value = val;
			d.intval = 0;
			d.type = STR_VAR;
			return d;
		}

		static DataItemDetail makeInt64(uint64_t val) {
			DataItemDetail d;
			d.intval = val;
			d.type = UINT64_VAR;
			return d;
		}
		static DataItemDetail makeFile(const std::string& path) {
			DataItemDetail d;
			d.value = path;
			d.type = DATA_FILE;
			return d;
		}
		static DataItemDetail makeFile(const std::string& path, const std::string& type) {
			DataItemDetail d;
			d.value = path;
			d.ext = type;
			d.type = DATA_FILE;
			return d;
		}

		DataItemDetail() {}
		/*DataItemDetail(DataItemDetail&& other): value(std::move(other.value)), intval(std::move(other.intval)),
			ext(std::move(other.ext)),
			type(std::move(other.type)) {}*/
	};
protected:
	DataGroup* parent, *root;
	std::string pname, gtype;

	typedef std::list<sptr<DataGroup> >  ChildLstTp;
	ChildLstTp children;
	typedef std::map<std::string, DataItemDetail> VarsLstTp;
	VarsLstTp vars;
};

