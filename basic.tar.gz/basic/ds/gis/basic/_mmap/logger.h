#pragma once

#ifndef __NULLSTREAM_
 #define __NULLSTREAM_
 
struct nullstream: 
    std::ostream { 
    struct nullbuf: std::streambuf { 
      int overflow(int c) { return traits_type::not_eof(c); } 
    } m_sbuf; 
    nullstream(): std::ios(&m_sbuf), std::ostream(&m_sbuf) {} 
  }; 

 
#endif //__NULLSTREAM_
 

#ifndef __LOGGER_HEADER_
#define __LOGGER_HEADER_

class NonCopyable {
protected:
    NonCopyable() { }
private:
    // copying and assignment is not allowed
    NonCopyable(const NonCopyable &);
    const NonCopyable & operator = (const NonCopyable &);
};
#include <cstdlib>
template <typename InstT, bool destroy_on_exit = true>
class Singleton : private NonCopyable
{
    typedef InstT InstT_type;
    typedef InstT_type * InstT_pointer;
    static InstT_pointer instance;
    static InstT_pointer create_instance();
    static void destroy_instance();
public:
    inline static InstT_pointer get_InstT() {
        if (!instance)
            return create_instance();
        return instance;
    }
};

template <typename InstT, bool destroy_on_exit>
typename Singleton<InstT, destroy_on_exit>::InstT_pointer
Singleton<InstT, destroy_on_exit>::create_instance()
{
    if (!instance) {
        instance = new InstT_type();
        if (destroy_on_exit)
            atexit(destroy_instance);
    }
    return instance;
}
template <typename InstT, bool destroy_on_exit>
void Singleton<InstT, destroy_on_exit>::destroy_instance()
{
    InstT_pointer inst = instance;
    //InstT = NULL;
    instance = reinterpret_cast<InstT_pointer>(-1);
    delete inst;
}
template <typename InstT, bool destroy_on_exit>
InstT * Singleton<InstT, destroy_on_exit>::instance = NULL;

#include <fstream>
#include <sstream>
class Logger : public Singleton<Logger>
{
    friend class Singleton<Logger>;
    std::ofstream _log_stream;
    std::ofstream _errlog_stream;
    inline Logger() : _log_stream("mylog.log"),
        _errlog_stream("mylog.errlog"){ }
public:
    inline std::ofstream & log_stream() {
        return _log_stream;
    }
    inline std::ofstream & errlog_stream() {
        return _errlog_stream;
    }
};
#endif // __LOGGER_HEADER_

#ifndef __LOGGING_MACRO_HEADER_
#define __LOGGING_MACRO_HEADER_

#define ___STRING(x) # x

#define __PRINTLN(label, outstream, log_stream, message) \
    { std::ostringstream str_; \
      str_ << "[" label "] " << message << std::endl; \
      outstream << str_.str() << std::flush; \
      Logger::get_InstT()->log_stream() << str_.str() << std::flush; \
    }
#define __PRINT(label, outstream, log_stream, message) \
    { std::ostringstream str_; \
      str_ << "[" label "] " << message << " " \
      outstream << str_.str() << std::flush; \
      Logger::get_InstT()->log_stream() << str_.str() << std::flush; \
    }


#define _MSG(x) __PRINTLN("MSG", std::cout, log_stream, x)

#define _ERRMSG(x) __PRINTLN("ERRMSG", std::cerr, errlog_stream, x)




//#define _VERBOSE_LEVEL 1

#ifdef _FORCE_VERBOSE_LEVEL
#undef _VERBOSE_LEVEL
#define _VERBOSE_LEVEL _FORCE_VERBOSE_LEVEL
#endif

#ifdef _DEFAULT_VERBOSE_LEVEL
#ifndef _VERBOSE_LEVEL
#define _VERBOSE_LEVEL _DEFAULT_VERBOSE_LEVEL
#endif
#endif

#ifndef _VERBOSE_LEVEL
#define _VERBOSE_LEVEL -1
#endif

// _VERBOSE0 should be used for current debugging activity only,
// and afterwards be replaced by _VERBOSE1 or higher.
// Code that actively uses _VERBOSE0 should never get into a release.

#if _VERBOSE_LEVEL > -1
 #define _VERBOSE0(x) __PRINTLN("VERBOSE0", std::cout, log_stream, x)
 #define DEBUGM(x) __PRINTLN("DEBUG", std::cout, log_stream, x)
#else
 #define _VERBOSE0(x)
 #define DEBUGM(x)
#endif

#if _VERBOSE_LEVEL > 0
 #define _VERBOSE1(x) __PRINTLN("VERBOSE1", std::cout, log_stream, x)
 #define TRACEM(x) __PRINTLN("INFO", std::cout, log_stream, x)
#else
 #define _VERBOSE1(x)
 #define TRACEM(x)
#endif

#define _VERBOSE(x) _VERBOSE1(x)

#if _VERBOSE_LEVEL > 1
 #define _VERBOSE2(x) __PRINTLN("VERBOSE2", std::cout, log_stream, x)
 #define WARNM(x) __PRINTLN("WARNING", std::cout, log_stream, x)
#else
 #define _VERBOSE2(x)
 #define WARNM(x)
#endif

#if _VERBOSE_LEVEL > 2
 #define _VERBOSE3(x) __PRINTLN("VERBOSE3", std::cout, log_stream, x)
 #define ERRORM(x) __PRINTLN("ERROR", std::cout, log_stream, x)
#else
 #define _VERBOSE3(x)
 #define ERRORM(x)
#endif


#endif //__LOGGING_MACRO_HEADER_

////////////////////////////////////////////////////////////////////////////

/*
#ifdef BOOST_MSVC
 #define _PRETTY_FUNCTION_NAME __FUNCTION__
#else
 #define _PRETTY_FUNCTION_NAME __PRETTY_FUNCTION__
#endif

#define _FORMAT_ERROR_MSG(str_, errmsg_) \
    std::ostringstream str_; str_ << "Error in " << errmsg_

#define _THROW(exception_type, location, error_message) \
    { \
        std::ostringstream msg_; \
        msg_ << "Error in " << location << ": " << error_message; \
        throw exception_type(msg_.str()); \
    }

#define _THROW2(exception_type, error_message) \
    _THROW(exception_type, "function " << _PRETTY_FUNCTION_NAME, \
                "Info: " << error_message << " " << strerror(errno))
*/
