#include "pets.h"

struct pets_node {
  uint32_t chroms;
  uint32_t *pointers;
  uint32_t *pets_pointers;
  uint32_t *sp;
  uint32_t *rank;
  FILE *fp;
  FILE *fpets;
};

uint32_t binary_search(uint32_t start[], uint32_t rank[], uint32_t k, uint32_t j)
{
  uint32_t s, t, m;
  
  //printf("Searching position %u inside...\n", j);
  
  //for (s = 0; s < k; s++)
	//printf("%u %u\n", start[s], rank[s]);
  
  // when query the last '1' position
  if (!j)
	return start[k-1] + rank[k-1] - rank[k-2] - 2;
  
  s = 0;
  t = k - 1;
  while (t > s) {
	m = (s + t) / 2;
	//printf("s = %d t = %d m = %d\n", s, t, m);
	if (rank[m] < j) 
	  if (s == m) break;
	  else s = m;
	else if (t == m) break;
	else t = m;
  }
  if (s == t) 
	if (s > 0)
	  return start[s] + j - rank[s-1] - 2;
	else
	  return j - 1;
  else return start[t] + j - rank[s] - 2;
}

uint32_t select1 (struct pets_node *pnode, uint32_t chrom, uint32_t i)
{
  uint32_t j, k, p, addr1, addr2, rbuffer;  
  
  k = 0;
  j = i % PETS_BSIZE;
  i--;
  i /= PETS_BSIZE;
  
  // jump to the corresponding chromesome
  fseek(pnode->fp, pnode->pointers[2 * (chrom - 1)], SEEK_SET);
  //printf("Block no: %u Position: %u\n", i+1, j);
  
  // jump to the biggest leading '1'
  if (fseek(pnode->fp, i * 8, SEEK_CUR))	perror("SEEK ERROR");
  // read the leading '1' position
  if (fread(&k, sizeof(uint32_t), 1, pnode->fp) != 1)	perror("READ ERROR");
  // read binary search range
  if (fread(&addr1, sizeof(uint32_t), 1, pnode->fp) != 1)	perror("READ ERROR");
  if (fread(&addr2, sizeof(uint32_t), 1, pnode->fp) != 1)	perror("READ ERROR");
  if (fread(&addr2, sizeof(uint32_t), 1, pnode->fp) != 1)	perror("READ ERROR");
  
  //printf("First level select at: %u\n", k);
  if (fseek(pnode->fp, pnode->pointers[2 * (chrom - 1) + 1] + addr1, SEEK_SET)) perror("SEEK ERROR");
  addr2 += pnode->pointers[2 * (chrom - 1) + 1];
  
  for (p = 0; ftell(pnode->fp) != addr2; p++) {
	fread(&rbuffer, sizeof(uint32_t), 1, pnode->fp);
	pnode->sp[p] = rbuffer >> 16;
	pnode->rank[p] = rbuffer & 0x0000FFFF;
	//printf("%u %u\n", sp[p], rank[p]);
  }
  
  // need to search inside the block
  if (j != 1)
	// if there are more then one element in the block
	if (p > 1)  k += binary_search(pnode->sp, pnode->rank, p, j);
	// if the whole block is '1'
	else if (j) k += j - 1;
	else k += PETS_BSIZE - 1;
	
  //printf("Result: %u\n", k);
  return k;
}

PyObject *decode_pets(struct pets_node *handler, uint32_t j, uint32_t x, uint32_t maxpets) {
	char c, strand1, strand2;
	uint64_t rbuffer;
	PyObject *result, *o;
	uint32_t counter = 0;

	result = PyList_New(0);
	while (ftell(handler->fpets) < j) {
		if (maxpets > 0 && counter >= maxpets) break; // limit results if maxpets>0

		//printf("Enter decode\n");
		fread(&rbuffer, sizeof(uint64_t), 1, handler->fpets);
		c = rbuffer >> 63 & 1 ? '+' : '-';

		//printf("Direction: %c\n", c);

		if (c == '+') {
			strand1 = rbuffer >> 62 & 1 ? '+' : '-';
			strand2 = rbuffer >> 61 & 1 ? '+' : '-';
			//printf("Head: %u %u %c\n", x, rbuffer & 0xFFFFFFF, hs);
			//printf("Tail: %u %u %c\n\n", rbuffer >> 56 & 0x1F, rbuffer >> 28 & 0xFFFFFFF, ts);
			o = Py_BuildValue("(iiciic)", x, rbuffer
					& 0xFFFFFFF, strand1, rbuffer >> 56 & 0x1F,
					rbuffer >> 28 & 0xFFFFFFF, strand2);
		} else {
			strand1 = rbuffer >> 61 & 1 ? '+' : '-';
			strand2 = rbuffer >> 62 & 1 ? '+' : '-';
			//printf("Head: %u %u %c\n", rbuffer >> 56 & 0x1F, rbuffer >> 28 & 0xFFFFFFF, hs);
			//printf("Tail: %u %u %c\n\n", x, rbuffer & 0xFFFFFFF, ts);
			o = Py_BuildValue("(iiciic)", rbuffer >> 56 & 0x1F,
					rbuffer >> 28 & 0xFFFFFFF, strand1, x,
					rbuffer & 0xFFFFFFF, strand2);
		}
		PyList_Append(result, o);
		counter++;
	}

	//printf("End decode\n");
	return result; // Py_BuildValue("{si}", "hchr", 0);
}

PyObject *decode_pets_single(struct pets_node *handler, uint32_t j, uint32_t x, uint32_t maxpets) {
	char strand;
	uint32_t rbuffer;
	PyObject *result, *o;
	uint32_t counter = 0;

	result = PyList_New(0);
	while (ftell(handler->fpets) < j) {
		if (maxpets > 0 && counter >= maxpets) break; // limit results if maxpets>0

		fread(&rbuffer, sizeof(uint32_t), 1, handler->fpets);
		strand = rbuffer >> 31 & 1 ? '+' : '-';
		o = Py_BuildValue("(iic)", x, rbuffer & 0x7FFFFFFF, strand);
		PyList_Append(result, o);
		counter++;
	}
	return result; // Py_BuildValue("{si}", "hchr", 0);
}

PyObject *pets_query (struct pets_node *handler, uint32_t x, uint32_t y, uint32_t z, uint32_t maxpets)
{
  uint32_t i, j, sy, sz;
  
  sy = select1(handler, x, y);
  sz = select1(handler, x, z);
  //printf("Select(%u %u) = %u\n", x, y, sy);
  //printf("Select(%u %u) = %u\n", x, z, sz);
  
  i = handler->pets_pointers[x-1] + sizeof (uint64_t) * (sy-y);
  j = handler->pets_pointers[x-1] + sizeof (uint64_t) * (sz-z);  
  
  if (fseek(handler->fpets, i, SEEK_SET))
		perror("SEEK ERROR");
	else if (i > j)
		perror("RANGE ERROR");
	else
		return decode_pets(handler, j, x, maxpets);
	return NULL;
}

PyObject *pets_query_single (struct pets_node *handler, uint32_t x, uint32_t y, uint32_t z, uint32_t maxpets)
{
  uint32_t i, j, sy, sz;
  sy = select1(handler, x, y);
  sz = select1(handler, x, z);
  i = handler->pets_pointers[x-1] + sizeof (uint32_t) * (sy-y);
  j = handler->pets_pointers[x-1] + sizeof (uint32_t) * (sz-z);  
  
  if (fseek(handler->fpets, i, SEEK_SET))
		perror("SEEK ERROR");
	else if (i > j)
		perror("RANGE ERROR");
	else
		return decode_pets_single(handler, j, x, maxpets);
	return NULL;
}

struct pets_node *pets_load (const char *ss, const char *pets, uint32_t num)
{
  struct pets_node *pnode;
  pnode = malloc(sizeof(struct pets_node));
  pnode->chroms = num;
  pnode->pointers = malloc(2 * num * sizeof(uint32_t));
  pnode->pets_pointers = malloc(num * sizeof(uint32_t));
  pnode->sp = malloc(PETS_BSIZE * sizeof(uint32_t));
  pnode->rank = malloc(PETS_BSIZE * sizeof(uint32_t));
  pnode->fp = fopen(ss, "rb");
  pnode->fpets = fopen(pets, "rb");
  
  if (pnode->fp == NULL) perror("NULL FILE POINTER ERROR");
  else if (pnode->fpets == NULL) perror("NULL FILE POINTER ERROR");
  else {
	fread(pnode->pointers, sizeof(uint32_t), 2 * num, pnode->fp);
	fread(pnode->pets_pointers, sizeof(uint32_t), num, pnode->fpets);
  }
  
  return pnode;
}

void pets_unload (struct pets_node *pnode)
{
  fclose(pnode->fp);
  fclose(pnode->fpets);
  free(pnode->pointers);
  free(pnode->pets_pointers);
  free(pnode->sp);
  free(pnode->rank);
  free(pnode);
}
