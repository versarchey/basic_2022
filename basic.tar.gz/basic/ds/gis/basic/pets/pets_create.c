#include "pets.h"

struct pet_node {
  uint32_t headpos;
  uint8_t headchr;
  char headstr;
  uint32_t tailpos;
  uint8_t tailchr;
  char tailstr;
  uint8_t count;
  char p;
};
typedef struct pet_node *pets_node;

static
int comphead(const void *p1, const void *p2)
{
  if ( (*(pets_node)p1).headchr == (*(pets_node)p2).headchr )
	return (*(pets_node)p1).headpos - (*(pets_node)p2).headpos;
  else 
	return (*(pets_node)p1).headchr - (*(pets_node)p2).headchr;
}

uint8_t convert(const char *chr, char **chrname, const uint32_t maxchr)
{
  uint8_t i;
  for (i = 0; i < maxchr; i++)
	if (!strcmp(chr, chrname[i])) 
	  return i + 1;
}

uint32_t createbv (const char *output, const uint32_t length, const pets_node pets, const uint8_t chrid, uint32_t startpos)
{
  uint32_t i, j, k, petcount;
  uint8_t wbuffer8;
  FILE *fp;
  fp = fopen(output, "wb");
  
  for (wbuffer8 = 0, i = j = 1, k = startpos, petcount = 0; i <= length; i++) {
	wbuffer8 <<= 1;
	wbuffer8++;
	j++;
	if (j > 8) {
	  j = 1;
	  fwrite(&wbuffer8, sizeof(uint8_t), 1, fp);
	  wbuffer8 = 0;
	}
	while (pets[k].headchr == chrid && pets[k].headpos == i) {
	  if (petcount < 10)  printf("%d ", i);
	  wbuffer8 <<= 1;
	  j++;
	  k++;
	  petcount++;
	  if (j > 8) {
		j = 1;
		fwrite(&wbuffer8, sizeof(uint8_t), 1, fp);
		wbuffer8 = 0;
	  }
	}
  }
  // padding if needed
  if (j > 1) {
	for ( ; j < 9; j++) {
	  wbuffer8 <<= 1;
	  wbuffer8++;
	}
	j = 1;
	fwrite(&wbuffer8, sizeof(uint8_t), 1, fp);
	wbuffer8 = 0;
  }
  printf("\n%6u PETs inserted for chrid %u.\n", petcount, chrid);
  fclose(fp);
  return k;
}

void construct_select1_structure (const char *input, const char *output1, const char *output2)
{
  int i, j, k, cc;
  //int size, max = 0, min = INT_MAX;
  uint8_t rbuffer8;
  uint16_t ipos, sp, rank;
  uint32_t wbuffer, count1;
  FILE *fpbv, *fpda, *fpdp;
  fpbv = fopen(input, "rb");
  fpda = fopen(output1, "wb");
  fpdp = fopen(output2, "wb");
  
  if (fpbv == NULL) {
	printf("Cant open %s\n", input);
	perror("Read ERROR");
	return;
  }
  
  for (i = k = cc = 0, rank = 0, count1 = 0; fread(&rbuffer8, sizeof(uint8_t), 1, fpbv) == 1; i++)
	
	  for (j = 7; j > -1; j--) {
		// increase block size until reach the last '1'
		ipos++;
		
		// encounter a '1' bit
		if ((rbuffer8 >> j) & 1) {
		  ++count1; // increase 1s counter
		  ++rank;
		  
		  // start a new block when encounter the first '1' of the block
		  if (rank == 1) {
			k++; // incease block count
			//printf("Start block %d\n", k);
			ipos = 1;
			sp = 1; // first interval start point
			//rank = 1; // current rank in the block
			cc = 1; // '1's flag
			
			// write leading '1' info
			wbuffer = i * 8 + 8 - j;
			fwrite(&wbuffer, sizeof(uint32_t), 1, fpda);
			wbuffer = ftell(fpdp);
			fwrite(&wbuffer, sizeof(uint32_t), 1, fpda);
		  }
		  
		  // if this is the last '1' in the block
		  else if (rank == PETS_BSIZE) {
			// previous bit is '0'
			if (!cc) {
			  sp = ipos;
			  cc = 1;
			}
			// write the last interval info
			wbuffer = sp;
			wbuffer <<= 16;
			wbuffer += rank;
			fwrite(&wbuffer, sizeof(uint32_t), 1, fpdp);
			sp = rank = 0;
		  }
		  
		  // if it is an inside '1'
		  else {
			if (!cc) {
			  sp = ipos;
			  cc = 1;
			}			
		  }
		}
		
		// encounter an '0' bit
		else {
		  cc = 0;
		  // if previous interval has not been written yet
		  if (sp) {
			wbuffer = sp;
			wbuffer <<= 16;
			wbuffer += rank;
			fwrite(&wbuffer, sizeof(uint32_t), 1, fpdp);
			sp = 0;
		  }
		}
	  }
	  
  printf("Iterations: %d\n", i);
  printf("1s Count: %d\n", count1);
  printf("Total blocks: %d\n", k);
  //printf("Max block size: %d\n", max);
  //printf("Min block size: %d\n", min);
  fclose(fpbv);
  fclose(fpda);
  fclose(fpdp);
}

void construct (char **chrname, uint32_t *chrlen, uint32_t NumOfChrom, const char output[], char *tmpdir)
{
  uint32_t i, rbuffer32;
  uint32_t *pointers;
  uint64_t rbuffer64;
  FILE *fp, *fpsda, *fpsds;
  char sdaname[100], sdsname[100];
  
  pointers = malloc(2 * NumOfChrom * sizeof(uint32_t));  
  fp = fopen(output, "wb");
  fseek(fp, 2 * NumOfChrom * sizeof(uint32_t), SEEK_SET);
  
  for (i = 0; i < NumOfChrom; i++) {

  	sprintf(sdaname, "%s/%s", tmpdir, "sda.dat");
  	sprintf(sdsname, "%s/%s", tmpdir, "sds.dat");
  	construct_select1_structure (chrname[i], sdaname, sdsname);
	
	fpsda = fopen(sdaname, "rb");
	fpsds = fopen(sdsname, "rb");
	
	pointers[2 * i] = ftell(fp);	
	while (fread(&rbuffer64, sizeof(uint64_t), 1, fpsda) == 1)
	  fwrite(&rbuffer64, sizeof(uint64_t), 1, fp);
	
	pointers[2 * i + 1] = ftell(fp);
	while (fread(&rbuffer32, sizeof(uint32_t), 1, fpsds) == 1)
	  fwrite(&rbuffer32, sizeof(uint32_t), 1, fp);
	
	fclose(fpsda);
	fclose(fpsds);
	remove(chrname[i]);
  }
  
  fseek(fp, 0, SEEK_SET);
  fwrite(pointers, sizeof(uint32_t), 2 * NumOfChrom, fp);
  fclose(fp);
  remove("sda.dat");
  remove("sds.dat");
  printf("Written succeed\n");
}

int pets_create(char* inputfile, char* pets_out, char* select_out, char* chromfile, uint32_t maxpets, char* tmpdir)
{
  char rbuffer[200];
  char **chrname;
  
  uint32_t i, j, k;
  uint32_t NumOfChrom;
  
  uint32_t *chrlen;
  uint32_t *pets_count;
  uint32_t *pets_pointers;
  
  uint64_t wbuffer64;
  uint32_t hp, tp, ct;
  char hc[10], tc[10];
  char hs[2], ts[2];
  char c;
  char tmp[100];
  pets_node pets;
  FILE *fp, *finput;
  
  fp = fopen(chromfile, "r");
  //fscanf(fp, "%u %u", &NumOfChrom, &MaxNumOfPETs);
  for (NumOfChrom = 0; fgets(rbuffer, 200, fp) != NULL; NumOfChrom++);
  fseek(fp, 0, SEEK_SET);
  chrlen = malloc(NumOfChrom * sizeof(uint32_t));
  chrname = malloc(NumOfChrom * sizeof(char *));
  for (i = 0; i < NumOfChrom; i++) {
	chrname[i] = malloc(100 * sizeof(char));
	fscanf(fp, "%s %u", chrname[i], &chrlen[i]);
  }
  fclose(fp);
  
  pets = malloc(2 * maxpets * sizeof(struct pet_node));
  pets_count = malloc(NumOfChrom * sizeof(uint32_t));
  pets_pointers = malloc(NumOfChrom * sizeof(uint32_t));
  for (i = 0; i < NumOfChrom; i++) pets_count[i] = 0;
  
  if (pets == NULL) {
	perror("Cant allocate enough memory");
	return 1;
  }
  
  finput = fopen(inputfile, "r");
  for (i = 0; fscanf(finput, "%s%u%s %s%u%s", hc, &hp, hs, tc, &tp, ts) != EOF; i++) {
	pets[i].headchr = convert(hc, chrname, NumOfChrom);
	pets[i].tailchr = convert(tc, chrname, NumOfChrom);
	pets[i].headpos = hp;
	pets[i].tailpos = tp;
	pets[i].headstr = hs[0];
	pets[i].tailstr = ts[0];
	pets[i].p = '+';
	pets_count[pets[i].headchr-1]++;
	i++;
	pets[i].headchr = convert(tc, chrname, NumOfChrom);
	pets[i].tailchr = convert(hc, chrname, NumOfChrom);
	pets[i].headpos = tp;
	pets[i].tailpos = hp;
	pets[i].headstr = ts[0];
	pets[i].tailstr = hs[0];
	pets[i].p = '-';
	pets_count[pets[i].headchr-1]++;
	//printf("%s\t%u\t%s\t%s\t%u\t%s\n", hc, hp, hs, tc, tp, ts);
  }
  
  fclose(finput);
  qsort(pets, i, sizeof(pets[0]), comphead);
  printf("%d pets sorted\n", i);
  
  pets_pointers[0] = NumOfChrom * sizeof(uint32_t);
  printf("%s:%u\n", chrname[0], pets_count[0]);
  for (k = 1; k < NumOfChrom; k++) {
	pets_pointers[k] = pets_pointers[k-1] + pets_count[k-1] * sizeof(uint64_t);
	printf("%s:%u\n", chrname[k], pets_count[k]);
  }
  
  fp = fopen(pets_out, "wb");
  fwrite(pets_pointers, sizeof(uint32_t), NumOfChrom, fp);
  for (j = 0; j < i; j++) {
	wbuffer64 = 0;
	if (pets[j].p == '+') wbuffer64++;
	wbuffer64 <<= 1;
	if (pets[j].headstr == '+') wbuffer64++;
	wbuffer64 <<= 1;
	if (pets[j].tailstr == '+') wbuffer64++;
	wbuffer64 <<= 5;
	wbuffer64 += pets[j].tailchr;
	wbuffer64 <<= 28;
	wbuffer64 += pets[j].tailpos & 0xFFFFFFF;
	wbuffer64 <<= 28;
	wbuffer64 += pets[j].headpos & 0xFFFFFFF;
	fwrite(&wbuffer64, sizeof(uint64_t), 1, fp);
	
	/*k = pets[j].count;
	if (k > 16) k = 15;
	else if (k > 0) k--;
	k <<= 4;
	k += pets[j].tailpos & 0xFFFFFFF;
	fwrite(&k, sizeof(uint32_t), 1, fp);*/
  }
  fclose(fp);
  
  for (i = j = k = 0; i < NumOfChrom; i++) {
  	sprintf(tmp, "%s/%s.tmp", tmpdir, chrname[i]);
  	j = createbv(tmp, chrlen[i], pets, i + 1, j);
  }
  printf("Total %u PETs inserted.\n", j);

  for (i = 0; i < NumOfChrom; i++) {
  	// add directory name
  	strncpy(tmp, chrname[i], 20);
  	sprintf(chrname[i], "%s/%s.tmp", tmpdir, tmp);
  }
  construct(chrname, chrlen, NumOfChrom, select_out, tmpdir);
   
  free(pets);
  return 0;
}

int pets_create_single(char* inputfile, char* pets_out, char* select_out, char* chromfile, uint32_t maxpets, char* tmpdir)
{
  char rbuffer[200];
  char **chrname;
  
  uint32_t i, j, k;
  uint32_t NumOfChrom;
  
  uint32_t *chrlen;
  uint32_t *pets_count;
  uint32_t *pets_pointers;
  
  uint64_t wbuffer64;
  uint32_t wbuffer32;
  uint32_t hp, tp, ct;
  char hc[10], tc[10];
  char hs[2], ts[2];
  char c;
  char tmp[100];
  pets_node pets;
  FILE *fp, *finput;
  
  fp = fopen(chromfile, "r");
  //fscanf(fp, "%u %u", &NumOfChrom, &MaxNumOfPETs);
  for (NumOfChrom = 0; fgets(rbuffer, 200, fp) != NULL; NumOfChrom++);
  fseek(fp, 0, SEEK_SET);
  chrlen = malloc(NumOfChrom * sizeof(uint32_t));
  chrname = malloc(NumOfChrom * sizeof(char *));
  for (i = 0; i < NumOfChrom; i++) {
	chrname[i] = malloc(100 * sizeof(char));
	fscanf(fp, "%s %u", chrname[i], &chrlen[i]);
  }
  fclose(fp);
  
  pets = malloc(2 * maxpets * sizeof(struct pet_node));
  pets_count = malloc(NumOfChrom * sizeof(uint32_t));
  pets_pointers = malloc(NumOfChrom * sizeof(uint32_t));
  for (i = 0; i < NumOfChrom; i++) pets_count[i] = 0;
  
  if (pets == NULL) {
	perror("Cant allocate enough memory");
	return 1;
  }
  
  finput = fopen(inputfile, "r");
  for (i = 0; fscanf(finput, "%s%u%s", hc, &hp, hs) != EOF; i++) {
	pets[i].headchr = convert(hc, chrname, NumOfChrom);
	pets[i].headpos = hp;
	pets[i].headstr = hs[0];
	pets_count[pets[i].headchr-1]++;
  }
  
  fclose(finput);
  qsort(pets, i, sizeof(pets[0]), comphead);
  printf("%d tags sorted\n", i);
  
  pets_pointers[0] = NumOfChrom * sizeof(uint32_t);
  printf("%s:%u\n", chrname[0], pets_count[0]);
  for (k = 1; k < NumOfChrom; k++) {
	pets_pointers[k] = pets_pointers[k-1] + pets_count[k-1] * sizeof(uint64_t);
	printf("%s:%u\n", chrname[k], pets_count[k]);
  }
  
  fp = fopen(pets_out, "wb");
  fwrite(pets_pointers, sizeof(uint32_t), NumOfChrom, fp);
  for (j = 0; j < i; j++) {
	wbuffer32 = 0;
	if (pets[j].headstr == '+') wbuffer32++;
	wbuffer32 <<= 31;
	wbuffer32 += pets[j].headpos & 0x7FFFFFFF;
	fwrite(&wbuffer32, sizeof(uint32_t), 1, fp);
  }
  fclose(fp);
  
  for (i = j = k = 0; i < NumOfChrom; i++) {
  	sprintf(tmp, "%s/%s.tmp", tmpdir, chrname[i]);
  	j = createbv(tmp, chrlen[i], pets, i + 1, j);
  }
  printf("Total %u PETs inserted.\n", j);

  for (i = 0; i < NumOfChrom; i++) {
  	// add directory name
  	strncpy(tmp, chrname[i], 20);
  	sprintf(chrname[i], "%s/%s.tmp", tmpdir, tmp);
  }
  construct(chrname, chrlen, NumOfChrom, select_out, tmpdir);
   
  free(pets);
  return 0;
}
