#ifndef SUCCINCT_H
#define SUCCINCT_H

#include<limits.h>
#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<string.h>
#include<Python.h>

#define PETS_BSIZE 1000

struct pets_node;

int pets_create(char* inputfile, char* pets_out, char* select_out, char* chromfile, uint32_t maxpets, char *tmpdir);
int pets_create_single(char* inputfile, char* pets_out, char* select_out, char* chromfile, uint32_t maxpets, char* tmpdir);
struct pets_node *pets_load (const char *ss, const char *pets, uint32_t num);
PyObject *pets_query (struct pets_node *handler, uint32_t x, uint32_t y, uint32_t z, uint32_t maxpets);
PyObject *pets_query_single (struct pets_node *handler, uint32_t x, uint32_t y, uint32_t z, uint32_t maxpets);
void pets_unload (struct pets_node *pnode);

// cc -c -fpic pets_create.c pets_query.c pets_wrap.c -I /usr/include/python2.6/
// ld -shared pets_create.o pets_query.o pets_wrap.o -o _pets.so
// pets.pets_create_single("pets.in","pets.out","pets.select","hg19.txt",2000000,"/home/jianxing/idea-mods")
// p = pets.pets_load("pets.select","pets.out",25)
// pets.pets_query_single(p,1,1,20000,0)
#endif
