#ifndef RMQ_H
#define RMQ_H

#include<limits.h>
#include<math.h>
#include<stdbool.h>
#include<stddef.h>
#include<stdint.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#define RMQ_BSIZE 256

typedef struct rmq_node *rmq_track;
struct rmq_node {
	int16_t **block_table;
	int16_t **bucket_table;
	uint8_t *compacted_bucket_size;
	uint8_t bucket_index[RMQ_BSIZE];
	int16_t bucket_value[RMQ_BSIZE];
	long *bucket_address;
	FILE *fp;
	unsigned int N, K; // total elements and buckets
	unsigned int L, logL; // number of buckets in a block
	unsigned int M, logM; // number of blocks
	long bucket_tables_start_addr;
	long bucket_contents_start_addr;
};

void      rmq_build (char outfile[], char filename[], int numOfElements);
int       rmq_query (rmq_track t, unsigned int p, unsigned int q);
rmq_track rmq_load (char filename[]);
void      rmq_unload (rmq_track t);
int       rmq_query2 (rmq_track t, unsigned int p, unsigned int q);

#endif
