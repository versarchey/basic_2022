#include<assert.h>
#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#define MAX_GROUPS 1048576
#define MAX_SEGMENTS_PER_GROUP 4
#define MAX_BITS_PER_SEGMENT 64
typedef struct node *CIF_Struct;

CIF_Struct init (char *input);
void unload (CIF_Struct s);
unsigned int countif (CIF_Struct s, unsigned int i, unsigned int j, unsigned int q);
void build (char *infile, char *tmpdir, char *outfile, unsigned int length);
