#include "avg.h"

unsigned int floorLog2 (unsigned int n) {
	unsigned int pos = 0;
	
	if (n == 0) return pos;
	if (n >= 1<<16) { n >>= 16; pos += 16; }
	if (n >= 1<< 8) { n >>=  8; pos +=  8; }
	if (n >= 1<< 4) { n >>=  4; pos +=  4; }
	if (n >= 1<< 2) { n >>=  2; pos +=  2; }
	if (n >= 1<< 1) {           pos +=  1; }
	
	return pos;
}

// encode segment summary info into byte-aligned codes
uint8_t *byte_aligned_encoding (unsigned int S_count[][2], unsigned int *bytes_needed)
{
	unsigned int i, j, k, byte_count;
	uint8_t *G;
	
	// calculate total bytes needed
	for (byte_count = i = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		for (j = 0; j < 2; j++)
			if (S_count[i][j] > 0)
				byte_count += floorLog2(S_count[i][j]) / 7 + 1;
			else byte_count += 1;
	G = malloc(byte_count * sizeof(uint8_t));
	
	// encoding
	for (i = j = k = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		for (j = 0; j < 2; j++)
			if (S_count[i][j] > 0)
				for ( ; S_count[i][j] > 0; k++) {
					G[k] = S_count[i][j] & 0x7F;
					G[k] <<= 1;
					S_count[i][j] >>= 7;
					if (S_count[i][j] > 0)  G[k]++;
				}					
			else G[k++] = 0;
	
	assert(k == byte_count);
	*bytes_needed += byte_count;
	return G;
}

// build the RS structure for a set of bit vectors
void build_rs_structure (char *input, FILE *output, unsigned int first_bit)
{
	unsigned int current_bit, current_segment, S_start_bit, S_ended, G_ended;
	unsigned int bit_countS[MAX_SEGMENTS_PER_GROUP][2], bit_countG[2];
	unsigned int *A[3], RLV, RLV_Sum;
	unsigned int S_bit_count, bits_needed, G_bytes_count;
	unsigned int S_count, G_count, RLV_count, i, j;
	uint8_t **G;
	uint64_t *S;
	FILE *fp;
	
	fp = fopen(input, "r");
	assert(fp != NULL);
	
	// memory allocation
	S = malloc(MAX_GROUPS * MAX_SEGMENTS_PER_GROUP * sizeof(uint64_t));
	if (S == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY FOR S ARRAY");
		exit(EXIT_FAILURE);
	}
	
	G = malloc(MAX_GROUPS * sizeof(uint8_t *));
	if (G == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY FOR G ARRAY");
		exit(EXIT_FAILURE);
	}
	for (i = 0; i < MAX_GROUPS; i++) G[i] = NULL;
	
	for (i = 0; i < 3; i++) {
		A[i] = malloc(MAX_GROUPS * sizeof(unsigned int));
		if (A[i] == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR A ARRAY");
			exit(EXIT_FAILURE);
		}
		for (j = 0; j < MAX_GROUPS; j++) A[i][j] = 0;
	}
	
	assert(first_bit < 2);
	printf("Start RLV Encoding...\n");
	
	// initialize
	current_segment = S_count = G_count = RLV_count = 0;
	S_bit_count = G_bytes_count = S_ended = G_ended = RLV = RLV_Sum = 0;
	bit_countG[0] = bit_countG[1] = 0;
	
	for (i = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		bit_countS[i][0] = bit_countS[i][1] = 0;
	
	// read only one run-length value each time
	for (S_start_bit = current_bit = first_bit; fscanf(fp, "%u", &RLV) != EOF; ) {
		assert(RLV); // run-length value cant be 0
						
		// dealing with S array
		RLV++; // avoid encode 1
		bits_needed = 1 + 2 * floorLog2(RLV);
		// if the run length value can be put into the S array
		if (S_bit_count + bits_needed < MAX_BITS_PER_SEGMENT) {
			S[S_count] <<= bits_needed;
			S[S_count] |= RLV; // put the gamma code into it
			S_bit_count += bits_needed;
			
		// start a new S array
		} else {
			 // padding if necessary
			for ( ; S_bit_count < MAX_BITS_PER_SEGMENT; S_bit_count++) {
				S[S_count] <<= 1;
				S[S_count]++;
			}
			if (!S_start_bit) S[S_count]--; // indicate what is the start bit in this segment
			
			S[++S_count] = RLV; // start a new S array
			S_start_bit = current_bit;
			S_bit_count = bits_needed;
			S_ended = 1; // indicate that we have started a new S array;
		}
		RLV--; // restore original RLV
		
		// dealing with G array
		// when the S array is not full yet
		if (!S_ended) bit_countS[current_segment][current_bit] += RLV;
		else {
			// S ended, can encode segment summary info
			
			// reach G's maximum segments
			if (++current_segment == MAX_SEGMENTS_PER_GROUP) {
				G[G_count] = byte_aligned_encoding(bit_countS, &G_bytes_count);
				current_segment = 0;
				G_ended = 1;
			}
			// start new S bit counting
			bit_countS[current_segment][current_bit] = RLV;
			bit_countS[current_segment][1 - current_bit] = 0;		
		}
		
		// dealing with A array
		if (!G_ended) bit_countG[current_bit] += RLV;
		else {
			A[0][G_count] = bit_countG[0];
			A[1][G_count] = bit_countG[1];
			A[2][G_count] = G_bytes_count;
			bit_countG[current_bit] += RLV;
			if (++G_count == MAX_GROUPS) {
				perror("NUMBER OF GROUPS REACHES THE MAXIMUM");
				exit(EXIT_FAILURE);
			}
		}
		
		// update
		RLV_count++;
		RLV_Sum += RLV;
		current_bit = 1 - current_bit;
		S_ended = G_ended = 0;
	}
	
	// dealing with the last S
	for (; S_bit_count < MAX_BITS_PER_SEGMENT; S_bit_count++, S[S_count]++) S[S_count] <<= 1; // padding
	if (!S_start_bit) S[S_count]--; // indicate the start bit
	S_count++;
	
	// dealing with the last G and A	
	while (++current_segment < MAX_SEGMENTS_PER_GROUP)
		bit_countS[current_segment][0] = bit_countS[current_segment][1] = 0;
		
	G[G_count] = byte_aligned_encoding(bit_countS, &G_bytes_count);
	A[0][G_count] = bit_countG[0];
	A[1][G_count] = bit_countG[1];
	A[2][G_count] = G_bytes_count;
	G_count++;
	
	printf("Encode Finished.\n");
	printf("Number of RLVs: %u\n", RLV_count);
	printf("Total Bits: %u (%u + %u)\n", RLV_Sum, bit_countG[0], bit_countG[1]);
	printf("Number of Segments: %u\n", S_count);
	printf("Number of Groups: %u\n", G_count);
	printf("Total bytes for G stream: %u\n", G_bytes_count);
	fclose(fp);
	
	printf("Start Writing Data to File....\n");
	// meta-data
	fwrite(&S_count, sizeof(unsigned int), 1, output);
	fwrite(&G_count, sizeof(unsigned int), 1, output);
	fwrite(&G_bytes_count, sizeof(unsigned int), 1, output);
	
	// S array
	fwrite(S, sizeof(uint64_t), S_count, output); free(S);
	
	// A arrays
	for (i = 0; i < 3; i++)
		fwrite(A[i], sizeof(unsigned int), G_count, output);
	free(A[0]);	free(A[1]);
	
	// G stream
	fwrite(G[0], sizeof(uint8_t), A[2][0], output); free(G[0]);
	for (i = 1; i < G_count; i++) {
		fwrite(G[i], sizeof(uint8_t), A[2][i] - A[2][i-1], output);
		free(G[i]);
	} free(A[2]); free(G);

	printf("Written Completed.\n");
}

void build(char *infofile, char *infile, char *tmpdir, char *outfile)
{
	char chromsname[100][100], chr[100], bv_path[1000];
	unsigned int chromslength[100], pos, num, NumOfChroms;
	unsigned int i, j, ct, file_ended, start_bit, fpointers[100];
	unsigned int *RS_pointer;
	FILE *infp, *outfp, *rsfp;
	
	// read the chromosomes info
	infp = fopen(infofile, "r");
	if (infp == NULL) {
		perror("ERROR");
		exit(EXIT_FAILURE);
	}
	for (NumOfChroms = 0; fscanf(infp, "%s%u", chr, &chromslength[NumOfChroms]) != EOF; NumOfChroms++)
		strcpy(chromsname[NumOfChroms], chr);
	printf("There are %u chromosomes.\n", NumOfChroms);
	
	infp = freopen(infile, "r", infp);
	assert(infp != NULL);
	
	// RS structure
	RS_pointer = malloc(NumOfChroms * sizeof(uint32_t));  
	rsfp = fopen(outfile, "wb");
	assert(rsfp != NULL);
	fseek(rsfp, (NumOfChroms + 1) * sizeof(uint32_t), SEEK_SET);
	
	for (file_ended = i = 0; i < NumOfChroms; i++) {
		// create bit-vector files
		sprintf(bv_path, "%s/%s.txt", tmpdir, chromsname[i]);
		outfp = fopen(bv_path, "w");
		if (outfp == NULL) {
			perror("ERROR");
			exit(EXIT_FAILURE);
		}
		
		// handle remaining data from previous chromosome
		if (ct && !strcmp(chr, chromsname[i])) {
			if (pos > 1) {
				fprintf(outfp, "%u\n%u\n", pos - 1, num);
				start_bit = 1;
			} else {
				fprintf(outfp, "%u\n", num);
				start_bit = 0;
			}
			j = pos + 1;
		} else  j = start_bit = 1;
		
		for (ct = 0; j <= chromslength[i]; j = pos + 1)
			if (!file_ended && fscanf(infp, "%s\t%u\t%u", chr, &pos, &num) != EOF)
				// this number belongs to current chromosome
				if (!strcmp(chr, chromsname[i]))
					if (j > pos) {
						perror("INPUT RANGE ERROR");
						exit(EXIT_FAILURE);
					// the gap between balls and number of balls
					} else if(pos > 1)
						if (j > 1)  fprintf(outfp, "%u\n%u\n", pos - j + 1, num);
						else  fprintf(outfp, "%u\n%u\n", pos - j, num);
					else {
						fprintf(outfp, "%u\n", num);
						start_bit = 0;
					}
				
				// have read the first number for next chromosome
				else {
					if (j > 1)  fprintf(outfp, "%u\n", chromslength[i] - j + 2); // pad the rest part
					else  fprintf(outfp, "%u\n", chromslength[i] - j + 1);
					ct = 1; // tell next chromosome its first value has been read
					break;
				}
			// reach the end of file, do padding
			else {
				if (j > 1)  fprintf(outfp, "%u\n", chromslength[i] - j + 2);
				else  fprintf(outfp, "%u\n", chromslength[i] - j + 1);
				file_ended = 1;
				break;
			}
		printf("%s Start bit: %u\n", chromsname[i], start_bit);
		fclose(outfp);
		// build the RS support structure
		RS_pointer[i] = ftell(rsfp);
		build_rs_structure (bv_path, rsfp, start_bit);
		remove(bv_path);
		printf("\n");
	}
	
	fseek(rsfp, 0, SEEK_SET);
	fwrite(&NumOfChroms, sizeof(uint32_t), 1, rsfp);
	fwrite(RS_pointer, sizeof(uint32_t), NumOfChroms, rsfp);
	fclose(rsfp);
	free(RS_pointer);
	printf("Construction Finished.\n");
}
