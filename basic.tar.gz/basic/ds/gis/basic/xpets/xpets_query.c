#include "xpets.h"

struct rs_node {
	FILE *fp;
	uint8_t *StreamG;
	uint64_t *StreamS;
	uint32_t *A[3];
	uint32_t bits_count[3];
	uint32_t S_size;
	uint32_t GA_size;
	uint32_t G_bytes;
	uint32_t S_base_pointer;
};
typedef struct rs_node *RS_Struct;

struct pets_node {
	uint32_t NumOfChrom;
	uint32_t NumOfPETS;
	uint32_t PETWidth;
	uint32_t ChromWidth;
	uint32_t *tag_count;
	uint32_t **pet_index;
	uint32_t pets_base_pointer;
	uint32_t *pets_base_pointers;
	FILE *fp_select;
	FILE *fp_petslib;
	RS_Struct *RSDS;
};

// search on the partial sum
unsigned int binary_search_A (unsigned int Q, unsigned int A[], unsigned int startpos, unsigned int endpos)
{
	unsigned int i = startpos, j = endpos, k;
	while (i < j)
		if (A[k = (i + j) / 2] > Q) j = k;
		else if (i == k) 
			if (A[i] == Q) return i;
			else return i + 1;
		else i = k;
	return i;	
}

unsigned int gamma_decode_select (uint64_t S, unsigned int bit, unsigned int inpos)
{
	unsigned int start_bit = S & 1, current_bit;
	unsigned int i, bits, bit_count[2];
	
	for (current_bit = start_bit, bit_count[0] = bit_count[1] = 0; ; current_bit = 1 - current_bit) {
		for (i = 63, bits = 0; i > 0; i--)
			if (!S) {
				perror("Out of S range");
				return 0;
			} else if (!(S >> i))
				bits++;
			else if (i == 63) {
				perror("Out of S range");
				return 0;
			} else {
				bit_count[current_bit] += (S >> 64 - 2 * bits - 1) - 1; // remember RLV is always bigger than 1
				S <<= 2 * bits + 1;
				break;
			}
		
		if (bit_count[bit] < inpos) continue;
		else {
			assert(current_bit == bit);
			return inpos + bit_count[1 - current_bit];
		}	
	}
}

unsigned int byte_aligned_decode (uint8_t *buffer, unsigned int *pos)
{
	unsigned int i, j, tmp, result;
	
	// decode the data from MSB to LSB
	i = result = 0; j = *pos;
	do {
		tmp = buffer[j] >> 1;
		result |= tmp << 7 * i++;
	} while (buffer[j++] & 1);
	*pos = j;
	return result;
}

uint32_t select1 (RS_Struct s, uint32_t pos)
{
	unsigned int i, j, block, bit = 1;
	unsigned int inpos, S_bit_count[2], S_accumalated_bits[2], result;
	uint64_t S;
	
	if (pos > s->bits_count[bit]) {
		perror("MAXIMUM BITS EXCEEDED");
		return 0;
	} else block = binary_search_A(pos, s->A[bit], 0, s->GA_size - 1);
	
	// if the position is in the first block
	if (!block) {
		inpos = pos;
		result = 0;
		j = 0;
	} else {
		inpos = pos - s->A[bit][block-1];
		result = s->A[0][block-1] + s->A[1][block-1];
		j = s->A[2][block-1];
	}

	S_bit_count[0] = S_bit_count[1] = 0;
	S_accumalated_bits[0] = S_accumalated_bits[1] = 0;
	
	// search within the block
	for (i = 0; S_bit_count[bit] + S_accumalated_bits[bit] < inpos; i++) {
		S_accumalated_bits[0] += S_bit_count[0];
		S_accumalated_bits[1] += S_bit_count[1];
		
		// assume stream G has been loaded into memory
		S_bit_count[0] = byte_aligned_decode(s->StreamG, &j);
		S_bit_count[1] = byte_aligned_decode(s->StreamG, &j);		
	}	
	if (i > MAX_SEGMENTS_PER_GROUP) {
		perror("Out of G range");
		return 0;
	}
	
	// not in the first S array
	if (i > 1) {
		inpos -= S_accumalated_bits[bit];
		result += S_accumalated_bits[0] + S_accumalated_bits[1];
	}
	
	// when stream S is in memory
	if (s->StreamS != NULL)
		S = s->StreamS[MAX_SEGMENTS_PER_GROUP * block + i - 1];		
	else {
		fseek(s->fp, s->S_base_pointer + MAX_SEGMENTS_PER_GROUP * block * sizeof(uint64_t) + (i-1) * sizeof(uint64_t), SEEK_SET);
		fread(&S, sizeof(uint64_t), 1, s->fp);
	}
	
	return result + gamma_decode_select(S, bit, inpos);
}

PyObject *pets_query (PET_Struct handler, uint32_t chr, uint32_t posx, uint32_t posy, uint32_t maxpets)
{
	char strand[2];
	uint32_t chrom[2];
	uint32_t i, pet_count, buffer32, tagx, tagy, petid, startpet, pos[2];
	PyObject *result;
	
	if (posx > posy || !posx || !posy || !chr || chr > handler->NumOfChrom) {
		perror("INPUT RANGE ERROR");
		return NULL;
	}
	
	// deal with start tag
	if (posx == 1) tagx = 0;
	else {
		tagx = select1(handler->RSDS[chr-1], posx);
		if (!tagx) return NULL; // out of range
		tagx -= posx;	
	}
	
	// ending tag(exclusive)
	tagy = select1(handler->RSDS[chr-1], posy + 1);
	if (!tagy) return NULL; // out of range
	else tagy -= posy + 1;
	
	pet_count = 0;
	result = PyList_New(0);	
	for (i = tagx; i < tagy; i++) {
		if (maxpets > 0 && pet_count > maxpets) break;
		petid = handler->pet_index[chr-1][i];
		startpet = petid & 1; // test if it is a starting tag or ending tag
		petid >>= 1;
		
		chrom[0] = 0;
		fseek(handler->fp_petslib, handler->pets_base_pointer + petid * handler->PETWidth, SEEK_SET);
		fread(&buffer32, sizeof(uint32_t), 1, handler->fp_petslib);
		fread(&chrom[0], handler->ChromWidth, 1, handler->fp_petslib);
		
		strand[0] = buffer32 & 1 ? '+' : '-';
		pos[0] = buffer32 >> 1;
		
		// dont return a PET that has appeared before
		if (!startpet && chrom[0] == chr && pos[0] >= posx && pos[0] <= posy) continue;
		else pet_count++;
		
		chrom[1] = 0;
		fread(&buffer32, sizeof(uint32_t), 1, handler->fp_petslib);
		fread(&chrom[1], handler->ChromWidth, 1, handler->fp_petslib);
		strand[1] = buffer32 & 1 ? '+' : '-';
		pos[1] = buffer32 >> 1;
		
		fread(&buffer32, sizeof(uint32_t), 1, handler->fp_petslib);
		/*printf("\nPET SEQID: %u(%c)\n", buffer32, startpet ? '+' : '-');
		printf("Head.chr%2u:%10u%c\n", chrom[0], pos[0], strand[0]);
		printf("Tail.chr%2u:%10u%c\n\n", chrom[1], pos[1], strand[1]);*/

		PyList_Append(result, Py_BuildValue("{sisisiscsisisc}", "id", buffer32, "chrom", chrom[0], "pos", pos[0], "strand", strand[0], "chrom2", chrom[1], "pos2", pos[1], "strand2", strand[1]));
	}
	return result;
}

PyObject *pets_query_single (PET_Struct handler, uint32_t chrom, uint32_t posx, uint32_t posy, uint32_t max)
{
	char strand;
	uint32_t i, count, tagx, tagy, pos, seq;
	PyObject *result;
	
	if (posx > posy || !posx || !posy || !chrom || chrom > handler->NumOfChrom) {
		perror("INPUT RANGE ERROR");
		return NULL;
	}
	
	// deal with start tag
	if (posx == 1) tagx = 0;
	else {
		tagx = select1(handler->RSDS[chrom-1], posx);
		if (!tagx) return NULL; // out of range
		tagx -= posx;	
	}
	
	// ending tag(exclusive)
	tagy = select1(handler->RSDS[chrom-1], posy + 1);
	if (!tagy) return NULL; // out of range
	else tagy -= posy + 1;
	
	result = PyList_New(0);
	for (count = 0, i = tagx; i < tagy; i++, count++) {
		if (max > 0 && count > max) break;
		
		fseek(handler->fp_petslib, handler->pets_base_pointers[chrom-1] + i * handler->PETWidth, SEEK_SET);
		fread(&pos, sizeof(uint32_t), 1, handler->fp_petslib);
		
		strand = pos & 1 ? '+' : '-';	pos >>= 1;
		
		fread(&seq, sizeof(uint32_t), 1, handler->fp_petslib);
		//printf("\nPET SEQID: %u\nChr%2u:%10u%c\n", seq, chrom, pos, strand);

		PyList_Append(result, Py_BuildValue("{sisisisc}", "id", seq, "chrom", chrom, "pos", pos, "strand", strand));
	}
	return result;
}

RS_Struct init (FILE *fin, unsigned int mode)
{
	int i;
	RS_Struct s = malloc(sizeof(struct rs_node));	
	s->fp = fin;
	assert(s->fp != NULL);
	
	fread(&s->S_size, sizeof(unsigned int), 1, s->fp);
	fread(&s->GA_size, sizeof(unsigned int), 1, s->fp);
	fread(&s->G_bytes, sizeof(unsigned int), 1, s->fp);

	//print("Number of Segments: %u\n", s->S_size);
	//print("Number of Groups: %u\n", s->GA_size);
	
	// load the S stream
	s->S_base_pointer = ftell(s->fp);
	if (mode) {
		s->StreamS = malloc(s->S_size * sizeof(uint64_t));
		if (s->StreamS == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR S ARRAY");
			exit(EXIT_FAILURE);
		} else fread(s->StreamS, sizeof(uint64_t), s->S_size, s->fp);
	} else {
		s->StreamS = NULL;
		fseek(s->fp, s->S_size * sizeof(uint64_t), SEEK_CUR); // jump over S stream
	}
	
	// load the A arrays and G stream, mandatory
	for (i = 0; i < 3; i++) {
		s->A[i] = malloc(s->GA_size * sizeof(unsigned int));
		if (s->A[i] == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR A ARRAY");
			exit(EXIT_FAILURE);
		} else  fread(s->A[i], sizeof(unsigned int), s->GA_size, s->fp);
	}
	s->bits_count[0] = s->A[0][s->GA_size-1];
	s->bits_count[1] = s->A[1][s->GA_size-1];
	s->bits_count[2] = s->bits_count[0] + s->bits_count[1];
	//print("Total Bits: %u (%u + %u)\n", s->bits_count[2], s->bits_count[0], s->bits_count[1]);
	
	s->StreamG = malloc(s->G_bytes * sizeof(uint8_t));
	if (s->StreamG == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY FOR G ARRAY");
		exit(EXIT_FAILURE);
	} else fread(s->StreamG, sizeof(uint8_t), s->G_bytes, s->fp);
	
	return s;
}

PET_Struct pets_load (const char *select, const char *pets, unsigned int mode)
{
	uint32_t i, *select_pointer;
	PET_Struct pnode;
		
	if (mode > 1) {
		perror("WRONG MODE CODE");
		return NULL;
	} else pnode = malloc(sizeof(struct pets_node));
	
	// load PETs library
	pnode->fp_petslib = fopen(pets, "rb");
	assert(pnode->fp_petslib != NULL);
	
	fread(&pnode->NumOfChrom, sizeof(uint32_t), 1, pnode->fp_petslib);
	fread(&pnode->NumOfPETS, sizeof(uint32_t), 1, pnode->fp_petslib);
	//print("There are %d chromosomes.\n", pnode->NumOfChrom);
	if (pnode->NumOfChrom < 256) {
		//print("1 byte is used for chromosome id.\n");
		pnode->ChromWidth = sizeof(uint8_t);
	} else if (pnode->NumOfChrom < 65536) {
		//print("2 bytes is used for chromosome id.\n");
		pnode->ChromWidth = sizeof(uint16_t);
	} else {
		//print("4 bytes is used for chromosome id.\n");
		pnode->ChromWidth = sizeof(uint32_t);
	}
	//print("There are %u PETs.\n", pnode->NumOfPETS);
	
	pnode->tag_count = malloc(pnode->NumOfChrom * sizeof(uint32_t));
	fread(pnode->tag_count, sizeof(uint32_t), pnode->NumOfChrom, pnode->fp_petslib);
	
	// if the input is PET data
	if (mode == 1) {
		pnode->pet_index = malloc(pnode->NumOfChrom * sizeof(uint32_t *));
		pnode->PETWidth = 2 * (sizeof(uint32_t) + pnode->ChromWidth) + sizeof(uint32_t);
		for (i = 0; i < pnode->NumOfChrom; i++) {
			pnode->pet_index[i] = malloc(pnode->tag_count[i] * sizeof(uint32_t));
			fread(pnode->pet_index[i], sizeof(uint32_t), pnode->tag_count[i], pnode->fp_petslib);
			//printf("Chromosome %u TAG count: %u.\n", i + 1, pnode->tag_count[i]);
		}
		pnode->pets_base_pointer = ftell(pnode->fp_petslib);
		pnode->pets_base_pointers = NULL;
	} else {
		pnode->pet_index = NULL;
		pnode->PETWidth = 2 * sizeof(uint32_t);
		pnode->pets_base_pointer = ftell(pnode->fp_petslib);
		pnode->pets_base_pointers = malloc(pnode->NumOfChrom * sizeof(uint32_t));
		for (i = 0; i < pnode->NumOfChrom; i++) {
			pnode->pets_base_pointers[i] = ftell(pnode->fp_petslib);
			//print("Chromosome %u TAG count: %u.\n", i + 1, pnode->tag_count[i]);
			fseek(pnode->fp_petslib, pnode->tag_count[i] * 2 * sizeof(uint32_t), SEEK_CUR);
		}
	}	
	
	// load RS structure
	pnode->fp_select = fopen(select, "rb");
	assert(pnode->fp_select != NULL);
	
	select_pointer = malloc(pnode->NumOfChrom * sizeof(uint32_t));
	fread(select_pointer, sizeof(uint32_t), pnode->NumOfChrom, pnode->fp_select);
	
	pnode->RSDS = malloc(pnode->NumOfChrom * sizeof(RS_Struct));
	for (i = 0; i < pnode->NumOfChrom; i++) {
		fseek(pnode->fp_select, select_pointer[i], SEEK_SET);
		pnode->RSDS[i] = init(pnode->fp_select, 0);
	}
	
	free(select_pointer);
  	return pnode;
}

void unload (RS_Struct s)
{
	int i;
	if (s != NULL) {
		if (s->StreamS != NULL)  free(s->StreamS);
		if (s->StreamG != NULL)  free(s->StreamG);
		for (i = 0; i < 3; i++)  free(s->A[i]);
		free(s);
	}
}

void pets_unload (PET_Struct pnode)
{
	uint32_t i;
	if (pnode == NULL) return;
	
	fclose(pnode->fp_select);
	fclose(pnode->fp_petslib);
	
	if (pnode->pet_index != NULL) {
		for (i = 0; i < pnode->NumOfChrom; i++)	{
			free(pnode->pet_index[i]);
			unload(pnode->RSDS[i]);
		}
		free(pnode->pet_index);
	} else {
		for (i = 0; i < pnode->NumOfChrom; i++)
			unload(pnode->RSDS[i]);		
		free(pnode->pets_base_pointers);
	}
	free(pnode->RSDS);
	free(pnode->tag_count);
	free(pnode);
}

