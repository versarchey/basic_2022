#ifndef XPETS_H
#define XPETS_H

#include <Python.h>

#define PETS_BSIZE 1000

#define MAX_GROUPS 1048576
#define MAX_SEGMENTS_PER_GROUP 4
#define MAX_BITS_PER_SEGMENT 64

typedef struct pets_node *PET_Struct;

void pets_create (char* inputfile, char* pets_out, char* select_out, char* chromfile, unsigned int maxpets, char *tmpdir);
void pets_create_single (char *inputfile, char *pets_out, char *select_out, char *chromfile, unsigned int max, char *tmpdir);

PET_Struct pets_load (const char *select, const char *pets, unsigned int mode);
void pets_unload (PET_Struct pnode);

PyObject *pets_query (PET_Struct handler, unsigned int chr, unsigned int x, unsigned int y, unsigned int maxpets);
PyObject *pets_query_single (PET_Struct handler, unsigned int chr, unsigned int posx, unsigned int posy, unsigned int maxpets);

// cc -c -fpic xpets_create.c xpets_query.c xpets_wrap.c -I /usr/include/python2.6/ -lpython2.6
// ld -shared xpets_create.o xpets_query.o xpets_wrap.o -o _xpets.so
// xpets.pets_create("/home/wangjianxing/pets/pet_maps.txt", "pets.out","pets.select","/home/wangjianxing/pets/hg19.txt",2000000,"/home/wangjianxing/pets");
// p = xpets.pets_load("pets.select","pets.out", 1)
// xpets.pets_query(p,1,1,20000,0)
// xpets.pets_unload(p)
#endif
