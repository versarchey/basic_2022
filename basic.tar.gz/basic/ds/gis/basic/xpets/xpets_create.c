#include "xpets.h"

struct pet_node {
	uint32_t id;
	uint32_t seq;
	uint32_t headpos;
	uint32_t headchr;
	char headstr;
	uint32_t tailpos;
	uint32_t tailchr;
	char tailstr;
	char p;
};
typedef struct pet_node *PET;

struct tag_node {
	uint32_t seq;
	uint32_t pos;
	uint32_t chr;
	char str;
};
typedef struct tag_node *TAG;

unsigned int floorLog2 (unsigned int n) {
	unsigned int pos = 0;
	
	if (n == 0) return pos;
	if (n >= 1<<16) { n >>= 16; pos += 16; }
	if (n >= 1<< 8) { n >>=  8; pos +=  8; }
	if (n >= 1<< 4) { n >>=  4; pos +=  4; }
	if (n >= 1<< 2) { n >>=  2; pos +=  2; }
	if (n >= 1<< 1) {           pos +=  1; }
	
	return pos;
}

// test whether one PET comes before the other PET based on their positions
// return a negative number iff p1 appear before p2
static
int comphead (const void *p1, const void *p2)
{
	PET x = (PET)p1, y = (PET)p2;
	return x->headchr == y->headchr ? x->headpos - y->headpos : x->headchr - y->headchr;
}

// test whether one PET comes before the other PET based on their IDs
// return a negative number iff p1 appear before p2
static
int compid (const void *p1, const void *p2)
{
	PET x = (PET)p1, y = (PET)p2;
	return x->id == y->id ? x->p - y->p : x->id - y->id;
}

// convert a chromosome name to an id
uint32_t convert (char *chr, char **chrname, uint32_t maxchr)
{
	uint32_t i;
	for (i = 0; i < maxchr; i++)
		if (!strcmp(chr, chrname[i])) return i + 1;
}

// create a bit vector for a given chromosome id
uint32_t createbv (char *output, uint32_t length, PET pets, uint32_t chrid, uint32_t startpos)
{
	uint32_t i, j, k, RLV, current_bit = 1;
	FILE *fp;
	
	fp = fopen(output, "w");
	assert (fp != NULL);
	
	// process one base per round
	for (k = startpos, RLV = i = 1, length++; i < length; i++)
		// when there are pets in the current location
		if (pets[k].headchr == chrid && pets[k].headpos == i) {
			// write last RLV
			fprintf(fp, "%u\n", RLV);
			// count number of pets
			for (RLV = 0; pets[k].headchr == chrid && pets[k].headpos == i; RLV++, k++);
			fprintf(fp, "%u\n", RLV);
			RLV = 1;
		} else RLV++; // if no then increase the number of consecutive 1s
	
	fprintf(fp, "%u\n", RLV); fclose(fp);
	
	while (pets[k].headchr == chrid) {
		//printf("%u\n", pets[k].id);
		k++;
	}
	printf("Chromosome %u finished. Count: %u.\n", chrid, k);
	
	return k;
}

// encode segment summary info into byte-aligned codes
uint8_t *byte_aligned_encoding (unsigned int S_count[][2], unsigned int *bytes_needed)
{
	unsigned int i, j, k, byte_count;
	uint8_t *G;
	
	// calculate total bytes needed
	for (byte_count = i = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		for (j = 0; j < 2; j++)
			if (S_count[i][j] > 0)
				byte_count += floorLog2(S_count[i][j]) / 7 + 1;
			else byte_count += 1;
	G = malloc(byte_count * sizeof(uint8_t));
	
	// encoding
	for (i = j = k = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		for (j = 0; j < 2; j++)
			if (S_count[i][j] > 0)
				for ( ; S_count[i][j] > 0; k++) {
					G[k] = S_count[i][j] & 0x7F;
					G[k] <<= 1;
					S_count[i][j] >>= 7;
					if (S_count[i][j] > 0)  G[k]++;
				}					
			else G[k++] = 0;
	
	assert(k == byte_count);
	*bytes_needed += byte_count;
	return G;
}

// build the RS structure for a set of bit vectors
void build_rs_structure (char *input, FILE *output, unsigned int first_bit)
{
	unsigned int current_bit, current_segment, S_start_bit, S_ended, G_ended;
	unsigned int bit_countS[MAX_SEGMENTS_PER_GROUP][2], bit_countG[2];
	unsigned int *A[3], RLV, RLV_Sum;
	unsigned int S_bit_count, bits_needed, G_bytes_count;
	unsigned int S_count, G_count, RLV_count, i, j;
	uint8_t **G;
	uint64_t *S;
	FILE *fp;
	
	fp = fopen(input, "r");
	assert(fp != NULL);
	
	// memory allocation
	S = malloc(MAX_GROUPS * MAX_SEGMENTS_PER_GROUP * sizeof(uint64_t));
	if (S == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY FOR S ARRAY");
		exit(EXIT_FAILURE);
	}
	
	G = malloc(MAX_GROUPS * sizeof(uint8_t *));
	if (G == NULL) {
		perror("CANT ALLOCATE ENOUGH MEMORY FOR G ARRAY");
		exit(EXIT_FAILURE);
	}
	for (i = 0; i < MAX_GROUPS; i++) G[i] = NULL;
	
	for (i = 0; i < 3; i++) {
		A[i] = malloc(MAX_GROUPS * sizeof(unsigned int));
		if (A[i] == NULL) {
			perror("CANT ALLOCATE ENOUGH MEMORY FOR A ARRAY");
			exit(EXIT_FAILURE);
		}
		for (j = 0; j < MAX_GROUPS; j++) A[i][j] = 0;
	}
	
	assert(first_bit < 2);
	printf("Start RLV Encoding...\n");
	
	// initialize
	current_segment = S_count = G_count = RLV_count = 0;
	S_bit_count = G_bytes_count = S_ended = G_ended = RLV = RLV_Sum = 0;
	bit_countG[0] = bit_countG[1] = 0;
	
	for (i = 0; i < MAX_SEGMENTS_PER_GROUP; i++)
		bit_countS[i][0] = bit_countS[i][1] = 0;
	
	// read only one run-length value each time
	for (S_start_bit = current_bit = first_bit; fscanf(fp, "%u", &RLV) != EOF; ) {
		assert(RLV); // run-length value cant be 0
						
		// dealing with S array
		RLV++; // avoid encode 1
		bits_needed = 1 + 2 * floorLog2(RLV);
		// if the run length value can be put into the S array
		if (S_bit_count + bits_needed < MAX_BITS_PER_SEGMENT) {
			S[S_count] <<= bits_needed;
			S[S_count] |= RLV; // put the gamma code into it
			S_bit_count += bits_needed;
			
		// start a new S array
		} else {
			 // padding if necessary
			for ( ; S_bit_count < MAX_BITS_PER_SEGMENT; S_bit_count++) {
				S[S_count] <<= 1;
				S[S_count]++;
			}
			if (!S_start_bit) S[S_count]--; // indicate what is the start bit in this segment
			
			S[++S_count] = RLV; // start a new S array
			S_start_bit = current_bit;
			S_bit_count = bits_needed;
			S_ended = 1; // indicate that we have started a new S array;
		}
		RLV--; // restore original RLV
		
		// dealing with G array
		// when the S array is not full yet
		if (!S_ended) bit_countS[current_segment][current_bit] += RLV;
		else {
			// S ended, can encode segment summary info
			
			// reach G's maximum segments
			if (++current_segment == MAX_SEGMENTS_PER_GROUP) {
				G[G_count] = byte_aligned_encoding(bit_countS, &G_bytes_count);
				current_segment = 0;
				G_ended = 1;
			}
			// start new S bit counting
			bit_countS[current_segment][current_bit] = RLV;
			bit_countS[current_segment][1 - current_bit] = 0;		
		}
		
		// dealing with A array
		if (!G_ended) bit_countG[current_bit] += RLV;
		else {
			A[0][G_count] = bit_countG[0];
			A[1][G_count] = bit_countG[1];
			A[2][G_count] = G_bytes_count;
			bit_countG[current_bit] += RLV;
			if (++G_count == MAX_GROUPS) {
				perror("NUMBER OF GROUPS REACHES THE MAXIMUM");
				exit(EXIT_FAILURE);
			}
		}
		
		// update
		RLV_count++;
		RLV_Sum += RLV;
		current_bit = 1 - current_bit;
		S_ended = G_ended = 0;
	}
	
	// dealing with the last S
	for (; S_bit_count < MAX_BITS_PER_SEGMENT; S_bit_count++, S[S_count]++) S[S_count] <<= 1; // padding
	if (!S_start_bit) S[S_count]--; // indicate the start bit
	S_count++;
	
	// dealing with the last G and A	
	while (++current_segment < MAX_SEGMENTS_PER_GROUP)
		bit_countS[current_segment][0] = bit_countS[current_segment][1] = 0;
		
	G[G_count] = byte_aligned_encoding(bit_countS, &G_bytes_count);
	A[0][G_count] = bit_countG[0];
	A[1][G_count] = bit_countG[1];
	A[2][G_count] = G_bytes_count;
	G_count++;
	
	printf("Encode Finished.\n");
	printf("Number of RLVs: %u\n", RLV_count);
	printf("Total Bits: %u (%u + %u)\n", RLV_Sum, bit_countG[0], bit_countG[1]);
	printf("Number of Segments: %u\n", S_count);
	printf("Number of Groups: %u\n", G_count);
	printf("Total bytes for G stream: %u\n", G_bytes_count);
	fclose(fp);
	
	printf("Start Writing Data to File....\n");
	// meta-data
	fwrite(&S_count, sizeof(unsigned int), 1, output);
	fwrite(&G_count, sizeof(unsigned int), 1, output);
	fwrite(&G_bytes_count, sizeof(unsigned int), 1, output);
	
	// S array
	fwrite(S, sizeof(uint64_t), S_count, output); free(S);
	
	// A arrays
	for (i = 0; i < 3; i++)
		fwrite(A[i], sizeof(unsigned int), G_count, output);
	free(A[0]);	free(A[1]);
	
	// G stream
	fwrite(G[0], sizeof(uint8_t), A[2][0], output); free(G[0]);
	for (i = 1; i < G_count; i++) {
		fwrite(G[i], sizeof(uint8_t), A[2][i] - A[2][i-1], output);
		free(G[i]);
	} free(A[2]); free(G);

	printf("Written Completed.\n");
}

// create a PET query structure and a PET library
void pets_create (char *inputfile, char *pets_out, char *select_out, char *chromfile, uint32_t maxpets, char *tmpdir)
{
	char rbuffer[1000];
	char **chrname;
	
	uint32_t i, j, k;
	uint32_t NumOfChrom;
	uint32_t NumOfBases;
	uint32_t NumOfPETS;
	uint32_t ChrWidth;
	
	uint32_t *chrlen;
	uint32_t *tagid;
	uint32_t *tags_count;
	uint32_t *RS_pointer;
	
	uint8_t wbuffer8;
	uint16_t wbuffer16;
	uint32_t wbuffer32;
	uint32_t seq, hp, tp, ct;
	char hc[10], tc[10];
	char hs[2], ts[2];
	
	PET pets;
	FILE *fp;
	
	fp = fopen(chromfile, "r");
	assert(fp != NULL);
	
	// read the chromosome info
	for (NumOfChrom = 0; fgets(rbuffer, 1000, fp) != NULL; NumOfChrom++);
	fseek(fp, 0, SEEK_SET);
	chrlen = malloc(NumOfChrom * sizeof(uint32_t));
	chrname = malloc(NumOfChrom * sizeof(char *));
	for (NumOfBases = i = 0; i < NumOfChrom; i++) {
		chrname[i] = malloc(1000 * sizeof(char));
		fscanf(fp, "%s%u", chrname[i], &chrlen[i]);
		NumOfBases += chrlen[i];
	}
	fclose(fp);
	printf("There are %d chromosomes.\n", NumOfChrom);
	if (NumOfChrom < 256) {
		printf("1 byte is used for chromosome id.\n");
		ChrWidth = sizeof(uint8_t);
	} else if (NumOfChrom < 65536) {
		printf("2 bytes is used for chromosome id.\n");
		ChrWidth = sizeof(uint16_t);
	} else {
		printf("4 bytes is used for chromosome id.\n");
		ChrWidth = sizeof(uint32_t);
	}
	printf("Total bases: %u.\n", NumOfBases);
			
	pets = malloc(2 * maxpets * sizeof(struct pet_node));
	assert(pets != NULL);
	
	tags_count = malloc(NumOfChrom * sizeof(uint32_t));
	for (i = 0; i < NumOfChrom; i++) tags_count[i] = 0;
	
	fp = fopen(inputfile, "r");
	assert(fp != NULL);
	
	// read PETs info and assign IDs
	for (i = 0; fscanf(fp, "%u%s%u%s%s%u%s", &seq, hc, &hp, hs, tc, &tp, ts) != EOF; i++) {
		pets[i].id = i / 2;
		pets[i].seq = seq;
		pets[i].headchr = convert(hc, chrname, NumOfChrom);
		pets[i].tailchr = convert(tc, chrname, NumOfChrom);
		pets[i].headpos = hp;
		pets[i].tailpos = tp;
		pets[i].headstr = hs[0];
		pets[i].tailstr = ts[0];
		pets[i].p = '+';
		tags_count[pets[i].headchr-1]++;
		i++;
		pets[i].id = pets[i-1].id;
		pets[i].seq = pets[i-1].seq;
		pets[i].headchr = pets[i-1].tailchr;
		pets[i].tailchr = pets[i-1].headchr;
		pets[i].headpos = tp;
		pets[i].tailpos = hp;
		pets[i].headstr = ts[0];
		pets[i].tailstr = hs[0];
		pets[i].p = '-';
		tags_count[pets[i].headchr-1]++;
	}
	fclose(fp);
	qsort(pets, i, sizeof(struct pet_node), comphead);
	printf("%u tags(2 x pets) sorted.\n", i);	
	for (k = 0; k < NumOfChrom; k++) printf("%s: %u\n", chrname[k], tags_count[k]);
		
	fp = fopen(pets_out, "wb");
	assert(fp != NULL);
	
	// write meta-info
	NumOfPETS = i / 2;
	fwrite(&NumOfChrom, sizeof(uint32_t), 1, fp);
	fwrite(&NumOfPETS, sizeof(uint32_t), 1, fp);
	fwrite(tags_count, sizeof(uint32_t), NumOfChrom, fp);
	
	// write TAG IDs
	tagid = malloc(i * sizeof(uint32_t));
	assert(tagid != NULL);
	for (j = 0; j < i; j++) {
		tagid[j] = pets[j].id << 1;
		if (pets[j].p == '+') tagid[j]++;
	}
	fwrite(tagid, sizeof(uint32_t), i, fp);
	printf("%u TAG IDs written.\n", j);
	free(tagid);
	
	// create bit vector and insert TAGs for each chromosome
	printf("Creating bit-vectors...\n");
	for (j = k = 0; j < NumOfChrom; j++) {
		sprintf(rbuffer, "%s/%s.bv", tmpdir, chrname[j]);
		sprintf(chrname[j], "%s", rbuffer);
		k = createbv(chrname[j], chrlen[j], pets, j + 1, k);
		//assert(tags_count[j] == k);
	}
	assert(NumOfPETS == k / 2);
	printf("%u TAGs inserted.\n", k);
	
	// write PETs info
	qsort(pets, i, sizeof(struct pet_node), compid);
	for (j = 0; j < i; j++)
		if (pets[j].p == '+') {
			assert(j == pets[j].id * 2);
			
			// head part
			wbuffer32 = pets[j].headpos;
			wbuffer32 <<= 1;
			if (pets[j].headstr == '+') wbuffer32++;
			fwrite(&wbuffer32, sizeof(uint32_t), 1, fp);
			switch (ChrWidth) {
				case 1:
					wbuffer8 = pets[j].headchr;
					fwrite(&wbuffer8, ChrWidth, 1, fp);
					break;
				case 2: 
					wbuffer16 = pets[j].headchr;
					fwrite(&wbuffer16, ChrWidth, 1, fp);
					break;
				case 4:
					wbuffer32 = pets[j].headchr;
					fwrite(&wbuffer32, ChrWidth, 1, fp);
					break;
				default:
					perror("Chromosome id width error");
					exit(EXIT_FAILURE);
			}
			
			// tail part
			wbuffer32 = pets[j].tailpos;
			wbuffer32 <<= 1;
			if (pets[j].tailstr == '+') wbuffer32++;
			fwrite(&wbuffer32, sizeof(uint32_t), 1, fp);
			switch (ChrWidth) {
				case 1:
					wbuffer8 = pets[j].tailchr;
					fwrite(&wbuffer8, ChrWidth, 1, fp);
					break;
				case 2: 
					wbuffer16 = pets[j].tailchr;
					fwrite(&wbuffer16, ChrWidth, 1, fp);
					break;
				case 4:
					wbuffer32 = pets[j].tailchr;
					fwrite(&wbuffer32, ChrWidth, 1, fp);
					break;
				default:
					perror("Chromosome id width error");
					exit(EXIT_FAILURE);
			}
			
			// seq number
			wbuffer32 = pets[j].seq;
			fwrite(&wbuffer32, sizeof(uint32_t), 1, fp);
		}
	printf("%u PETs info written.\n", NumOfPETS);
	fclose(fp);
	free(pets);
	
	printf("Start constructing RS structure....\n");
	RS_pointer = malloc(NumOfChrom * sizeof(uint32_t));  
	fp = fopen(select_out, "wb");
	assert(fp != NULL);
	fseek(fp, NumOfChrom * sizeof(uint32_t), SEEK_SET);
	
	for (i = 0; i < NumOfChrom; i++) {	
		RS_pointer[i] = ftell(fp);
		build_rs_structure (chrname[i], fp, 1);		
		remove(chrname[i]);
	}
	
	fseek(fp, 0, SEEK_SET);
	fwrite(RS_pointer, sizeof(uint32_t), NumOfChrom, fp);
	fclose(fp);
	free(RS_pointer);
	printf("Construction Finished.\n");
}

// create a single tag query structure and a tag library
void pets_create_single (char *inputfile, char *pets_out, char *select_out, char *chromfile, uint32_t maxpets, char *tmpdir)
{
	char rbuffer[200];
	char **chrname;
	
	uint32_t i, j, k;
	uint32_t NumOfChrom;
	uint32_t NumOfBases;
	uint32_t NumOfTags;
	
	uint32_t *chrlen;
	uint32_t *tags_count;
	uint32_t *RS_pointer;
	
	uint32_t wbuffer32;
	uint32_t seq, hp;
	char hc[10];
	char hs[2];
	
	PET pets;
	FILE *fp;
	
	// read the chromosome info
	fp = fopen(chromfile, "r");	 assert(fp != NULL);	
	for (NumOfChrom = 0; fgets(rbuffer, 200, fp) != NULL; NumOfChrom++);
	fseek(fp, 0, SEEK_SET);
	chrlen = malloc(NumOfChrom * sizeof(uint32_t));
	chrname = malloc(NumOfChrom * sizeof(char *));
	for (NumOfBases = i = 0; i < NumOfChrom; i++) {
		chrname[i] = malloc(1000 * sizeof(char));
		fscanf(fp, "%s%u", chrname[i], &chrlen[i]);
		NumOfBases += chrlen[i];
	}
	fclose(fp);
	printf("There are %d chromosomes.\n", NumOfChrom);
	printf("Total bases: %u.\n", NumOfBases);
			
	pets = malloc(maxpets * sizeof(struct pet_node));
	assert(pets != NULL);
	
	tags_count = malloc(NumOfChrom * sizeof(uint32_t));
	for (i = 0; i < NumOfChrom; i++) tags_count[i] = 0;
	
	// read TAGs info
	fp = fopen(inputfile, "r"); assert(fp != NULL);	
	for (i = 0; fscanf(fp, "%u%s%u%s", &seq, hc, &hp, hs) != EOF; i++) {
		pets[i].seq = seq;
		pets[i].headchr = convert(hc, chrname, NumOfChrom);
		pets[i].headpos = hp;
		pets[i].headstr = hs[0];
		tags_count[pets[i].headchr-1]++;
	}
	fclose(fp);
	
	qsort(pets, i, sizeof(struct pet_node), comphead);
	for (j = 0; j < 10; j++) printf("%u: %u %u %c\n", pets[j].seq, pets[j].headchr, pets[j].headpos, pets[j].headstr);
	printf("%u tags sorted.\n", i);
	for (k = 0; k < NumOfChrom; k++)
		printf("%s: %u\n", chrname[k], tags_count[k]);
	
	fp = fopen(pets_out, "wb");
	assert(fp != NULL);
	
	// write meta-info
	fwrite(&NumOfChrom, sizeof(uint32_t), 1, fp);
	fwrite(&i, sizeof(uint32_t), 1, fp);
	fwrite(tags_count, sizeof(uint32_t), NumOfChrom, fp);
	free(tags_count);
	
	// create bit vector and insert TAGs for each chromosome
	printf("Creating bit-vectors...\n");
	for (j = k = 0; j < NumOfChrom; j++) {
		sprintf(rbuffer, "%s/%s.bv", tmpdir, chrname[j]);
		sprintf(chrname[j], "%s", rbuffer);
		k = createbv(chrname[j], chrlen[j], pets, j + 1, k);
	}
	assert(i == k);
	printf("%u TAGs inserted.\n", k);	
	
	// write PETs(TAGs) info
	for (j = 0; j < i; j++) {
		wbuffer32 = pets[j].headpos;
		wbuffer32 <<= 1;
		if (pets[j].headstr == '+') wbuffer32++;
		fwrite(&wbuffer32, sizeof(uint32_t), 1, fp);
		fwrite(&pets[j].seq, sizeof(uint32_t), 1, fp);
	}
	printf("%u PETs info written.\n", i);
	fclose(fp);
	free(pets);
	
	printf("Start constructing RS structure....\n");
	RS_pointer = malloc(NumOfChrom * sizeof(uint32_t));  
	fp = fopen(select_out, "wb");
	assert(fp != NULL);
	fseek(fp, NumOfChrom * sizeof(uint32_t), SEEK_SET);
	
	for (i = 0; i < NumOfChrom; i++) {	
		RS_pointer[i] = ftell(fp);
		build_rs_structure (chrname[i], fp, 1);		
		remove(chrname[i]);
	}
	
	fseek(fp, 0, SEEK_SET);
	fwrite(RS_pointer, sizeof(uint32_t), NumOfChrom, fp);
	fclose(fp);
	free(RS_pointer);
	printf("Construction Finished.\n");
}

