'''
Created on Feb 27, 2012

@author: Fabianus
'''
from browser.models import Project, Technology, CellLine, TargetFactor

def initialize(engine):
  engine.register('list_projects', handler=list_projects)
  engine.register('list_techs', handler=list_techs)
  engine.register('list_cells', handler=list_cells)
  engine.register('list_tfactors', handler=list_tfactor)

def list_projects(request, args):
  return _list_helper(Project, 'name')

def list_techs(request, args):
  return _list_helper(Technology, 'name')

def list_cells(request, args):
  return _list_helper(CellLine, 'name')

def list_tfactor(request, args):
  return _list_helper(TargetFactor, 'code')

def _list_helper(cls, attr):
  return dict((getattr(x, attr), x.descn) for x in cls.objects.all())
