'''
Created on Feb 26, 2012

@author: Fabianus
'''
from driver.acgt import ACGTSeq
from os import path
from settings import GENOME_SIZE_DIR, CHROM_BAND_DIR, GENOME_ACGT_DIR
from table.models import MetaTable
from util.mongo import BASICollection
import os
import re

def initialize(engine):
  engine.register('get_chrom_sizes', handler=get_chrom_sizes, get=('asm',))
  engine.register('get_chrom_bands', handler=get_chrom_bands, get=('asm', 'chrom'))
  engine.register('parse_location', handler=parse_location, get=('asm', 'term'))
  engine.register('get_refseq', handler=get_refseq, get=('asm', 'chrom', 'start~int', 'end~int'))

# -----------------------------
#  GET CHROMOSOME SIZES
# -----------------------------

def _to_dict(filename):
  chromlist = list()
  chroms = dict()
  with open(filename) as f:
    for line in f:
      if not line or line[0] == "#": continue
      name, size = re.split(r"\s+", line.rstrip())
      chromlist.append(name)
      chroms[name] = int(size)
  return chromlist, chroms

# Record the chromosome size of each assembly
# Assume filename is <asm name>.txt
GENOME_LIST = dict()
GENOME_SIZE = dict()
for filename in os.listdir(GENOME_SIZE_DIR):
  asm = filename[:-4]
  GENOME_LIST[asm], GENOME_SIZE[asm] = _to_dict(path.join(GENOME_SIZE_DIR, filename))

def get_chrom_sizes(request, args):
  return GENOME_SIZE[args['asm']]

# -----------------------------
#  GET CHROMOSOME BANDS
# -----------------------------

def get_chrom_bands(request, args):
  asm, chrom = args['asm'], args['chrom']
  result = _chrom_sizes(asm)
  for c in result:
    if (chrom == c['name'] or not chrom):
      c.update(_chrom_bands(asm, c['name']))
  return result

_chrom_bands_cache = dict()
def _chrom_bands(asm, chromname):
  """
  Given assembly and chromosome names, returns JSON of info on the chromosome bands.
  """
  cache = _chrom_bands_cache.get(asm, {})
  if not cache:
    fcband = path.join(CHROM_BAND_DIR, "%s.txt"% asm)
    with open(fcband) as f:
      for line in f:
        chrom, start, end, pq, color = line.rstrip().split("\t")
        m = cache.get(chrom)
        if not m: cache[chrom] = m = dict(p=[], q=[])
        m[pq[0]].append(dict(l=int(start), r=int(end), c=color))
    _chrom_bands_cache[asm] = cache
  return cache.get(chromname, {})

def _chrom_sizes(asm, skip=None):
  ls = list()
  gsize = GENOME_SIZE[asm]
  for chrom in GENOME_LIST[asm]:
    if skip and chrom in skip: continue # skip certain chromosomes
    ls.append(dict(name=chrom, size=gsize[chrom]))
  return ls

# -----------------------------
#  PARSE LOCATION
# -----------------------------

def parse_location(request, args):
  """
  Calls [_parse_helper] and returns JSON of the returned dictionary.
  """
  asm, term = args['asm'], args['term']
  result = dict()
  try:
    result.update(_parse_helper(asm, term.strip()))
  except:
    # check first if it's actually gene symbol
    try:
      result['status'] = 'GENE'
      table = MetaTable.objects.get(key='knownGene.%s'% asm)
      coll = BASICollection(table.value)
      
      # just search for exact match, because we already have autocomplete
      chrom, start, end = None, 1e9, 0
      for gene in coll.find_all({ 'sym': term }):
        if not chrom: chrom = gene['chrom']
        start = min(start, gene['start'])
        end = max(end, gene['end'])
      
      if not chrom: raise
      result['gene'] = dict(chrom=chrom, start=start, end=end)
    except:
      # not a gene location, not a gene symbol either
      # indicate that there's a parsing error
      result['status'] = 'ERR' 
  return result
    
def _parse_helper(asm, gloc):
  '''
  Parses text indicating genome location and
  returns a dictionary containing
  chromosome, left, and right positions
  
  >>> sorted(_parse_helper('hg19', 'chr1:1000-2000').iteritems())
  [('chrom', 'chr1'), ('end', 2000), ('start', 1000)]
  
  >>> sorted(_parse_helper('hg19', 'chr1:1,000-2,000').iteritems())
  [('chrom', 'chr1'), ('end', 2000), ('start', 1000)]

  >>> sorted(_parse_helper('hg19', 'chr1\t1000\t2000').iteritems())
  [('chrom', 'chr1'), ('end', 2000), ('start', 1000)]

  >>> sorted(_parse_helper('hg19', 'chr1\t1,000\t2,000').iteritems())
  [('chrom', 'chr1'), ('end', 2000), ('start', 1000)]

  >>> sorted(_parse_helper('hg19', 'CHR1\t1000\t2000').iteritems())
  [('chrom', 'chr1'), ('end', 2000), ('start', 1000)]
  
  >>> sorted(_parse_helper('hg19', 'CHR1    1000    2000').iteritems())
  [('chrom', 'chr1'), ('end', 2000), ('start', 1000)]
  '''
  
  origkey = dict((k.lower(), k) for k in GENOME_SIZE[asm].iterkeys())
  gensize = dict((k.lower(), v) for k,v in GENOME_SIZE[asm].iteritems())
  g = re.match(r"([^\:\-\+\s]+)([\:\s]+)?([\d,]+)?([\.\-\+\s]+)?([\d,]+)?", gloc).groups()
  if not g[0]: 
    raise Exception("Invalid genomic location")
  else:
    chrom = g[0].strip().lower()
    if chrom not in gensize:
      raise Exception("No such chromosome: [%s]"% chrom) 
    
  if g[2]:
    start = int(g[2].replace(",", ""))
  else:
    start = 1
    end = gensize[chrom]
    return dict(chrom=origkey[chrom], start=start, end=end)
    
  if g[3]:
    sign = g[3].strip()
    if not g[4]: raise Exception("Invalid genomic location")
      
    rhs = int(g[4].replace(",", ""))
    if sign == '+':
      end = min(gensize[chrom], start+rhs-1)
    else:
      end = min(gensize[chrom], rhs)
  else:
    end = start

  if end < start: end, start = start, end
  return dict(chrom=origkey[chrom], start=start, end=end)

# -----------------------------
#  GET REFERENCE SEQUENCE
# -----------------------------

def get_refseq(request, args):
  cache = _get_acgt_cache(args['asm'])
  result = {
    'seq': cache.query(args['chrom'], args['start'], args['end'])            
  }
  return result

_chrom_acgt_cache = dict()
def _get_acgt_cache(asm):
  cache = _chrom_acgt_cache.get(asm, {})
  if not cache:
    seqfile = path.join(GENOME_ACGT_DIR, asm, '%s.acgt'% asm)
    if not path.exists(seqfile):
      raise Exception('File not found: %s'% seqfile)
    cache = ACGTSeq(seqfile)
    _chrom_acgt_cache[asm] = cache
  return cache