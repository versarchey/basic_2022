'''
Created on Feb 26, 2012

@author: Fabianus
'''
from table.models import Track, Metadata
from table.trackdefs import TRACK_DEFS, TrackEncoder
import json
from util.http import json_service
from browser.utils import has_perm

def initialize(engine):
    engine.register('defs', handler=get_defs, output='manual')
    engine.register('list', handler=get_list, get=('asm',))
    engine.register('get_config', handler=get_config, get=('track_id',))
    engine.register('set_config', handler=set_config)

# -----------------------------
#    GET VARIOUS TRACK DEFINITIONS (gene, pcls, cov, usw.)
# -----------------------------

def get_defs(request, args):
    '''
    Returns a dictionary of track name -> {properties},
    where properties is a dictionary containing two main keys: 'options' (global) and 'series' (per-source config)
    '''
    result = dict((k,v.properties) for k,v in TRACK_DEFS.iteritems())
    with json_service(request, result, TrackEncoder) as response:
        return response

# -----------------------------
#    GET LIST OF TRACKS
# -----------------------------

def get_list(request, args): # needed by widget [tracky]
    result = list()
    # get all tracks with the same assembly
    for t in Track.objects.order_by('name').filter(table__asm__name=args['asm']):
        # skip this track if the user doesn't have permission on the table
        if not has_perm(request, t.table.library): continue

        lib_id = None
        try:            
            library = t.table.library
            libname = library.name
            lib_id = library.id
            
            target = library.target.code if library.target else '~'
            cell = library.cell.name if library.cell else '~'
            tech = library.tech.name if library.tech else '~'
            proj = library.proj.name if library.proj else '~'
        except:
            # reach this point: no library
            libname = target = cell = tech = proj = '~' # uncategorized
        
        result.append({'library': libname,     # e.g. CHG007
                                     'library_id': lib_id,
                                     'target': target, # e.g. RNAPII
                                     'cell': cell,         # e.g. MCF7
                                     'tech': tech,         # e.g. ChIP-Seq
                                     'proj': proj,
                                     'track_id': t.id, 
                                     'table_id': t.table.id, 
                                     'name': t.name,     # track name
                                     'descn': t.descn, 
                                     'type': t.track_type, 
                                     })
    return result

# -----------------------------
#    GET CONFIGS
# -----------------------------

def get_config(request, args):
    '''
    Returns all configurations related to a track
    User-specific configs, if present, will override global configs
    '''
    track = Track.objects.get(id=args['track_id'])
    
    # default (global) track configs
    public_configs = dict()
    for m in track.metadata_set.filter(owner=None):
        try:
            public_configs[m.key] = json.loads(m.value)
        except:
            public_configs[m.key] = m.value
    
    # user-specific track configs
    private_configs = dict()
    for m in track.metadata_set.filter(owner=request.user):
        try:
            private_configs[m.key] = json.loads(m.value)
        except:
            private_configs[m.key] = m.value
    
    return {
        'public': public_configs,
        'private': private_configs
    }

def _strip_dict(d):
    '''Recursively removes keys with empty values in d'''
    result = dict()
    for k,v in d.iteritems():
        if v is None or (type(v) in (str, unicode) and not v): continue
        if type(v) is dict:
            w = _strip_dict(v)
            if w: result[k] = w
        else:
            result[k] = v
    return result

# -----------------------------
#    SET CONFIGS
# -----------------------------

def set_config(request, args):
    options = dict((k[8:],v) for k,v in request.POST.iteritems() if k.startswith('options.'))
    series = dict((k[7:],v) for k,v in request.POST.iteritems() if k.startswith('series.'))
    track_id = request.POST['track_id']

    o_val = _strip_dict(_str_to_dict(options))
    s_val = _strip_dict(_str_to_dict(series))
    try:
        track = Track.objects.get(id=track_id)
        try:
            meta = Metadata.objects.get(key='options', track=track, owner=request.user)
            meta.value = json.dumps(o_val, indent=2)
        except Metadata.DoesNotExist:
            meta = Metadata(key='options', track=track, owner=request.user, value=json.dumps(o_val, indent=2))
        finally:
            meta.save()

        try:
            meta = Metadata.objects.get(key='series', track=track, owner=request.user)
            meta.value = json.dumps(s_val, indent=2)
        except Metadata.DoesNotExist:
            meta = Metadata(key='series', track=track, owner=request.user, value=json.dumps(s_val, indent=2))
        finally:
            meta.save()

        return { 'status': 'OK' }
    except Exception as e:
        return { 'status': 'ERR', 'message': str(e) }

def _str_to_dict(items):
    result = dict()
    for k,v in items.iteritems():
        arr = k.split('.')
        d = result
        for x in arr[:-1]:
            try:
                x = int(x) # see if the key is actually integer (javascript array)
            except: pass
            if not x in d: d[x] = dict()
            d = d[x]
            
        if v == 'null':
            v = None
        elif v in ('true', 'false'):
            v = (v == 'true')
        else:
            try:
                v = float(v)
            except: pass
        
        if v is not None:
            if isinstance(v, basestring):
                d[arr[-1]] = v if v else None
            else:
                d[arr[-1]] = v 
        
    return result