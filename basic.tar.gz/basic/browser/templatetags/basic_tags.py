from django import template
from django.contrib.humanize.templatetags.humanize import intcomma

register = template.Library()

# --- SIMPLE TAGS

@register.simple_tag
def prozent(number, *args, **kw):
    number = int(number)
    total = sum(args)
    if total:
        pct = '%.2f%%'% (number*100.0/total)
        return pct if 'only' in kw else '%s (%s)'% (intcomma(number), pct)
    else:
        return intcomma(number)

@register.simple_tag
def sigma(*args, **kw):
    total = sum(int(_) for _ in args)
    return intcomma(total) if kw.get('intcomma') else total