'''
Created on Feb 26, 2012

@author: Fabianus
'''
from django.http import HttpResponse, HttpResponseNotFound
from django.utils.importlib import import_module
from util.http import json_service
import os
from settings import ROOT_DIR
    
class Module(object):
    def __init__(self, mod_name, mod_instance):
        self.module_name = mod_name
        self.module = mod_instance
        self._methods = dict()
        
        # print 'Registering module [%s]'% mod_name
        mod_instance.initialize(self)
        
    def __repr__(self):
        return 'BASICModule <{0}>: {1}'.format(self.module_name, self.module)
        
    def register(self, method_name, handler, get=[], post=[], output='json'):
        self._methods[method_name] = dict(handler=handler, get_params=get, post_params=post, output=output)
    
    def has_method(self, meth_name):
        return meth_name in self._methods
    
    def execute(self, request, meth_name):
        m = self._methods[meth_name]
        args = Module._params(request.GET, *m['get_params'])
        if not args:
            args = Module._params(request.POST, *m['post_params'])
        
        result = m['handler'](request, args)
        
        if result is None:
            return HttpResponse()
        else:
            output = m['output']
            if output == 'json':
                with json_service(request, result) as response: return response
            elif output == 'manual':
                return result # this must be of type HttpResponse
            else:
                raise Exception('Unrecognized output type: [%s]'% output)

    @staticmethod
    def _params(source, *args):
        CONVERTERS = dict(int=lambda x: int(float(x)), float=float, list=list)
        result = dict()
        for arg in args:
            arg = arg.split('~')
            key = arg[0]
            conv = CONVERTERS.get(arg[-1], str)
            
            vals = source.getlist(key)
            if len(vals) == 0:
                result[key] = None
            elif len(vals) == 1:
                result[key] = [vals[0]] if conv is list else conv(vals[0]) 
            else:
                result[key] = [conv(_) for _ in vals] if conv != list else vals
        return result
    
class ModuleManager(object):
    def __init__(self, mod_dir):
        self._modules = dict()
        self._methods = dict()
        
        PREFIX = mod_dir.replace(os.sep, '.')
        for f in os.listdir(os.path.join(ROOT_DIR, mod_dir)):
            if f.endswith('.py'):
                name = f[:-3]
                if not name.startswith('_'):
                    mod = import_module('{0}.{1}'.format(PREFIX, name))
                    self._modules[name] = Module(name, mod)

    def execute(self, request, mod_name, meth_name):
        mod = self._modules.get(mod_name)
        if not mod:
            return HttpResponseNotFound('No such module [%s]'% mod_name)
        if not mod.has_method(meth_name):
            print mod, meth_name
            return HttpResponseNotFound('No such method [%s]'% meth_name)
        return mod.execute(request, meth_name)
        