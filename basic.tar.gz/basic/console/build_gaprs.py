'''
Created on Nov 25, 2011
Expects stdin like the following:

chr1  /tmp/tmpfile.chr1
chr2  /tmp/tmpfile.chr2
chrX  /tmp/tmpfile.chrX
...

Each temp file is assumed to be in the following format:
--> chrom, snp_pos  
chr1  1000
chr1  2000

@author: mulawadifh
'''

from argparse import ArgumentParser
from bitarray import bitarray
from fabi.pytools.io import opentemp, cleanup
from fabi.pytools.run import together
from fabi.pytools.shell import Shell, ShellChain, runscript
from os import path
import os
import sys
import yaml

def make_it_so(output, inputfile, size):
  root_dir = path.abspath(path.join(path.dirname(path.realpath(__file__)), path.pardir))

  sh = Shell()
  ch = ShellChain()
  ratio = 1 # normal ratio
  with opentemp(2, suffix='.snp.tmp') as (tmp1, tmp2):
    sh("cut -f 2- < '{inputfile}' > {tmp1.name}".format(**locals()))

    ba = bitarray(size)
    tmp1.seek(0)
    for line in tmp1:
      if not line.rstrip(): continue
      ba[int(line)-1] = 1
      
    tmp2.write('%d\n'% size)
    tmp2.write(ba.to01())
    tmp2.flush()
    
    inputname = tmp2.name # all clear
    make = path.join(root_dir, 'console', 'tools', 'make_ds.py')
    out, _ = runscript(sys.executable, make, 'rs', inputname, output, size)
    return int(out)

def main(args):
  # read chromosome sizes
  chrsize = dict()
  with open(args.chromfile) as f:
    for line in f:
      p, q = line.strip().split('\t')
      chrsize[p] = int(q)
  
  if not path.exists(args.outdir):
    os.mkdir(args.outdir)

  # read files to process
  tmpfiles = dict()
  for line in sys.stdin:
    line = line.strip()
    if not line: continue
    chrom, tmp = line.split('\t')
    if chrom in chrsize: tmpfiles[chrom] = tmp
  
  snpfile = dict()
  ids = dict()

  try:
    with together(args.proc) as tog:
      for chrom in chrsize.iterkeys():
        f = '%s.snp.%s'% (args.libname, chrom)
        snpfile[chrom] = f
        output = path.join(args.outdir, f)
        if chrom in tmpfiles: # do not call the method if there's no corresponding file for the given chromosome
          ids[chrom] = tog(make_it_so, output, tmpfiles[chrom], chrsize[chrom])
    
    # get the result -- into the same variable
    for chrom in ids.iterkeys():
      ids[chrom] = ids[chrom].get() # this return the ratio for this chromosome
    
    # create snp file
    outfile = path.join(args.outdir, '%s.snp'% args.libname)
    with open(outfile, 'w') as out:
      snpfile['__lib__'] = args.libname
      snpfile['__ids__'] = ids
      out.write(yaml.dump(snpfile))
  
    # DO NOT DELETE! 
    # The following line is used by the calling script to know the name of created file
    print outfile
  finally:
    if not args.no_cleanup:
      cleanup(*tmpfiles.values())
    
if __name__ == '__main__':
  parser = ArgumentParser()
  parser.add_argument('libname', help='Library name')
  parser.add_argument('chromfile', help='File containing info on chromosome length')
  parser.add_argument('-o', '--outdir', help='Output directory', default='.')
  parser.add_argument('-p', '--proc', type=int, help='Number of processors to use (default=auto)', default=-1)
  parser.add_argument('--no-cleanup', action='store_true', help='Do not delete the list of files passed via stdin')
  args = parser.parse_args()
  sys.exit(main(args))
