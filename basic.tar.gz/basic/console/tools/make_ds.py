'''
Created on Jun 11, 2011

@author: Fabianus
'''
from argparse import ArgumentParser
from extsds import wsman, gap_rs
from gis.basic import rmq, countif
import os
import shutil
import tempfile

def _init_workspace(wsfile):
  wsdir = '%s_dir'% os.path.basename(wsfile)
  wsabsdir = os.path.join(os.path.dirname(wsfile), wsdir)
  try:
    os.mkdir(wsabsdir)
  except:
    shutil.rmtree(wsabsdir)
    os.mkdir(wsabsdir)
  wsman.init_workspace(wsfile, wsdir)

def _make_rs(infile, wsfile, size):
  _init_workspace(wsfile)
  cons = gap_rs.Constructor()
  print cons.build(wsfile, infile)

def _make_sum(infile, wsfile, size):
  _init_workspace(wsfile)
  cons = gap_rs.SumConstructor()
  print cons.build(wsfile, infile, size)

def _make_max(infile, outfile, size):
  rmq.rmq_build(outfile, infile, size)

def _make_cif(infile, outfile, size):
  tmpdir = tempfile.mkdtemp(suffix='.make.cif')
  try:
    countif.build(infile, tmpdir, outfile, size)
  finally:
    shutil.rmtree(tmpdir)
    
def build(type_, infile, outfile, size):
  func = globals()['_make_%s'% type_]
  func(infile, outfile, size)

if __name__ == '__main__':
  parser = ArgumentParser()
  parser.add_argument('type', help='Type of data structure', choices=('rs', 'sum', 'max', 'cif'))
  parser.add_argument('input', help='Input file (a number per line)')
  parser.add_argument('output', help='Output file')
  parser.add_argument('size', type=int, help='Number of entries')

  args = parser.parse_args()
  build(args.type, args.input, args.output, args.size)