'''
Converts all track config stored in MySQL to MongoDB
Created on Nov 28, 2011

@author: mulawadifh
'''

from os import path
import sys
_dir = path.join(path.dirname(path.abspath(path.realpath(__file__))), path.pardir, path.pardir)
if _dir not in sys.path: sys.path.append(_dir)

import settings
settings.configure()

from util.mongo import BASICollection, trkcfg_coll
from table.models import Track
import json
import yaml

if __name__ == '__main__':
  processed = 0
  skipped = 0
  failed = 0
  failed_ids = list()

  for track in Track.objects.all():
    coll = trkcfg_coll(track.id)
    coll.drop()
    
    coll.create_index('key')
    coll.create_index('track.id')
    
    print track
    for meta in track.metadata_set.all():
      print '\t', meta,
      track = meta.track
      
      value = json.loads(meta.value)
      if type(value) == unicode: 
        value = str(value)
        
      if meta.key == 'source' and type(value) == str:
        value = [value]
      
      doc = dict(_id=meta.id, format='yaml', key=meta.key, value=value)
      doc['track.id'] = track.id
      if meta.owner: doc['owner'] = meta.owner
      
      print '->', doc
      coll.save(doc)
      processed += 1

  print '-' * 100
  print 'Processed:', processed
  print 'Skipped:', skipped
  print 'Failed:', failed, failed_ids
    