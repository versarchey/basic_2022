"""
Converts chromosome codes of 1..25 to chr1..chrM
Use: chromify.py <file containing chromosome list> <columns to convert; comma-separated>
"""

import sys
if __name__ == "__main__":
  chroms = list()
  chromfile = sys.argv[1] 
  columns = [int(c) for c in sys.argv[2].split(",")]
  with open(chromfile) as f:
    for line in f:
      chroms.append(line.split("\t")[0])
  for line in sys.stdin:
    arr = line.rstrip().split("\t")
    for c in columns:
      arr[c-1] = chroms[int(arr[c-1])-1]
    print "\t".join(arr) 