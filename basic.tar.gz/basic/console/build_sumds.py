'''
Created on Feb 17, 2010
Expects stdin like the following:

chr1  /tmp/tmpfile.chr1
chr2  /tmp/tmpfile.chr2
chrX  /tmp/tmpfile.chrX
...

With pileover mode, each temp file is assumed to be in the following format:
--> chrom, pos, '[' or ']', tag weight  
chr1  1000  [  2
chr1  2000  ]  2

With non-pileover mode, each temp file is assumed to be in the following format:
--> chrom, pos, level in the position 
chr1  1000  12
chr1  2000  27
chr1  3000  7

@author: mulawadifh
'''

from argparse import ArgumentParser
from fabi.pytools.io import opentemp, cleanup
from fabi.pytools.run import together
from fabi.pytools.shell import Shell, is_sorted, ShellChain, runscript
from os import path
import os
import sys
import yaml

def make_it_so(output, inputfile, size, pileover):
  _MIN_SPAN = 50
  
  root_dir = path.abspath(path.join(path.dirname(path.realpath(__file__)), path.pardir))
  if pileover:
    stream = path.join(root_dir, 'scripts', 'awk', 'pileup.awk')
  else:
    stream = path.join(root_dir, 'scripts', 'awk', 'flatstream.awk')

  sh = Shell()
  ratio = 1 # normal ratio
  with opentemp(3, suffix='.sum.tmp') as (tmp1, tmp2, tmp3):
    sh("cut -f 2- < '{inputfile}' > {tmp1.name}".format(**locals()))

    # find out the span min-max
    ch = ShellChain()
    ch.chain('cat {tmp1.name}'.format(**locals()))
    
    # include sorting only if it's not already sorted
    if not is_sorted(tmp1.name, '-k 1n,1'): ch.chain('sort -k 1n,1')

    (ch.context(locals())
       .chain('awk -f {stream} -v chromsize={size}')
       .chain(r"""awk 'BEGIN {{ mx=0; mn=2147483647; }} 
                             {{ if ($0>mx) mx=$0; if ($0<mn) mn=$0; }} 
                         END {{ print (mx-mn) }}'""")
       .chain('cat > {tmp3.name}')
    ).execute()

    with open(tmp3.name) as f:
      span = float(f.read())

    if span < _MIN_SPAN:
      modifier = _MIN_SPAN/span
    else:
      modifier = 1
    
    # NOTE: the awk is meant to get the max value found in tmp2.name,
    # to determine whether we need scaling
    ch = ShellChain()
    ch.chain('cat {tmp1.name}'.format(**locals()))
    
    # include sorting only if it's not already sorted
    if not is_sorted(tmp1.name, '-k 1n,1'): ch.chain('sort -k 1n,1')
       
    (ch.context(locals())
       .chain('awk -f {stream} -v chromsize={size}')
       .chain(r"""awk '{{ print int($0*{modifier}+0.5) }}'""")
       .chain('cat > {tmp2.name}')
    ).execute()

    inputname = tmp2.name # all clear
    make = path.join(root_dir, 'console', 'tools', 'make_ds.py')
    out, _ = runscript(sys.executable, make, 'sum', inputname, output, size)
    return int(out), modifier

def main(args):
  # read chromosome sizes
  chrsize = dict()
  with open(args.chromfile) as f:
    for line in f:
      p, q = line.strip().split('\t')
      chrsize[p] = int(q)
  
  if not path.exists(args.outdir):
    os.mkdir(args.outdir)

  # read files to process
  tmpfiles = dict()
  for line in sys.stdin:
    line = line.strip()
    if not line: continue
    chrom, tmp = line.split('\t')
    if chrom in chrsize: tmpfiles[chrom] = tmp
  
  sumfile = dict()
  id_mods = dict()

  try:
    with together(args.proc) as tog:
      for chrom in chrsize.iterkeys():
        f = "%s.sum.%s"% (args.libname, chrom)
        sumfile[chrom] = f
        output = path.join(args.outdir, f)
        if chrom in tmpfiles: # do not call the method if there's no corresponding file for the given chromosome
          id_mods[chrom] = tog(make_it_so, output, tmpfiles[chrom], chrsize[chrom], not args.no_pile)
    
    # get the result -- into the same variable
    for chrom in id_mods.iterkeys():
      id_mods[chrom] = id_mods[chrom].get()
    
    # create sum file
    outfile = path.join(args.outdir, "%s.sum"% args.libname)
    with open(outfile, "w") as out:
      sumfile["__lib__"] = args.libname
      sumfile["__ids__"] = dict((k,v[0]) for k,v in id_mods.iteritems())
      sumfile["__modifiers__"] = dict((k,v[1]) for k,v in id_mods.iteritems())
      out.write(yaml.dump(sumfile))
  
    # DO NOT DELETE! 
    # The following line is used by the calling script to know the name of created file
    print outfile
  finally:
    if not args.no_cleanup:
      cleanup(*tmpfiles.values())
    
if __name__ == '__main__':
  parser = ArgumentParser()
  parser.add_argument('libname', help='Library name')
  parser.add_argument('chromfile', help='File containing info on chromosome length')
  parser.add_argument('-o', '--outdir', help='Output directory (curdir)', default='.')
  parser.add_argument('-p', '--proc', type=int, help='Number of processors to use (auto)', default=-1)
  parser.add_argument('--no-pile', help='Do not perform pile-up',  action='store_true')
  parser.add_argument('--no-cleanup', action='store_true', help='Do not delete the list of files passed via stdin')
  args = parser.parse_args()
  sys.exit(main(args))
  