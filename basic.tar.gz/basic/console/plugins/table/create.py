'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.list import list_tables
from engine import table_core, table_load
from fabi.pytools.term import stdin_or_editor
from table.models import Table
import json

def help():
  return "Creates a new table"

def permissions():
  return ['table.add_table',]

def config(sub):
  sub.add_argument("asm", type=str, help="Assembly name, e.g. hg19, mm9")
  sub.add_argument("name", help="Table name (caption)")
  sub.add_argument("-l", "--lib", help="Name of library")
  sub.add_argument('-j', '--json', action='store_true', help='Prints out output in JSON format. Useful in automation.')
  sub.add_argument('--descn', nargs='?', const='', help='Table description')

  sub.add_argument('-i', '--input', help='Input file to be uploaded')
  
  group = sub.add_mutually_exclusive_group()
  group.add_argument('-p', '--preset', choices=table_load._PRESETS.keys(), help='Use predefined mappings')
  group.add_argument('-m', '--mapping', help='Mapping rules in format <column_pos>:<name>[:type][:longname][+]. ' +
                                             'Plus sign at the end indicates whether the column should be indexed')
  sub.set_defaults(func=_parser_callback)

def _refine_table_name(table_name):
  return table_name

def _parser_callback(args):
  table_name = _refine_table_name(args.name)
  with table_core.create_table_tx(table_name, args.asm, None, args.lib) as table:
    descn = args.descn
    if descn is not None:
      if descn == '':
        descn = stdin_or_editor('Please enter description for table [%s]'% args.name)
      table.descn = descn
    
    count = 0
    if args.input:
      if args.preset:
        count = table_load.load(args.input, table.id, preset=args.preset)
      elif args.mapping:
        count = table_load.load(args.input, table.id, maps=args.mapping.split(','))
      else:
        raise Exception('Input file is specified, but no preset or mapping is given.')
    
    if args.json:
      print json.dumps({ 
        'table-id': table.id, 
        'table-name': table.name,
        'upload-count': count, 
      })
    else:
      list_tables(args, id=table.id)
