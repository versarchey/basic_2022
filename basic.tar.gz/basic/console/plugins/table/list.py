'''
Created on Jun 10, 2011

@author: Fabianus
'''
from fabi.pytools.format import intcomma
from fabi.pytools.term import Tabulator
from fabi.pytools.text import parse_range
from util.mongo import BASICollection
from table.models import Table

def help():
  return "Lists tables in database"

def config(sub):
  sub.add_argument("tables", nargs='?', default=None, help="Table IDs; comma-separated. Omit or specify 'all' to list all libraries")
  sub.add_argument("filters", nargs='*', default=[], help="Conditions to filter the list of tables. Parameter 'tables' must be specified")
  sub.add_argument("--order-by", choices=['id', 'name', 'table_type'], default='id', help="default: order by ID")
  sub.add_argument('--csv', action='store_true', help='Returns only the table IDs in comma-separated format to be passed to other scripts')
  sub.set_defaults(func=list_tables)
  
def list_tables(args, **kw): # kw -> criteria passed to filter
  try:
    orby = args.order_by
  except:
    orby = 'id'
  
  # if called by others
  if not hasattr(args, 'verbose'): setattr(args, 'verbose', True) # default: verbose mode ON
  if not hasattr(args, 'csv'): setattr(args, 'csv', None)
  
  slash = None
  if hasattr(args, 'tables') and args.tables:
    if args.tables == 'all':
      pass # do nothing
    elif ":" in args.tables: # slice notation
      p, q = args.tables.replace("~","-").split(":")
      slash = slice(int(p) if p else None, int(q) if q else None)
    else:
      kw['id__in'] = parse_range(args.tables)
  
  if hasattr(args, 'filters'): 
    # in case this function is called by other functions that don't set 'filters'
    for filt in args.filters:
      k,v = filt.split('=')
      kw[k] = v
  
  tlist = Table.objects.filter(**kw).order_by(orby)
  if slash: tlist = [m for m in Table.objects.filter(**kw).order_by(orby)][slash]

  if args.csv: # only print IDs
    print ','.join(str(t.id) for t in tlist) if tlist else 'No table found.'
    return tlist

  tabby = Tabulator()
  tabby.add_column('ID', 6, just='right')
  tabby.add_column('Table name', 50, color='yellow')
  tabby.add_column('Assembly', 10, color='green')
  tabby.add_column('Library', 15, color='magenta')
  tabby.add_column('Traits', 30, just='left', color='cyan')
  tabby.add_column('Row count (_table_X)', 20, just='right')
 
  if tlist: # print only if there's something
    def _gen():
      for t in tlist:
        coll = BASICollection(t.id)
        yield [t.id, t.name, t.asm.name,
               '[%d] %s'% (t.library.id, t.library.name) if t.library else '-',
               ','.join(sorted(coll.meta().get('traits', []))) or '-',
               intcomma(coll.count() or '-')]
    tabby.print_table(_gen())
    
  return tlist