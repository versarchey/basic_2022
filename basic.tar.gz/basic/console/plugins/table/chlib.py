'''
Created on Jun 10, 2011

@author: Fabianus
'''
from browser.models import Library
from console.plugins.table.list import list_tables
from fabi.pytools.text import parse_range
from table.models import Table

def help():
  return "Sets corresponding library"
  
def permissions():
  return ['table.change_table',]

def config(sub):
  sub.add_argument("tables", help="Table IDs; comma-separated")
  sub.add_argument("op", choices=["set", "clear"], help="Set/clear tables' relationship to libraries")
  sub.add_argument("lib_id_name", help="Library ID or name", nargs="?")
  sub.set_defaults(func=lib_tables)
  
def lib_tables(args):
  tabids = parse_range(args.tables)
  for tabid in tabids:
    table = Table.objects.filter(id=tabid)
    if not table: continue
    table = table[0]
    if args.op == 'set':
      try:
        lib = Library.objects.get(id=int(args.lib_id_name))
      except:
        # if the above failed, it means we're given library name
        lib = Library.objects.get(name__iexact=args.lib_id_name)
      table.library = lib
    else: # clear
      table.library = None
    table.save()
  
  list_tables(args)
