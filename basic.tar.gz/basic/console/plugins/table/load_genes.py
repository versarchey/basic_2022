'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from console.plugins.table.list import list_tables
from console.plugins.track.common import aggregate
from engine import table_load
from engine.table_core import create_metatable, create_table_tx
from engine.table_load import IndexBasedUploader
from fabi.pytools.io import ouvrir, opentemp
from itertools import izip
from table.models import Table, MetaTable
from util.mongo import BASICollection
import re

_GOASSOC_URL = 'http://cvsweb.geneontology.org/cgi-bin/cvsweb.cgi/go/gene-associations/gene_association.goa_{org}.gz?rev=HEAD'
_GOTERMS_URL = 'http://www.geneontology.org/doc/GO.terms_alt_ids'


def help():
    return ("Loads UCSC known genes data into database. Also downloads related gene ontology databases")


def permissions():
    return ['table.add_table', ]


def config(parser):
    parser.add_argument('table_id_name', help='Table ID or name of type [gene]')
    parser.add_argument('-i', '--input', help='Input file name. If not specified, the script will read from stdin')
    parser.add_argument('--assoc', help='GO association file')
    parser.add_argument('--terms', help='GO terms file')
    parser.add_argument('--cosmic', help='Cosmic HGNC file')
    parser.set_defaults(func=_parser_callback)


_TUPLES = (
    (r'.kgXref.geneSymbol$', 'sym', 'str', 'Gene Symbol+'), # indexed
    (r'.kgXref.mRNA$', 'name', 'str', 'mRNA+'), # indexed
    (r'.name$', 'ucsc_name', 'str', 'Name+'), # indexed

    (r'.chrom$', 'chrom'),
    (r'.txStart$', 'start'),
    (r'.txEnd$', 'end'),

    (r'.strand$', 'strand', 'str', 'Strand'),
    (r'.cdsStart$', 'cds_start', 'int', 'CDS Start'),
    (r'.cdsEnd$', 'cds_end', 'int', 'CDS End'),
    (r'.exonStarts$', 'exon_starts', 'str', 'Exon Starts'),
    (r'.exonEnds$', 'exon_ends', 'str', 'Exon Ends'),
)

_MAPPING_NAME = dict((_[0], _[1]) for _ in _TUPLES)
_MAPPING_ALL = dict((_[1], _[2:]) for _ in _TUPLES)

# --- Upload UCSC gene file

def _upload_ucscfile(genefile, table_id):
    with ouvrir(genefile) as f:
        header = f.next()
        mapping = ['%d:%s:%s' % (q + 1, p, ':'.join(_MAPPING_ALL[p]))
                   for p, q in _determine_mapping(_MAPPING_NAME, header).iteritems()]
        table_load.load(genefile, table_id, mapping, forceful=True, skiplines=1,
                        uploader_cls=UCSCGeneUploader)

    table = Table.objects.get(id=table_id)
    asm = table.asm.name
    create_metatable(**{
        # to be used by gene search function
        # it needs to know which _table_XX to query
        'knownGene.%s' % asm: table_id,
    })

# --- Upload GO association file

def _upload_goassoc(assocfile, table_id):
    table = Table.objects.get(id=table_id)
    asm = table.asm.name

    def _helper(inputfile):
        found, total = _parse_goassoc_file(inputfile, table_id)
        create_metatable(**{
            # to be used by gene search function
            # it needs to know which _table_XX to query
            'goAssoc.{asm}'.format(asm=asm): table_id,
        })

        print 'Total GO association entries: %d' % total
        print 'Number of matches: %d (%.2f%%)' % (found, found * 100.0 / total)

    if assocfile:
        _helper(assocfile)
    else:
        org = dict(mm8='mouse',
                   mm9='mouse',
                   hg18='human',
                   hg19='human')[asm]
        with aggregate(_GOASSOC_URL.format(org=org)) as inputfile:
            _helper(inputfile)


def _parse_goassoc_file(inputfile, table_id):
    coll = BASICollection(table_id)
    for gene in coll.find_all():
        gene['ontology'] = []
        coll.save(gene)

    total = 0
    found = 0
    with ouvrir(inputfile) as f:
        for line in f:
            if line[0] == '!': continue
            arr = line.split('\t')
            gsym = arr[2]
            go_id = arr[4]
            genes = coll.find_all({'sym': gsym})

            yes = False
            for gene in genes:
                gene['ontology'].append(go_id)
                coll.save(gene)
                yes = True

            if yes: found += 1
            total += 1

    return found, total

# --- Upload GO terms, if not yet uploaded

def _upload_goterms(gotermsfile):
    def _helper(gofile):
        with open(gofile) as rawterms:
            with opentemp() as refinedterms:
                for line in rawterms:
                    if line[0] == '!': continue
                    line = line.rstrip()
                    if not line: continue
                    arr = line.split('\t')
                    refinedterms.write('\t'.join((arr[0], arr[2], arr[3], '1')) + '\n')
                    for x in arr[1].split(' '):
                        refinedterms.write('\t'.join((x, arr[2], arr[3], '2')) + '\n')

                refinedterms.flush()

                term = MetaTable.objects.filter(key='go.terms')
                if term: # overwrite existing goterms
                    table_id = term[0].value
                    table_load.load(refinedterms.name, table_id, preset='go.terms', forceful=True)
                else:
                    with create_table_tx(name='GO Terms', asm='hg19', descn='') as table:
                        table_load.load(refinedterms.name, table.id, preset='go.terms')
                        create_metatable(**{
                            # to be used by gene search function
                            # it needs to know which _table_XX to query
                            'go.terms': table.id,
                        })

    if gotermsfile:
        _helper(gotermsfile)
    else:
        with aggregate(_GOTERMS_URL) as gofile:
            _helper(gofile)

# ---

def _parser_callback(args):
    with aggregate(args.input or []) as genefile:
        table_id = get_table_id(args.table_id_name)
        _upload_ucscfile(genefile, table_id)
        if args.assoc:
            _upload_goassoc(args.assoc, table_id)
        if args.terms:
            _upload_goterms(args.terms)

        if args.cosmic:
            with aggregate(args.cosmic) as cosmic:
                table_load.load(cosmic, table_id, ljoin='sym', preset='cosmic.hgnc')

        list_tables(args, id=table_id)


def _determine_mapping(mappings, headline):
    headers = headline.split()
    newmaps = dict()
    for pat, name in mappings.iteritems():
        regex = re.compile(pat)
        for i, head in enumerate(headers):
            if regex.search(head):
                if name not in newmaps:
                    newmaps[name] = i
                else:
                    raise Exception('Ambiguous mapping: /%s/ has more than one match' % pat)
        if name not in newmaps:
            raise Exception('No column found that satisfies regex /%s/' % pat)
    return newmaps


class UCSCGeneUploader(IndexBasedUploader):
    def __init__(self, *args, **kwargs):
        super(UCSCGeneUploader, self).__init__(*args, **kwargs)

    def convert(self, line):
        doc = super(UCSCGeneUploader, self).convert(line)

        # converts to integer
        doc['sym'] = doc['sym'].rstrip()
        doc['cds_start'] = int(doc['cds_start'])
        doc['cds_end'] = int(doc['cds_end'])
        st = doc['start']

        # combine exon columns and make them relative to start position
        doc['exons'] = [(int(p) - st, int(q) - st) for p, q in izip(doc['exon_starts'].split(','),
                                                                    doc['exon_ends'].split(',')) if p]
        del doc['exon_starts']
        del doc['exon_ends']

        # convert to 1-based position
        doc['start'] += 1
        doc['end'] += 1
        doc['cds_start'] += 1
        doc['cds_end'] += 1
        return doc

    def postprocess(self, coll, srcfile):
        meta = coll.meta()
        meta['columns'] = [_ for _ in meta['columns'] if not _['name'].startswith('exon_')]
        meta['columns'].append(dict(name='exons', long_name='Exons', type='str', indexed=False))
        coll.meta(meta)
