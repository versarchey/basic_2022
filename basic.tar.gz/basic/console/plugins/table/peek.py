'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.table.common import get_table_id
from engine.table_core import iter_mcoll
from fabi.pytools.format import intcomma
from pygments import highlight
from pygments.formatters import get_formatter_by_name
from pygments.lexers import get_lexer_by_name
from util.mongo import BASICollection
from termcolor import colored
import pprint

def help():
  return "Display the uploaded content of a table"

def config(sub):
  sub.add_argument("table_id_name", help="Table ID or name")
  sub.add_argument("-n", help='Number of rows to display (default=5)', type=int, default=5)
  sub.add_argument("-c", help='Max characters in one line (default=80)', type=int, default=80)
  sub.set_defaults(func=peek_table)

def _format(val, field):
  intern_type = field.get_internal_type() 
  if intern_type in ('IntegerField',):
    return intcomma(val), 'right'
  elif intern_type in ('FloatField',):
    return val, 'right'
  else:
    return val, 'left'
  
def peek_table(args, **kw): # kw -> criteria passed to filter
  table_id = get_table_id(args.table_id_name)
  
  coll = BASICollection(table_id)
  if not coll.count():
    print colored("Not found: Corresponding data table for Table [%s]"% args.table_id_name, 'red')
    return 1

  pylexer = get_lexer_by_name("python", stripall=True)
  formatter = get_formatter_by_name("terminal")

  for entry in iter_mcoll(coll, limit=args.n):
    print highlight(pprint.pformat(entry, width=args.c).replace("u'", "'"), pylexer, formatter),

  print '-' * args.c
  
  # print metadata
  meta = coll.meta()
  print highlight(pprint.pformat(meta, width=args.c).replace("u'", "'"), pylexer, formatter),
