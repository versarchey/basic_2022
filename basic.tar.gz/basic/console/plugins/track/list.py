'''
Created on Jun 10, 2011

@author: Fabianus
'''
from fabi.pytools.format import shorten
from fabi.pytools.term import Tabulator
from fabi.pytools.text import parse_range
from pygments import highlight
from pygments.formatters import get_formatter_by_name
from pygments.lexers import get_lexer_by_name
from table.models import Track, Metadata
from termcolor import colored
import json
import re

# -- to format javascript config

def help():
  return 'Lists tracks in database'

def config(parser):
  parser.add_argument('track_ids', nargs='?', default=None, help='IDs of tracks to be displayed, e.g. 2-5,8-10')
  parser.add_argument("filters", nargs='*', default=[], help="Conditions to filter the list of tables. Parameter 'track_ids' must be specified")
  parser.add_argument('-v', '--verbose', action='store_true', help='Show metadatas as well')
  parser.add_argument('--csv', action='store_true', help='Returns only the table IDs in comma-separated format to be passed to other scripts')
  parser.add_argument('--order-by', choices=['id', 'name', 'track_type'], default='id', help='default: order by ID')
  parser.set_defaults(func=list_tracks)

def list_tracks(args, **kw): # kw -> criteria passed to filter
  try:
    orby = args.order_by
  except:
    orby = 'id'
  
  if not hasattr(args, 'verbose'): setattr(args, 'verbose', None)
  if not hasattr(args, 'csv'): setattr(args, 'csv', None)
  
  slash = None
  if hasattr(args, 'track_ids') and args.track_ids:
    if args.track_ids == 'all':
      pass
    elif ":" in args.track_ids: # slice notation
      p, q = args.track_ids.replace("~","-").split(":")
      slash = slice(int(p) if p else None, int(q) if q else None)
    else:
      kw["id__in"] = parse_range(args.track_ids)
  
  if hasattr(args, 'filters'): 
    # in case this function is called by other functions that don't set 'filters'
    for filt in args.filters:
      k,v = filt.split('=')
      kw[k] = v
  
  tlist = Track.objects.filter(**kw).order_by(orby)
  if slash: tlist = [m for m in tlist][slash]

  if args.csv: # only print IDs
    print ','.join(str(t.id) for t in tlist) if tlist else 'No track found.'
    return tlist

  if args.verbose:    
    if args.track_ids and not slash and args.track_ids != 'all' and len(parse_range(args.track_ids)) == 1: # special case: very verbose mode
      def _callback(entry):
        lexer = get_lexer_by_name("javascript", stripall=True)
        formatter = get_formatter_by_name("terminal")
        for md in Metadata.objects.filter(track__id=entry[0], owner=None).order_by('key'):
          print colored("\n\t[%s]"% md.key, "cyan")
          print "\t", highlight(md.value, lexer, formatter),
    else:
      def _callback(entry):
        for md in Metadata.objects.filter(track=entry[0], owner=None).order_by('key'):
          try:
            val = json.loads(md.value)
          except:
            val = re.sub(r'\s+', ' ', md.value)
          print "\t%s -> %s"% (colored(md.key, "cyan"), shorten(str(val), 100)) 
  else:
    _callback = None
  
  if tlist:
    tabby = Tabulator()
    tabby.add_column('ID', 6, just='right')
    tabby.add_column('Type', 7, color='red')
    tabby.add_column('Track name', 50, color='yellow')
    tabby.add_column('Table name', 50, color='magenta')
    tabby.print_table(((t.id, t.track_type, t.name, '[%d] %s'% (t.table.id, t.table.name)) for t in tlist), 
                      callback=_callback)
  return tlist