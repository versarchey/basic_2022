'''
Created on Jun 20, 2011

@author: mulawadifh
'''
from engine.table_core import create_track_tx, create_metadata
from table.models import MetaTable, Table

def help():
  return "Generates gene track (data must have been uploaded into database with 'table load_genes')"
  
def permissions():
  return ['table.add_track',]

def config(parser):
  parser.add_argument("asm", help="Assembly code")
  parser.set_defaults(func=_parser_callback)

def _parser_callback(args):
  tbl = MetaTable.objects.get(key='knownGene.%s'% args.asm)
  gene_table = Table.objects.get(id=tbl.value)

  with create_track_tx(gene_table, 'gene', 'UCSC Known Genes [%s]'% args.asm) as track:
    create_metadata(track, options='''
    {
      colors: {
        text: function(args) {
          var g = args.element;
          return (g["cosmic_cancer"] || g["cosmic_mutated"]) ? "red" : "black";
        }
      }
    }''')