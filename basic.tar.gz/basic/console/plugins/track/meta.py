'''
Created on Jun 10, 2011

@author: Fabianus
'''
from console.plugins.track.list import list_tracks
from fabi.pytools.term import stdin_or_editor
from fabi.pytools.text import parse_range
from table.models import Metadata, Track
from termcolor import colored

def help():
  return "Create/edit track metadata with the given KEY"

def permissions():
  return ['table.change_track',]

def config(parser):
  parser.add_argument("track_ids", help="Track ID")
  parser.add_argument("key", help="Metadata key")
  parser.add_argument("--editor", help="")
  parser.set_defaults(func=edit_track_metadata)

def edit_track_metadata(args):
  ids = parse_range(args.track_ids)

  prev_val = None
  # if there's only one ID, try to get the metadata, if exists
  if len(ids) == 1:
    try:
      # NOTE: do not modify user-specific metadata
      meta = Metadata.objects.get(track__id=ids[0], owner=None, key=args.key)
      prev_val = meta.value
    except:
      pass
  
  content = stdin_or_editor(preloaded=prev_val, editor=args.editor)  
  setattr(args, "verbose", True) # required before calling list_tracks()
  
  if content is None: # not modified
    list_tracks(args)
    print colored("No change", "white")
    return
  
  # if modified, change all afflicted tracks
  for track in Track.objects.filter(id__in=ids):
    try:
      # NOTE: do not modify user-specific metadata
      meta = track.metadata_set.get(key=args.key, owner=None) 
      if content: # not empty -- update mode
        meta.value = content
        meta.save()
      else:
        meta.delete() # no content -- delete existing
        print colored("Metadata '%s' is deleted from track %s"% (args.key, track.name), "red")
    except:
      if content: # insert mode
        meta = Metadata(key=args.key)
        meta.track = track
        meta.value = content
        meta.save()
      else:
        print colored("Nothing to delete from track %s"% (track.name), "yellow")
        
  list_tracks(args)
