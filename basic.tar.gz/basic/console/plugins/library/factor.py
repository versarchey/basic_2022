from browser.models import TargetFactor
from fabi.pytools.term import Tabulator, stdin_or_editor

def help():
  return 'Manage the list of target factors'

def config(parser):
  subpar = parser.add_subparsers()
  sub = subpar.add_parser('new', help='Create new target factor entry. Description read from stdin, if available')
  sub.add_argument('code', help='Code/short name of the new target factor')
  sub.add_argument('name', help='Long name')
  sub.set_defaults(func=_new)
  
  sub = subpar.add_parser('list', help='List all target factors')
  sub.set_defaults(func=_list)

def _new(args):
  factor = TargetFactor(code=args.code, name=args.name)
  factor.descn = stdin_or_editor('Please enter description for target factor [%s]'% args.code)
  factor.save()
  _list(args, id=factor.id)

def _list(args, **kw):
  tabby = Tabulator()
  tabby.add_column('ID', 6, just='right')
  tabby.add_column('Factor Code', 15, color='red')
  tabby.add_column('Name', 30, color='yellow')
  tabby.add_column('Description', 70)
  tabby.print_table((l.id, l.code, l.name, l.descn or '-') for l in TargetFactor.objects.filter(**kw))
