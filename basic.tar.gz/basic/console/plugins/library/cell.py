from browser.models import CellLine, Organism
from fabi.pytools.term import Tabulator, stdin_or_editor

def help():
  return 'Manage the list of cell lines'

def config(parser):
  subpar = parser.add_subparsers()
  sub = subpar.add_parser('new', help='Create new cell line entry. Description read from stdin, if available')
  sub.add_argument('name', help='Cell line name')
  sub.add_argument('org', help='Organism name')
  sub.set_defaults(func=_new)
  
  sub = subpar.add_parser('list', help='List all target factors')
  sub.set_defaults(func=_list)

def _new(args):
  cell = CellLine(name=args.name, org=Organism.objects.get(name__iexact=args.org))
  cell.descn = stdin_or_editor('Please enter description for cell [%s]'% args.name)
  cell.save()
  _list(args, id=cell.id)

def _list(args, **kw): # kw -> criteria passed to filter
  tabby = Tabulator()
  tabby.add_column('ID', 6, just='right')
  tabby.add_column('Cell Line', 15, color='red')
  tabby.add_column('Organism', 15, color='magenta')
  tabby.add_column('Description', 70)
  tabby.print_table((l.id, l.name, l.org.name, l.descn or '-') for l in CellLine.objects.filter(**kw))
