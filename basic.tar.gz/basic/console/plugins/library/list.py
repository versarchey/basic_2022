'''
Created on Sep 11, 2011

@author: Fabianus
'''
from browser.models import Library
from fabi.pytools.term import Tabulator
from fabi.pytools.text import parse_range
import re

def help():
  return "List libraries"

def config(sub):
  sub.add_argument("libs", nargs='?', default=None, help="Library IDs; comma-separated")
  sub.set_defaults(func=list_libraries)

def list_libraries(args, **kw): # kw -> criteria passed to filter
  if hasattr(args, 'libs') and args.libs:
    try:
      kw['id__in'] = parse_range(args.libs)
    except:
      kw['id__in'] = [Library.objects.get(name=_).id for _ in args.libs.split(',')]
  
  tabby = Tabulator()
  tabby.add_column('ID', 5, just='right')
  tabby.add_column('Library name', 20, color='yellow')
  tabby.add_column('Description', 35)
  tabby.add_column('Project', 15, color='cyan')
  tabby.add_column('Cell Line', 15, color='magenta')
  tabby.add_column('Technology', 15, color='red')
  tabby.add_column('Target Factor', 15, color='green')
  tabby.add_column('Owners', 15, color='blue')
  tabby.add_column('Groups', 20, color='cyan')

  libs = list(Library.objects.filter(**kw))
  def _gen():
    for l in libs:
      tup = [l.id, l.name, re.sub(r'[\r\n]+', r'\\n', l.descn or '')]
      tup.append(l.proj.name if l.proj else '-')
      tup.append(l.cell.name if l.cell else '-')
      tup.append(l.tech.name if l.tech else '-')
      tup.append(l.target.code if l.target else '-')
      tup += [','.join(sorted(u.username for u in l.owners.all())) or '-',
              ','.join(sorted(g.name for g in l.groups.all())) or '-']
      yield tup

  tabby.print_table(_gen())
  return libs