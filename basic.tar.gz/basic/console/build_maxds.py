'''
Created on Feb 17, 2010
Expects stdin like the following:

chr1  /tmp/tmpfile.chr1
chr2  /tmp/tmpfile.chr2
chrX  /tmp/tmpfile.chrX
...

With pileover mode, each temp file is assumed to be in the following format:
--> chrom, pos, '[' or ']', tag weight  
chr1  1000  [  2
chr1  2000  ]  2

With non-pileover mode, each temp file is assumed to be in the following format:
--> chrom, pos, level in the position 
chr1  1000  12
chr1  2000  27
chr1  3000  7

@author: mulawadifh
'''

from argparse import ArgumentParser
from fabi.pytools.io import opentemp, cleanup
from fabi.pytools.run import together
from fabi.pytools.shell import Shell, is_sorted, ShellChain, runscript
from os import path
import os
import sys
import yaml

def make_it_so(output, input, size, pileover):
  _RMQ_LIMIT = 32767

  root_dir = path.abspath(path.join(path.dirname(path.realpath(__file__)), path.pardir))
  if pileover:
    stream = path.join(root_dir, 'scripts', 'awk', 'pileup.awk')
  else:
    stream = path.join(root_dir, 'scripts', 'awk', 'flatstream.awk')

  sh = Shell()
  ch = ShellChain()
  ratio = 1 # normal ratio
  with opentemp(4, suffix='.rmq.tmp') as (tmp1, tmp2, tmp3, tmp4):
    sh("cut -f 2- < '{input}' > {tmp1.name}".format(**locals()))
    
    # NOTE: the awk is meant to get the max value found in tmp2.name,
    # to determine whether we need scaling
    ch.chain('cat {tmp1.name}'.format(**locals()))
    
    # include sorting only if it's not already sorted
    if not is_sorted(tmp1.name, '-k 1n,1'): ch.chain('sort -k 1n,1')

    (ch.context(locals())
       .chain('awk -f {stream} -v chromsize={size}')
       .chain(r"""awk 'BEGIN {{x=0}} {{y=int($0+0.5); if (y>x) x=y; print y;}} END {{print x>"{tmp4.name}"}}'""")
       .chain('cat > {tmp2.name}')
    ).execute()

    with open(tmp4.name) as f:
      maxval = int(f.read())
    
    if maxval <= _RMQ_LIMIT: 
      inputname = tmp2.name # all clear
    else:
      # uh-oh... time for plan B: scale down the values
      ratio = float(maxval)/_RMQ_LIMIT
      sh("awk '{{ print int($0*{_RMQ_LIMIT}/{maxval} +0.5) }}' < {tmp2.name} > {tmp3.name}".format(**locals()))
      inputname = tmp3.name
    
    make = path.join(root_dir, 'console', 'tools', 'make_ds.py')
    runscript(sys.executable, make, 'max', inputname, output, size)
    return ratio

def main(args):
  # read chromosome sizes
  chrsize = dict()
  with open(args.chromfile) as f:
    for line in f:
      p, q = line.strip().split('\t')
      chrsize[p] = int(q)
  
  if not path.exists(args.outdir):
    os.mkdir(args.outdir)

  # read files to process
  tmpfiles = dict()
  for line in sys.stdin:
    line = line.strip()
    if not line: continue
    chrom, tmp = line.split('\t')
    if chrom in chrsize: tmpfiles[chrom] = tmp
  
  dsfile = dict()
  ratios = dict()

  try:
    with together(args.proc) as tog:
      for chrom in chrsize.iterkeys():
        f = "%s.max.%s"% (args.libname, chrom)
        dsfile[chrom] = f
        output = path.join(args.outdir, f)
        if chrom in tmpfiles: # do not call the method if there's no corresponding file for the given chromosome
          ratios[chrom] = tog(make_it_so, output, tmpfiles[chrom], chrsize[chrom], not args.no_pile)
    
    # get the result -- into the same variable
    for chrom in ratios.iterkeys():
      ratios[chrom] = ratios[chrom].get() # this return the ratio for this chromosome
    
    # create rmq file
    outfile = path.join(args.outdir, "%s.max"% args.libname)
    with open(outfile, "w") as out:
      dsfile["__lib__"] = args.libname
      dsfile["__ratios__"] = ratios
      out.write(yaml.dump(dsfile))
  
    # DO NOT DELETE! 
    # The following line is used by the calling script to know the name of created file
    print outfile
  finally:
    if not args.no_cleanup:
      cleanup(*tmpfiles.values())
    
if __name__ == '__main__':
  parser = ArgumentParser()
  parser.add_argument("libname", help="Library name")
  parser.add_argument("chromfile", help="File containing info on chromosome length")
  parser.add_argument("-o", "--outdir", help="Output directory (curdir)", default=".")
  parser.add_argument('-p', '--proc', type=int, help='Number of processors to use (auto)', default=-1)
  parser.add_argument("--no-pile", help="Do not perform pile-up",  action='store_true')
  parser.add_argument('--no-cleanup', action='store_true', help='Do not delete the list of files passed via stdin')
  args = parser.parse_args()
  sys.exit(main(args))
  