'''
Created on Aug 3, 2011

@author: mulawadifh
'''
from argparse import ArgumentParser
from contextlib import contextmanager
from fabi.pytools.io import opentemp
from gis.basic import seq
from os import path
import os
import sys
import yaml
import re

@contextmanager
def _convert(chrom, size, inpdir):
  fa = path.join(inpdir, '%s.fa'% chrom)
  if not path.exists(fa): yield None
  
  with open(fa) as f:
    with opentemp(suffix='.acgt') as tmp:
      erste = True
      for line in f:
        if erste: 
          tmp.write('>%s, %d\n' %(fa.split('.')[0], size))
        else:
          oink = re.sub(r'[^ACGTacgt]', 'N', line.rstrip())
          tmp.write(oink)
        erste = False
      tmp.flush()
      yield tmp.name

def make_it_so(name, chrom, size, inpdir, outdir, acgtdict):
  with _convert(chrom, size, inpdir) as tmpname:
    if tmpname:
      outfile = path.join(args.outdir, '%s.%s.xml'% (name, chrom))
      try:
        outdir = path.join(outdir, chrom)
        os.mkdir(outdir)
        seq.build(tmpname, outfile, outdir)
        acgtdict[chrom] = outfile
        print 'OK: %s'% chrom
      except:
        print >> sys.stderr, 'Failed: %s'% chrom
        raise

def main(args):
  # read chromosome sizes
  chrsize = dict()
  with open(args.chromfile) as f:
    for line in f:
      p, q = line.strip().split('\t')
      chrsize[p] = int(q)
  
  if not path.exists(args.outdir):
    os.mkdir(args.outdir)

  acgtdict = dict()
  for chrom, size in chrsize.iteritems():
    make_it_so(args.libname, chrom, size, args.inpdir, args.outdir, acgtdict)

  # create main file
  outfile = path.join(args.outdir, "%s.acgt"% args.libname)
  with open(outfile, "w") as out:
    acgtdict["__lib__"] = args.libname
    acgtdict["__sizes__"] = chrsize
    out.write(yaml.dump(acgtdict))

if __name__ == '__main__':
  parser = ArgumentParser(usage='This script expects to find file with pattern <chrom.fa> in input directory')
  parser.add_argument("libname", help="Library name")
  parser.add_argument("chromfile", help="File containing info on chromosome length")
  parser.add_argument("-i", "--inpdir", help="Input directory", default=".")
  parser.add_argument("-o", "--outdir", help="Output directory", default=".")
  parser.add_argument('-p', '--proc', type=int, help='Number of processors to use (default=auto)', default=-1)
  args = parser.parse_args()
  sys.exit(main(args))
    
