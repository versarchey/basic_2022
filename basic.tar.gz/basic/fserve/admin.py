from django.contrib import admin
from fserve.models import FileGroup, FileLink

class FileGroupAdmin(admin.ModelAdmin):
  list_display = ('name', 'path', 'library', 'recursive', 'includes', 'excludes',)

class FileLinkAdmin(admin.ModelAdmin):
  list_display = ('group', 'reldir', 'fname', 'accessed_ts', 'url',)

admin.site.register(FileGroup, FileGroupAdmin)
admin.site.register(FileLink, FileLinkAdmin)