'''
This module contains main functions that are called directly or indirectly via API.
'''