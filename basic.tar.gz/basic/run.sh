/home/fabianus/BASIC/_python/bin/python manage.py runserver 0.0.0.0:8000
