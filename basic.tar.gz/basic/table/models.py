from browser.models import Library, Assembly
from django.contrib.auth.models import User
from django.db import models
from table.trackdefs import TRACK_DEFS

class Table(models.Model): # this is the bigshot that keeps track of peak, cluster, and other tables
    def __unicode__(self):
        return self.name

    name = models.CharField(max_length=200) # long name (human-readable)
    descn = models.TextField(max_length=250, null=True, blank=True)
    asm = models.ForeignKey(Assembly, null=True)
    library = models.ForeignKey(Library, null=True) 

class MetaTable(models.Model): 
    '''Stores meta-information pertaining to Table entries, 
       e.g. which table contains known gene information for a given assembly,
            which table is the "subset" of another table (e.g. gene symbol -> accessions -> exons)
    '''
    def __unicode__(self):
        return "%s -> %s"% (self.key, self.value)
        
    key = models.CharField(max_length=50, db_index=True)
    value = models.TextField()
    table = models.ForeignKey(Table, db_index=True, null=True, blank=True)

class Track(models.Model): # stores data pertaining to tracks
    def __unicode__(self):
        return "%s [%s]"% (self.name, self.track_type)

    _TYPES = ((k,v.verbose_name) for k,v in TRACK_DEFS.iteritems())
    track_type = models.CharField(max_length=5, choices=sorted(_TYPES, key=lambda x: x[0]))
    name = models.CharField(max_length=200) # long name (human-readable)
    descn = models.TextField(max_length=250, null=True, blank=True)
    table = models.ForeignKey(Table, db_index=True)

class Metadata(models.Model): # stores additional info regarding a particular track
    def __unicode__(self):
        return "[%s] %s -> %s"% ('-' if not self.owner else self.owner, self.key, self.value)
        
    track = models.ForeignKey(Track, db_index=True)
    key = models.CharField(max_length=50, db_index=True)
    value = models.TextField()
    owner = models.ForeignKey(User, null=True, blank=True) # null=global/default value; not null=user-specific
