'''
Any parallel functions, e.g. sorting.
Created on Jun 6, 2011

@author: Fabianus
'''
from collections import deque
from fabi.pytools.io import opentemp
from fabi.pytools.run import together
from fabi.pytools.shell import Shell, split_file, count_line_num
from threading import Event
import itertools
import os
import sys

def treesort(infile, outfile, sortparams, nproc, tmpdir=None):
  '''
  Splits and sorts file in parallel, then merge it using UNIX sort.
  Topology: 1-level-deep tree. Merging is done by one process after all sortings
  are done, so it may be a bottleneck.
  '''
  sh = Shell()
  temps = split_file(infile, nproc, nline=1, tmpdir=tmpdir)
  try:
    with opentemp(nproc, dir=tmpdir) as sortemps:
      sortemps_names = [t.name for t in sortemps]
      with together(nproc) as ens:
        for i in xrange(nproc):
          ens(sh, 'sort {params} < {intmp} > {outmp}'.format(params=sortparams, intmp=temps[i], outmp=sortemps_names[i]))
      # merge
      outmps = ' '.join(sortemps_names)
      if outfile == sys.stdout:
        sh('sort -m {outmps}'.format(**locals()), output=outfile)
      else:
        sh('sort -m {outmps} > {outfile}'.format(**locals()))
  finally:
    for tmp in temps: os.unlink(tmp)

def hypersort(infile, outfile, sortparams, nproc, maxline=1000000, maxnodes=256, tmpdir=None):
  '''
  Sorts file in parallel using hypercube topology.
  Theoretically, this should have better processor utilization than treesort,
  but the creation of intermediate files may slow it down.
  May perform well if tmpdir is in a memory-backed filesystem, e.g. /dev/shm on Linux
  '''
  line_num = count_line_num(infile)+1 # "wc -l" may miss the last line
  sortedfiles = dict()
  im_done = Event()
  
  # cannot use [together]; will result in deadlock
  with together(nproc, use_manager=True) as sort_runner: # used to call sort/merge
    taskqueue = deque()
    task = _hypersort_helper(infile, sortparams, 1, line_num, maxline, maxnodes, 
                         tmpdir, 0, 0, sort_runner, sortedfiles, im_done, taskqueue)
    taskqueue.appendleft(task)
    while taskqueue:
      task = taskqueue.pop()
      try:
        next(task)
        taskqueue.appendleft(task)
      except StopIteration:
        pass

  im_done.wait() # wait for process #0 to finish
  final_file = sortedfiles[0] # sorted file
  
  sh = Shell()
  if type(outfile) == file:
    sh("cat '{final_file}'".format(**locals()), output=outfile)
    os.unlink(final_file)
  else:
    sh("mv -f '{final_file}' '{outfile}'".format(**locals()))
    
def _hypersort_helper(infile, sortparams, fr_line, to_line, maxline, maxnodes, tmpdir, 
                      pid, dim, sort_runner, sortedfiles, im_done, taskqueue):
  '''
  Called by hypersort
  -------------------
  infile: name of file to be sorted
  sortparams: parameters to be passed to UNIX's sort, e.g. "-k 1,1 -k 2n,2"
  fr_line: starting line to sort (from 1)
  to_line: ending line to sort
  maxline: run UNIX's sort only when the input size is less than or equal to maxline
  maxnodes: maximum number of nodes in hypercube (if this value is too high, we may get "too many open file" error)
  tmpdir: location of temporary files
  pid: process ID in the hypercube
  dim: dimension in hypercube (0=line, 1=plane, and so on)
  sort_runner: instance of together to be used globally to sort
  help_runner: instance of together to be used to call _hypersort_helper recursively (each invocation should never block)
  sortedfiles: contains {pid->sortedfile} of process that has finished sorting and merging
  im_done: threading.Event to be set to notify parent that this process has finished everything
  '''
  
  child_ids = list() # ID's of processes spawned by this one
  child_evs = list() # events that will be set by children when they're done
  
  flen = to_line-fr_line+1
  for x in itertools.count(dim): # never ends, but we'll stop somehow
    flen = to_line-fr_line+1 
    if (flen <= maxline): break # the file is small enough; no need to spawn another process

    nextpid = pid | (1 << x)
    if (nextpid >= maxnodes): break # limit the number of open files
    
    mid_line = fr_line-1 + flen/2 # new to_line for this process
    
    # recursive call
    ev = Event()
    t = _hypersort_helper(infile, sortparams, mid_line+1, to_line, maxline, maxnodes, 
                      tmpdir, nextpid, x+1, sort_runner, sortedfiles, ev, taskqueue)
    taskqueue.appendleft(t)
      
    child_ids.append(nextpid)
    child_evs.append(ev)
    to_line = mid_line # now my burden is halved

  sh = Shell()
  # time for me to work
  with opentemp(dir=tmpdir, delete=False, suffix='.%d.sort'% pid) as tmp:
    tmpname = tmp.name
    def _help(cond):
      cmd = "tail -n +{start} < '{infile}' | head -{n} | sort {params} > {out}"
      sh(cmd.format(infile=infile, start=fr_line, n=flen, params=sortparams, out=tmpname))
      cond.set()
      
    # we need to control how many sorting is done in one go with [sort_runner]
    cond = Event()
    sort_runner(_help, cond) # this command doesn't get executed right away
    while not cond.is_set(): yield
  
    # now we need to wait for our children to finish before merging (only if children is present)
    if child_ids:
      for cid, cev in reversed(zip(child_ids, child_evs)): # start from youngest kid
        while not cev.is_set(): yield # wait for the kid to finish
        
        with opentemp(dir=tmpdir, delete=False, suffix='.%d.merge'% pid) as tmp:
          kidfile = sortedfiles[cid]
          def _help(cond):
            cmd = "sort -m {params} {myfile} {kidfile} > {out}"
            sh(cmd.format(params=sortparams, myfile=tmpname, kidfile=kidfile, out=tmp.name))
            cond.set()
          
          cond = Event()
          sort_runner(_help, cond) # wait until merging is done
          while not cond.is_set(): yield
            
          os.unlink(tmpname) # delete my previous file
          os.unlink(kidfile) # delete kid's file
          tmpname = tmp.name # this is my new (merged) file
    
    sortedfiles[pid] = tmpname
    im_done.set() # this will tell our parent that I'm done

if __name__ == '__main__':
  hypersort(sys.argv[1], sys.stdout, ' '.join(sys.argv[3:]), int(sys.argv[2]))
