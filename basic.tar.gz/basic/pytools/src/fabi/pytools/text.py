'''
Text-related operations
'''

'''
Converts something like "1,3-4,7-8" to [1,3,4,7,8]
'''
def parse_range(r):
  result = list()
  a = r.split(',')
  for x in a:
    if '-' in x:
      p, q = x.split('-')
      result += list(xrange(int(p), int(q)+1))
    else:
      result.append(int(x))
  return result

