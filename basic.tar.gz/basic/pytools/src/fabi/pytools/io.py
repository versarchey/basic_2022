'''
Created on Dec 8, 2010

@author: mulawadifh
'''

from contextlib import contextmanager
from os import path
import os
import subprocess as sp
import tempfile
import time
import shutil

@contextmanager
def opentemp(count=1, dir=None, delete=True, prefix="tmp", suffix=""):
    """Creates temporary file(s) and deletes it on leaving the [with] block"""
    temp_list = [tempfile.NamedTemporaryFile(dir=dir, delete=False, 
                             prefix=prefix, suffix=suffix) for _ in xrange(count)]
    
    with deleting(*[_.name for _ in temp_list], delete=delete):
        try:
            if len(temp_list) == 1:
                yield temp_list[0]
            else:
                yield temp_list
        finally:
            for t in temp_list: t.close()

def which(file_, *env_vars):
    """Finds executable file in the PATH"""
    for p in ('PATH',) + env_vars:
        for path in os.environ.get(p, '').split(os.pathsep):
            if os.access(os.path.join(path, file_), os.X_OK):
                return os.path.join(path, file_)
    return None

@contextmanager
def creer(filename):
    '''Create a file with a given name and returns the handle.
    If there's an existing file, it's renamed with current date as suffix'''
    if path.exists(filename):
        today = time.strftime('%Y-%m-%d', time.localtime())
        bakfile = path.join('%s.%s.bak' %(filename, today))
        i = 1
        while path.exists(bakfile):
            bakfile = path.join('%s.%s.%02d.bak' %(filename, today, i))
            i += 1
        os.rename(filename, bakfile)
    with open(filename, 'w') as out:
        yield out
        
@contextmanager
def ouvrir(filename, buffered=False):
    '''Opens normal file or compressed file.
    If buffered is true, temporary file is used to hold the output.
    '''
    
    @contextmanager
    def _uncompressed(filename, prog):
        if not which(prog):
            raise Exception("Required executable '%s' not found."% prog)
        
        if not buffered:
            p = sp.Popen('%s -c %s' % (prog, filename), shell=True, stdout=sp.PIPE)
            # ACHTUNG!
            # we actually need to check the retcode here, similar to the code below,
            # but since it's not a blocking operation, the retcode may not be set yet.
            # quoi faire?
            yield p.stdout
        else:
            with opentemp() as f:
                p = sp.Popen('%s -c %s > %s' %(prog, filename, f.name), shell=True, stderr=sp.PIPE)
                p.wait()
                if p.returncode != 0:
                    raise Exception(p.stderr.read())
                yield f
    
    if type(filename) == file: # in case we're given stdin
        yield filename
    elif filename.endswith('.gz'):
        with _uncompressed(filename, 'gunzip') as _: yield _
    elif filename.endswith('.bz2'):
        with _uncompressed(filename, 'bunzip2') as _: yield _
    else:
        with open(filename) as _: yield _

@contextmanager
def deleting(*filelist, **kwargs):
    '''Deletes all file/directory specified in filelist recursively upon exiting [with] block'''
    try:
        yield
    finally:
        if kwargs.get('delete', True):
            cleanup(*filelist)

def cleanup(*filelist, **kwargs): # deletes files and also their directories if empty
    dirs = set(path.dirname(_) for _ in filelist)
    for f in filelist:
        if path.isdir(f):
            shutil.rmtree(f)
        else:
            if path.exists(f):
                os.unlink(f)
    if kwargs.get('rmdir', True): # by default, directory is deleted if empty
        for d in dirs:
            if not os.listdir(d): # if dir is empty
                shutil.rmtree(d)

if __name__ == '__main__':
    import sys
    filename = sys.argv[1]
    with ouvrir(filename, buffered=False) as f:
        for line in f: print line.rstrip()
