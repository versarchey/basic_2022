'''
Created on Dec 8, 2010

@author: mulawadifh
'''
from collections import deque
from threading import Event
import multiprocessing
import os
import threading

def _fetch_task(sched_tasks, active_tasks, cpu_count):
  if sched_tasks: # there are tasks queued
    if cpu_count == 0: # no limit
      return sched_tasks.pop()
    elif cpu_count > 0: # fixed limit
      if len(active_tasks) < cpu_count:
        return sched_tasks.pop()
    elif cpu_count < 0: # flexible; adjust to system load
      count = int(max(1, multiprocessing.cpu_count() - round(os.getloadavg()[0])))
      if len(active_tasks) < count:
        return sched_tasks.pop()
  return None

class _Task(threading.Thread):
  def __init__(self, id, proc, ev, args, kwargs):
    super(_Task, self).__init__()
    self._id = id
    self._proc = proc
    self._par_ev = ev
    self._args = args
    self._kwargs = kwargs
    self._result = None # return values from the invoked function
    self.error = None # exception instance, if any occurs
    self._par_ev.set() # tell parent thread to try to schedule me
  
  def get_id(self):
    return self._id # to be used when retrieving results
  
  def get(self):
    return self._result
  
  def run(self):
    try:
      self._result = self._proc(*self._args, **self._kwargs)
    except Exception as e:
      self.error = e
    finally:
      self._par_ev.set() # tell parent thread I'm done

class _Manager(threading.Thread):
  '''Extra thread created to execute the other threads
  '''
  def __init__(self, parent):
    super(_Manager, self).__init__()
    self._active_tasks = set() # stores Task objects currently running
    self._exit_reached = False # whether code execution has reached the end of 'with' block
    self.error = None

    # from parent
    self._parent = parent
    self._sched_tasks = parent._sched_tasks
    self._cpu_count = parent._cpu_count
    self._results = parent._results
    self._ev = parent._ev
    
  def run(self):
    while (not self._exit_reached) or self._sched_tasks or self._active_tasks:
      # check if there's any finished task
      for t in list(self._active_tasks):
        if not t.is_alive():
          self._active_tasks.remove(t) #remove from current set 
          if t.error: 
            self.error = t.error
            raise t.error
          if not self._results is None: 
            self._results[t._id] = t.get()

      # check if we there's a task to schedule
      with self._parent._task_lock:
        t = _fetch_task(self._sched_tasks, self._active_tasks, self._cpu_count)

      if t: # activate a Task
        self._active_tasks.add(t)
        t.start()
      
      self._ev.wait() # wait until any of child process screams

class together(object):
  """To schedule many threads to run in parallel,
  with specified number of threads allowed to be active at one time.
  
  Example:
  The following code will call function foo("Hello", True, 123) ten times,
  but only 5 threads are active in one go.
  
  with together(5) as ens:
    for i in xrange(10):
      ens(foo, "Hello", True, 123)
  """

  def set_cpu_count(self, cpu_count):
    self._cpu_count = cpu_count # to change scheduling behavior during runtime
  
  def __call__(self, proc, *args, **kwargs):
    with self._task_lock: 
      self._id += 1
      t = _Task(self._id, proc, self._ev, args, kwargs)
      self._sched_tasks.appendleft(t)
      return t
  
  # cpu_count=0 -> no limit
  # cpu_count<0 -> automatically adjusting to current system load (default)
  # cpu_count>0 -> exact limit
  def __init__(self, cpu_count=-1, results=None, use_manager=False):
    '''
    In some situations it may be necessary to spawn additional thread to act
    as manager for the other scheduled threads to prevent dead/livelock/starvation
    '''
    self._task_lock = threading.RLock()
    self._cpu_count = cpu_count
    self._id = 0 # task ID
    self._results = results
    self._ev = Event() # Task instance will set this to tell parent thread that it's done

    self._sched_tasks = deque() # stores Task objects queued for execution
    self._active_tasks = set() # stores Task objects currently running
    
    self._use_manager = use_manager
    if use_manager: # use extra thread to manage the others
      self.manager = _Manager(self)
      self.manager.start()
    
  def __enter__(self): return self

  def __exit__(self, type, value, traceback):
    if self._use_manager:
      self._exit_with_manager()
    else:
      self._exit_no_manager()
    
  def _exit_no_manager(self):
    while self._sched_tasks or self._active_tasks: # while there are still scheduled/active tasks
      with self._task_lock:
        t = _fetch_task(self._sched_tasks, self._active_tasks, self._cpu_count)
        if t: # activate a Task
          self._active_tasks.add(t)
          t.start()
      
      # barrier
      for t in list(self._active_tasks):
        if not t.is_alive(): # Task is completed
          self._active_tasks.remove(t)
          if t.error: raise t.error # fail fast
          if not self._results is None:
            self._results[t._id] = t.get()
      
      if self._active_tasks:
        self._ev.wait() # wait until any of child process screams
  
  def _exit_with_manager(self):
    self.manager._exit_reached = True
    self.manager.join() # if Manager terminates, it means everything's done
    if self.manager.error:
      raise self.manager.error
  