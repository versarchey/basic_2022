'''
Created on Nov 4, 2010

@author: fabianus
'''
from contextlib import contextmanager
from gis.basic import seq
from os import path
import os
import yaml

class ACGTSeq:
  _LIMIT = 4096
  
  @staticmethod
  @contextmanager
  def open(seqfile):
    driver = None
    try:
      driver = ACGTSeq(seqfile)
      yield driver
    finally:
      if driver: driver.close()
  
  def __init__(self, seqfile):
    with open(seqfile) as f:
      self.seqfile = yaml.load(f)
    self.chrsizes = self.seqfile['__sizes__']
    self.handlers = dict()
    self.dirname = path.dirname(path.abspath(seqfile))
  
  def query(self, chrom, start, end):
    size = self.chrsizes.get(chrom, 0)
    if not (0 <= end-start < ACGTSeq._LIMIT and 
            1 <= start <= size and
            1 <= end <= size): return None
    
    h = self.handlers.get(chrom, None)
    if not h:
      f = str(path.join(self.dirname, self.seqfile[chrom]))
      # HACK WARNING: we need the following line because the module
      # looks for file relative to current directory
      os.chdir(path.dirname(f))
      h = seq.load(f)
      self.handlers[chrom] = h
    return seq.substring(h, start, end-start+1)
  
  def close(self):
    for h in self.handlers.itervalues():
      seq.unload(h)
