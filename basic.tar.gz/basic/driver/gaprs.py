'''
Created on Nov 4, 2010

@author: fabianus
'''
from extsds import gap_rs
from os import path
import yaml
from collections import deque

class RankSelect:
  _CACHE_SIZE = 100
  
  class NO_FILE: pass

  def __init__(self, sumfile, silent=False):
    with open(sumfile) as f:
      self.filepaths = yaml.load(f)
    self.handlers = dict()
    self.ids = self.filepaths.get("__ids__", {})
    self.dirname = path.dirname(path.abspath(sumfile))
    self._cachedict = dict()
    self._cachedeq = deque()
    self.silent = silent # keep quiet when file not found

  def _get_handler(self, chrom):
    h = self.handlers.get(chrom)
    if not h:
      f = str(path.join(self.dirname, self.filepaths[chrom]))
      if not path.exists(f):
        self.handlers[chrom] = h = RankSelect.NO_FILE
      else:
        h = gap_rs.Query()
        h.load(f, self.ids[chrom])
        self.handlers[chrom] = h
    return h

  def _until(self, h, chrom, x):
    key = (chrom, x)
    if key in self._cachedict:
      return self._cachedict[key]
    else:
      val = h.count_until(1, x)
      self._cachedict[key] = val
      self._cachedeq.append(key)
      if len(self._cachedeq) > RankSelect._CACHE_SIZE:
        k = self._cachedeq.popleft()
        del self._cachedict[k]
      return val

  def count(self, chrom, start, end):
    h = self._get_handler(chrom)
    if h == RankSelect.NO_FILE and self.silent: 
      return 0
    
    x = self._until(h, chrom, end)
    if (start>1): x -= self._until(h, chrom, start-1)
    return x
  
  def close(self): pass
