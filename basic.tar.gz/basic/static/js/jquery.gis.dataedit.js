(function ($) {
    function random_ID() {
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz',
            string_length = 10,
            randomstring = '';
        for (var i = 0; i < string_length; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        return randomstring;
    };
    
    $.widget("gis.dataedit", {
        options: {
            entries: null, // <-- required
            
	        _vars: {
	        	// global vars within this widget
	        } 
        },
        
        _get_pane_id: function(x) {
            return this.options._vars.id + '_pane-' + x;
        },
        
        _fill_ul: function(opts) {
            for (var i in opts.entries) {
                var group = opts.entries[i],
                    li = $('<li>').append($('<a>').attr({
                        'data-toggle': 'tab',
                        'href': '#' + this._get_pane_id(i)
                    }).html(group.name));
                    
                if (i == 0) li.addClass('active');
                this.options._vars.ul.append(li);
            }
        },

        _fill_tab_group: function(parent, items) {
            var table = $('<table>').addClass('table table-striped table-bordered table-condensed'),
                tbody = $('<tbody>').appendTo(table);
            
            for (var i in items) {
                var it = items[i],
                    tr = $('<tr>'),
                    tdlabel = $('<td>').css({ width: '1%' }).append($('<strong>').html(it.label)),
                    tdval = $('<td>');
                
                if (it.type == 'bool') {
                    input = $('<input type="checkbox">').val('true');
                    if (it.value) input.attr({ checked: 'checked '});
                } else {
                    if (it.size == 'textarea') {
                        input = $('<textarea rows="3">').val(it.value);
                    } else {
                        input = $('<input type="text">').val(it.value);
                        if (it.size) input.addClass('input-' + it.size); else input.addClass('input-mini'); 
                    }
                }
                    
                input.attr({ placeholder: 'undefined' }).css({ 'margin-bottom': 0 }).data('item', it).appendTo(tdval);
                
                tbody.append(tr.append(tdlabel).append(tdval));
            }
            
            parent.append(table);
        },

        _fill_tabs: function(opts) {
            for (var i in opts.entries) {
                var group = opts.entries[i],
                    div = $('<div>').addClass('tab-pane fade').attr({
                        id: this._get_pane_id(i)
                    });

                this._fill_tab_group(div, group.items);
                if (i == 0) div.addClass('active in');
                this.options._vars.tabs.append(div);
            }
        },
        
        values: function() {
            var result = {};
            this.options._vars.tabs.find('input').each(function() {
                var it = $(this).data('item'),
                    val = $(this).val();
                    
                if (val && val != '') {
                    if (it.type == 'int') val = parseInt(val);
                    else if (it.type == 'float') val = parseFloat(val);
                    else if (it.type == 'bool') {
                        val = $(this).attr('checked') == 'checked';
                    }
                }
                
                result[it.id || it.label] = val;
            });
            return result;
        },
        
        _create: function() {
            var self = this,
                opts = this.options,
                el = $(this.element).addClass('tabbable tabs-left');
            
            this.options._vars.id = 'dataedit-' + random_ID();
            this.options._vars.ul = $('<ul>').addClass('nav nav-tabs').appendTo(el);
            this.options._vars.tabs = $('<div>').addClass('tab-content').appendTo(el);
            
            this._fill_ul(opts);
            this._fill_tabs(opts);
        }
    });
})(jQuery);
