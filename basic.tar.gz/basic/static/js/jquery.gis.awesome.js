/**
 * Awesome bar for genome navigation.
 * Fabi. Jul 2010.
 */
(function ($) {
    $.widget("gis.awesome", {
        options: {
            asm: null,
            width: null,
            location: null,
            // URL of service that parses genomic location
            url: null,
            hist_limit: 100,
            anchor: null // component [chromview] to be used as reference to determine location when 'pencil' is active
        },

        _init: function () {},

        _addCommas: function (val) {
            if (val < 1000) return val;
            var sValue = new String(val),
                sRegExp = new RegExp('(-?[0-9]+)([0-9]{3})');
            while (sRegExp.test(sValue)) {
                sValue = sValue.replace(sRegExp, '$1,$2');
            }
            return sValue;
        },

        _updateSpan: function () {
            var opts = this.options,
                viewSpan = opts._end - opts._start + 1;
            
            var can = $('#full_chrom_view_canvas');
            if (can != null) {
                var title = viewSpan > can.width() 
                            ? this._addCommas(Math.round(viewSpan/can.width()+0.5)) + " bases/pixel"
                            : this._addCommas(Math.round(can.width()/viewSpan+0.5)) + " pixels/bases";
                            
                opts._info.attr({
                    // hack to make it work with bootstrap's tooltip
                    'data-original-title': "Approx. " + title 
                });
            }
            opts._info.html(this._addCommas(viewSpan));
        },

        /**
         * 
         * @param loc: { chrom -> STR, start -> INT, end -> INT }
         * @param skipHistory Set to true by navigation buttons when invoking this function
         * @returns
         */
        setLocation: function (loc) {
            var opts = this.options;
            if (_.isObject(loc)) {
                if (loc.chrom != null) opts._chrom = loc.chrom;
                if (loc.start != null) opts._start = loc.start;
                if (loc.end != null) opts._end = loc.end;
                $(opts._input).val(opts._chrom + ":" + opts._start + "-" + opts._end);
            } else if (_.isString(loc)) {
                this._parse(loc, function() {
                    $(opts._input).val(opts._chrom + ":" + opts._start + "-" + opts._end);
                });
            }
            this._updateSpan();
        },

        _parse: function (text, fun) {
            var self = this;
            $.getJSON(self.options.url, {
                asm: self.options.asm,
                term: text
            }, function (data) {
                if (data.status === 'ERR') {
                    self._trigger('parseError', null, text);
                } else if (data.status === 'GENE') {
                    var l = data.gene;
                    $.publish(BASICEvent.NAV_ZOOM_TO, [ l.chrom, l.start, l.end ]);
                }
                else {
                    self.setLocation(data);
                    if (fun != null) fun();
                }
            });
        },

        _addPencil: function () {
            var self = this,
                opts = this.options;
            
            opts._pencil = $('<div>').addClass('pencil').appendTo($('#world')); // add to 'body'; easier to track

            var penhint = $('<div>').addClass('hint')
                                    .appendTo(opts._pencil),
                anchor = opts.anchor,
                ancdiv = anchor.find('>div');
            
            $(document).mousemove(function (ev) {
                if (opts._pencil.is(':visible')) {
                    opts._pencil.css({
                        left: ev.pageX+1,
                        top: $(window).scrollTop(),
                        height: $(window).height()
                    });
                    
                    var lb = anchor.chromview('leftDragBound'),
                        rb = anchor.chromview('rightDragBound')+3, // magico
                        w = rb-lb,
                        x = ev.pageX+1-ancdiv.offset().left; // also take into account the position of chromview in document
                    
                    if (x>=lb && x<=rb) {
                        penhint.css({
                            top: $(window).scrollTop() + ev.pageY - 5
                        }).html(self._addCommas(Math.round((opts._end-opts._start)*(x-lb)/w + opts._start))).show();
                    } else {
                        penhint.hide();
                    }
                }
            });
        },

        /* -----------------------
         *    NAVIGATION FUNCTIONS
         * ----------------------- */
        
        _shift: function(ev, direction) {
            $.publish(BASICEvent.NAV_GET_LOCATION, function(loc) {
                var span = loc.end - loc.start + 1,
                    delta = ev.ctrlKey ? ev.shiftKey ? 0.95 : 0.475 : 0.1;
                
                delta *= direction * span;
                $.publish(BASICEvent.NAV_ZOOM_TO, [loc.chrom, loc.start + delta, loc.end + delta]);
            });
        },

        _makeNavButtons: function() {
            var self = this,
                span = $("<span>").addClass('btn-group pull-left');

            $('<a>').attr({ title: 'Shift left' }).addClass('btn')
                .click(function(ev) { self._shift(ev, -1); })
                .tooltip({ placement: 'bottom' })
                .append($('<i>').addClass('icon-chevron-left'))
                .appendTo(span);

            $('<a>').attr({ title: 'Shift right' }).addClass('btn')
                .click(function(ev) { self._shift(ev, 1); })
                .tooltip({ placement: 'bottom' })
                .append($('<i>').addClass('icon-chevron-right'))
                .appendTo(span);
            
            return span.buttonset();
        },

        /* -----------------------
         *    ZOOM FUNCTIONS
         * ----------------------- */

        _zoomAll: function () {
            $.publish('gis.basic.bootstrap.getChromInfo', function(info) {
                $.publish(BASICEvent.NAV_GET_LOCATION, function(loc) {
                    $.publish(BASICEvent.NAV_ZOOM_TO, [ loc.chrom, 1, info.sizes[loc.chrom] ]);
                });
            });
        },

        _makeZoomButtons: function() {
            var self = this,
                span = $('<span>').addClass('btn-group pull-left');

            $('<a>').attr({ title: 'Show whole chromosome' }).addClass('btn').tooltip({ placement: 'bottom' })
                .click(function() { self._zoomAll(); })
                .append($('<i>').addClass('icon-resize-horizontal'))
                .appendTo(span);

            $('<a>').attr({ title: 'Zoom out' }).addClass('btn').tooltip({ placement: 'bottom' })
                .click(function() { $.publish(BASICEvent.NAV_ZOOM_OUT); })
                .append($('<i>').addClass('icon-zoom-out'))
                .appendTo(span);

            $('<a>').attr({ title: 'Zoom in' }).addClass('btn').tooltip({ placement: 'bottom' })
                .click(function() { $.publish(BASICEvent.NAV_ZOOM_IN); })
                .append($('<i>').addClass('icon-zoom-in'))
                .appendTo(span);
            
            return span;
        },
        
        /* -----------------------
         *  MISC
         * ----------------------- */
        
        _makeOtherButtons: function() {
            var self = this,
                opts = this.options,
                span = $('<span>').css({
                    'margin-right': '0.5em',
                    'float': 'left' 
                });

            $('<button>').addClass('btn').attr({
                id: 'awesome_pencil',
                title: 'Show/hide vertical line',
                'data-toggle': 'button'
            }).click(function() {
                var self = $(this);
                self.data('active', !(self.data('active') || false));
                if (self.data('active')) {
                    opts._pencil.show();
                }
                else {
                    opts._pencil.hide();
                }
            })
            .tooltip({ placement: 'bottom' })
            .append($('<i>').addClass('icon-eye-open'))
            .appendTo(span);
            
            return span;
        },
        
        hresize: function() {
            var el = this.element, 
                opts = this.options,
                div = $(el).find('>div');
            opts._input.css({
                width: div.width() - 430 - BASIConst.flot.labelWidth
            });
        },
        
        /* -----------------------
         *    ENTRY POINT
         * ----------------------- */
        
        _create: function () {
            var self = this,
                opts = this.options;

             // holder
            var daddy = $('<div>')
                    .addClass('basic-awesomebar well well-small')
                    .appendTo(this.element),
                    
                div = $('<div>')
                    .addClass('ui-helper-clearfix')
                    .css({
                        'margin-left': BASIConst.flot.labelWidth + 18 // magic; just take it by faith
                    }).appendTo(daddy);
            
            // pencil buttons
            this._makeOtherButtons().appendTo(div);
         
            // back + forward buttons
            this._makeNavButtons().appendTo(div);
            
            // textfield
            opts._input = $("<input>").addClass('text').attr({
                type: 'text'
            }).appendTo(div).change(function() {
                self._parse($(this).val(), function () {
                    $.publish(BASICEvent.NAV_ZOOM_TO, [opts._chrom, opts._start, opts._end]);
                });
            }).autocomplete({
                minLength: 3,
                source: function(request, response) {
                    $.getJSON(BASICService.GENE_AUTOCOMPLETE, { asm: opts.asm, term: request.term }, response);
                },
                select: function(ev, ui) {
                    $(this).trigger('change');
                }
            });

            this.hresize();
            
            // zoom in, out, all
            this._makeZoomButtons().appendTo(div);

            // shows how many bases represented by each pixel
            opts._info = $('<h4>').css({ 'margin': '5px 0 0 1em' }).addClass('pull-left')
                                  .tooltip({ placement: 'bottom' })
                                  .disableSelection()
                                  .appendTo(div);

            if (opts.location != null) this.setLocation(opts.location);

            this._addPencil();
        }
    });
})(jQuery);