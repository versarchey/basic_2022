/**
 * Provides API to perform operations on left panels
 */
BASIC.register('gis.basic.bookmarks', (function() {
    var global = null;
    
    var BOOKMARK_SERVICE = {
        LIST: '/basic/services/bookmarks/get/',
        ADD : '/basic/services/bookmarks/set/',
        DEL : '/basic/services/bookmarks/del/',
    };

    return {
        __init__: function(args) {
            global = args.global;
            app_url = args.APP_URL;

            var open_close = function(active_ids, new_ids) {
                // close all open tracks
                _.each(active_ids, function(trk_id) {
                    $.publish(BASICEvent.TRACK_MGR_REMOVE, trk_id);
                });
                // open tracks related to the bookmark
                _.each(new_ids, function(trk_id) {
                    $.publish(BASICEvent.TRACK_MGR_ADD, trk_id);
                });
            };
            
            var book_click_handler = function(ev, ui) {
                $.publish(BASICEvent.NAV_ZOOM_TO, [ui.book.chrom, ui.book.start, ui.book.end]);
                $.publish('gis.basic.tracklist.getActiveTrackIDs', function(active_ids) {
                    if (ui.book.tracks.length > 0) {
                        if (active_ids.length > 0) {
                            // confirm only when there are open tracks 
                            if (confirm('Replace currently opened tracks with the ones in the bookmark?')) {
                                open_close(active_ids, ui.book.tracks);
                            }
                        } else {
                            open_close(active_ids, ui.book.tracks);
                        }
                    }
                });
            };

            $.publish('gis.basic.panel.left.addTab', ['Bookmarks', '', function(tab) {
                tab.booky({
                    add_url: app_url + BOOKMARK_SERVICE.ADD,
                    list_url: app_url + BOOKMARK_SERVICE.LIST,
                    delete_url: app_url + BOOKMARK_SERVICE.DEL,
                    asm: global.asm,
                    click: book_click_handler
                });
            }]);
        },
        
        __deps__: function() {
            return ['gis.basic.panel.left', 'gis.basic.tracklist', 'gis.basic.trackmanager'];
        }
    };
})());

//START WIDGET ----------------------------------------------------------

(function ($) {
    $.widget("gis.booky", {
        options: {
            add_url: '', // required
            list_url: '', // required
            delete_url: '', // required
            asm: '', // required
            
            _vars: {
            	// "local" variables
            } 
        },

        refresh: function() {
            this._retrieveFromServer();
        },
        
        _makeAddButton: function() {
            var opts = this.options, vars = this.options._vars;
            return $('<button>')
                .addClass('btn')
                .attr({ id: 'add_booky' })
                .html(' Add Bookmark')
                .prepend($('<i>').addClass('icon-heart')).on('click', function() {
                    $.publish(BASICEvent.NAV_GET_LOCATION, function(loc) {
                        var locField = vars.dialog.find('input[name=loc]');
                        // refers to the HTML component created by _createDialogForm()
                        locField.data("value", loc).val(loc.chrom + ":" + loc.start + "-" + loc.end);
                        vars.dialog.modal('show');
                    }); 
                });
        },
                
        _refreshList: function() {
            var self = this,
                el = this.element,
                opts = this.options,
                vars = this.options._vars,
                content = vars.content;
            
            content.empty(); // clear the whole thing
            
            var bookmarks = vars.bookmarks;
            
            bookmarks.sort(function(p,q) {
                return (p.name.toLowerCase() < q.name.toLowerCase() ? -1 : 1);
            });
            
            _.each(bookmarks, function(book) {
                var divx = $('<div>').data('book', book).css({
                        cursor: 'pointer',
                        color: 'black',
                        'margin-bottom': '0.5em',
                        'background-color': '#f0f0f0',
                        'border-color': '#ccc'
                    }).addClass('alert fade in').appendTo(content).disableSelection();
                
                $('<div>').append($('<strong>').html(book.name)).appendTo(divx);
                $('<div>').append($('<i>').html(book.chrom + ':' + book.start + '-' + book.end)).appendTo(divx);

                if ((book.tracks || []).length > 0) {
                    var tracklist = $('<div>').css({ 'margin-top': '0.5em', 'font-size': '90%' }).appendTo(divx),
                        ul = $('<ul>').appendTo(tracklist);
                    
                    _.each(book.tracks, function(trk_id) {
                        $('<li>').html(opts._vars.trackdict[trk_id].name).appendTo(ul);
                    });
                }
                
                var close_button = $('<button class="close" type="button">&times;</button>')
                    .attr({ 'data-dismiss': 'alert' })
                    .click(function(ev) {
                        // to prevent location to change when bookmark is deleted
                        $(this).data('close_clicked', true);
                    });
                
                divx.prepend(close_button)
                    .bind('close', function(ev) {
                        var book = $(this).data('book');
                        $.post(opts.delete_url, { id: book.id }, function() { self.refresh(); });
                    }).click(function(ev) {
                        if (!close_button.data('close_clicked')) {
                            self._trigger("click", ev, { item: el, book: $(this).data('book') });
                        }
                    });
            });
            
            content.find('div.bookname').css({ 'color': 'black' });
            content.find('div.gloc').css({ 'color': '#777' });
        },
        
        _retrieveFromServer: function() {
            var self = this,
                opts = this.options;
        
            $.getJSON(opts.list_url, { asm: opts.asm }).done(function(bookmarks) {
                self.options._vars['bookmarks'] = bookmarks;
                self._refreshList();
            });
        },
        
        _addBookmark: function() {
            var self = this,
                opts = this.options,
                dialog = this.options._vars.dialog;
            
            $('input', dialog).removeClass('ui-state-error');
            
            var bookName = dialog.find('input:text[name=name]'),
                bookLoc = dialog.find('input:text[name=loc]'),
                saveTrx = dialog.find('input:checkbox[name=save_trx]');

            if (bookName.val() == '') {
                bookName.addClass('ui-state-error');
                return;
            }
            
            $.publish('gis.basic.tracklist.getActiveTrackIDs', function(track_ids) {
                if (!saveTrx.prop('checked')) track_ids = []; // don't save open tracks
                
                var params = $.extend({ name: bookName.val(), t: track_ids }, bookLoc.data('value'));
                
                $.post(opts.add_url, $.param(params, true), function() {
                    // refresh bookmark list and clear the forms
                    self.refresh();
                    $('input', dialog).val('');
                    saveTrx.prop('checked', false);
                    dialog.modal('hide');
                });
            });

        },
        
        _createDialogForm: function() {
            var html = [
                '<div class="modal hide fade">',
                '<div class="modal-header">',
                    '<h3>Add new bookmark</h3>',
                '</div>',
                '<div class="modal-body">',
                '<form><fieldset>',
                    '<label for="book_name">Bookmark name</label>',
                    '<input type="text" name="name" class="focus" />',
                    '<label for="book_loc">Location</label>',
                    '<input type="text" name="loc" value="" readonly="readonly" />',
                    '<label class="checkbox"><input name="save_trx" type="checkbox"> Save open tracks</label>',
                '</fieldset></form>',
                '</div>',
                '<div class="modal-footer">',
                    '<button id="bookmark_close" class="btn" data-dismiss="modal">Close</button>',
                    '<button id="bookmark_save" class="btn btn-primary">Save bookmark</button>',
                '</div>',
                '</div>'
            ].join('\n');
            
            var self = this,
                bookDialog = $(html).appendTo(this.element);
            
            $('#bookmark_save').click(function() {
                self._addBookmark();
            });
            $('#bookmark_close').click(function() { 
                $('input', bookDialog).val('').removeClass('ui-state-error') 
            });
            
            bookDialog.find('input:text[name=name]').keyup(function (ev) {
                if (ev.keyCode == 13) self._addBookmark();
            });
            
            return bookDialog;
        },
        
        _create: function() {
            var self = this,
                el = this.element,
                opts = this.options;
            
            // clear the playing field

            el.empty();
            var holder = $('<div>').appendTo(el);

            this.options._vars.dialog = this._createDialogForm();

            // must be called after _createDialogForm
            addButton = this._makeAddButton();
            addButton.appendTo(holder);
            this.options._vars['addbooky'] = addButton;
            
            // separator
            $('<div>').css({ 
                'border-bottom': '1px solid #ccc', 
                'margin-top': '0.8em',
                'margin-bottom': '1.8em'
            }).appendTo(holder);
            
            // this div will be emptied every time
            // new data is retrieved from server, or grouping/filtering is done
            opts._vars.content = $('<div>').appendTo(holder);
            
            $.publish(BASICEvent.TRACK_MGR_GET_TRACKLIST, function(tracklist) {
                opts._vars.trackdict = {};
                _.each(tracklist, function(x) {
                    opts._vars.trackdict[x.track_id] = x;
                });
                
                // retrieve for the first time
                self._retrieveFromServer();
            });
        }
    });
})(jQuery);