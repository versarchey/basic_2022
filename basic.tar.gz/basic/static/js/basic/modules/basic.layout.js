BASIC.register('gis.basic.layout', (function() {
  var global = null;
  
  function setupSeparators() {
    var left_panel_startlen = BASIC_local(BASICStorage.PANEL_LEFT_WIDTH) || 250,
        bottom_panel_startlen = BASIC_local(BASICStorage.PANEL_BOTTOM_HEIGHT) || 200;
    
    var lazy_fun_left = _.debounce(global.fun_left, 200);
    
    global.left_sep.addClass('ui-resizable-handle ui-resizable-e'); // required due to bug in JQuery UI
    global.left_panel.css({ width: left_panel_startlen }).resizable({
      handles: { e: global.left_sep },
      minWidth: 240,
      start: function() { global.no_panel_op = true; },
      resize: lazy_fun_left,
      stop: function() {
        // this is necessary to prevent event left_sep.click to happen after resize
        _.delay(function() { global.no_panel_op = false; }, 500);
        $.publish(BASICEvent.WIN_RESIZE);
        BASIC_local(BASICStorage.PANEL_LEFT_WIDTH, $(this).width());
      }
    });

    global.bottom_sep.addClass('ui-resizable-handle ui-resizable-n'); // required due to bug in JQuery UI
    global.bottom_panel.css({ height: bottom_panel_startlen }).resizable({
      handles: { n: global.bottom_sep },
      minHeight: 80,
      start: function() { global.no_panel_op = true; },
      resize: global.fun_bottom, 
      stop: function() {
        // CSS [top] must be removed for property [bottom] to take effect
        // and [width] must be re-set to relative value 100%
        $(this).css({ top: '', width: '100%' });
        // this is necessary to prevent event left_sep.click to happen after resize
        _.delay(function() { global.no_panel_op = false; }, 500);
        BASIC_local(BASICStorage.PANEL_BOTTOM_HEIGHT, $(this).height());
      }
    });

    global.left_sep.click(function() { $.publish(BASICEvent.PANEL_LEFT_TOGGLE); });
    global.fun_left();

    global.bottom_sep.click(function() { $.publish(BASICEvent.PANEL_BOTTOM_TOGGLE); });
    global.fun_bottom();
  }

  return {
    __init__: function(args) {
      global = args.global;
      setupSeparators();
    }
  };
})());