BASIC.register('gis.basic.ev.passwd', (function() {
    function setup() {
        /*
         * CHANGE PASSWORD
         */ 
        
        var passwd_modal = $('#chg_passwd_modal');
        $('form', passwd_modal).submit(function() {
            var curr = $('[name=curr]', this).val(),
                new1 = $('[name=new1]', this).val(),
                new2 = $('[name=new2]', this).val();
            
            if (curr === '' || new1 === '' || new2 === '') {
                $('.alert', passwd_modal).html('All three fields must not be empty').removeClass('hide');
            } else if (new1 !== new2) {
                $('[name=new1]', this).val('');
                $('[name=new2]', this).val('');
                $('.alert', passwd_modal).html('The two fields did not match').removeClass('hide');
            } else {
                $.post(BASICService.USER_CHANGE_PASSWD, { 'curr': curr, 'new': new1 }, function(data) {
                    if (data.status === 'OK') {
                        passwd_modal.modal('hide');
                    } else {
                        $('.alert', passwd_modal).html(data.message).removeClass('hide');
                    }
                }, 'json');
            }
            
            return false;
        });
        
        $('input', passwd_modal).keyup(function(ev) {
            if (ev.which === 13) $('form', passwd_modal).submit();
        });
        $('.submit', passwd_modal).click(function() {
            $('form', passwd_modal).submit();
        });
        
        $('#chg_passwd_link').click(function(ev) {
            ev.preventDefault();
            $('.alert', passwd_modal).addClass('hide');
            $('input', passwd_modal).val('');
            passwd_modal.modal('show');
        });
    }
    
    return {
        __init__: function(args, done) {
            setup();
        },
        
        __deps__: function() {
            return ['gis.basic.comsetup', 'gis.basic.corenav'];
        }
    };
})());