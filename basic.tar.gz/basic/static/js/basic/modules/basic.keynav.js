/**
 * Adds keyboard navigation functionality
 */
BASIC.register('gis.basic.keynav.panel', (function() {
  var ARROW = { LEFT: 37, RIGHT: 39 },
      SPACE = 32,
      keydown = false;

  return {
    __init__: function(args) {
      
      $(document).keydown(function(ev) {
      	if (ev.target.localName == 'input') return;
      	
        if (keydown) return;
        if (!(ev.which === ARROW.LEFT || ev.which === ARROW.RIGHT || ev.which === SPACE)) return;
        
        keydown = true;
        if (ev.which === SPACE) {
          // ctrl+space to auto-vresize all tracks
          if (ev.ctrlKey) $.publish(BASICEvent.TRACK_VRESIZE);
        } else {
          $.publish(BASICEvent.NAV_GET_LOCATION, function(loc) {
            var mod = ev.which === ARROW.LEFT ? -1 : 1,
                span = loc.end - loc.start + 1;
            
            var delta = ev.ctrlKey ? ev.shiftKey ? 0.95 : 0.475 : 0.1;
            delta *= mod * span;
            $.publish(BASICEvent.NAV_ZOOM_TO, [null, Math.round(loc.start+delta), Math.round(loc.end+delta)]);
          });
        }
      }).keyup(function(ev) {
        keydown = false;
      });
    }
  };
})());