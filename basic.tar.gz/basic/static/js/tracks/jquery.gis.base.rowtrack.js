/**
 * Base "class" for tracks that display data in rows, e.g. gene track, cluster track.
 * Fabi. Aug 2010.
 */
(function ($) {
    function _get(dict, key, altval) {
        return (dict == null) ? altval : (dict[key] || altval);
    }
    
    $.widget("gis.b_rowtrack", $.gis.abstrack, {
        
        options: {
            label: null, // either string (template), or function (returning string)
            glyph: {
                colors: "black",
                height: 8,
                prepad: 0,
                postpad: 0,
                hpad: 10, // distance between glyphs (used in intersection)
                clickable: false // if true, we must create a link layer
            }
        },

        _makeLabel: function(item, templ) {
            var opts = this.options, label = opts.label;
            if ((label == null || label === '') && templ == null) return '';
            if (templ != null) label = templ;
            
            if (_.isString(label)) {
                return $.tmpl(label, item).text(); // use template (TODO: use compiled template)
            } else if (_.isFunction(label)) {
                return label(item); // normal function
            }
            return ''; // catch-all
        },
        
        _getColor: function(colors, comp, item) { // comp <- (line|outline|fill)
            if (colors == null) return 'black'; // paranoid check
            var defaultValue = colors._ || 'black', // if specific type is not found, use wildcard "_"
                    c = colors[comp] || defaultValue;
            
            if (!_.isFunction(c)) return c;
            
            var args = $.extend({
                comp: comp, // component type
                element: item,
                
                cluster: item, // for backward compatibility
                tag: item // for backward compatibility
            });
            return c(args) || defaultValue; // in case the function doesn't return valid value
        },

        _intersects: function(dim1, dim2) {
            var pad = this.options.glyph.hpad,
                    p = dim1.start - pad,
                    q = dim1.end + pad,
                    m = dim2.start - pad,
                    n = dim2.end + pad;
            return p < n && q >= m;
        },

        _noIntersection: function(dim, group) {
            for (var i = 0; i < group.length; i++) {
                if (this._intersects(group[i], dim)) return false;
            }
            return true;
        },

        _determineRow: function(dim, groups) {
            for (var i = 0; i < groups.length; i++) {
                if (this._noIntersection(dim, groups[i])) {
                    groups[i].push(dim);
                    return i;
                }
            }
            // must be placed in a new row
            groups.push([dim]);
            return groups.length - 1;
        },

        _clearCanvas: function(canvas, linklayer) {
            var ctx = canvas.getContext("2d");
            ctx.clearRect(0, 0, $(canvas).width(), $(canvas).height());
            if (linklayer) {
                linklayer.css({
                    height: $(canvas).height(),
                    width: $(canvas).width()-16
                }).empty();
            }
        },

        _createLayer: function(canvasHolder) {
            var canvas = canvasHolder.find(">canvas");
            return $("<div>").css({
                position: "absolute",
                top: canvas.position().top,
                left: canvas.position().start,
                width: canvas.width()-16,
                height: canvas.height(),
                'overflow-x': 'hidden',
                'overflow-y': 'hidden',
                margin: 0
            }).mousewheel(function(ev, d, dx, dy) {
                var top = canvasHolder.scrollTop();
                canvasHolder.scrollTop(top - 36 * d);
                if (top !== canvasHolder.scrollTop()) ev.preventDefault();

            }).appendTo(canvasHolder);
        },

        _createCanvas: function(data) {
            var opts = this.options,
                prepad = opts.glyph.prepad,
                postpad = opts.glyph.postpad,
                h = opts.glyph.height,
                cvs_holder = opts._canvas;
            
            var canvas = $(cvs_holder).data('canvas');
            
            if (canvas == null) {
                // avoid re-creating canvas if it's already present
                canvas = $("<canvas>").attr({
                    width: cvs_holder.width(),
                    height: (h + prepad + postpad) * data.length
                }).appendTo(cvs_holder);
                
                cvs_holder.scroll(function () { // must sync link layer with canvas scrolling
                    var link_layer = cvs_holder.find(">div");
                    link_layer.css({ top: canvas.position().top });
                });
                
                cvs_holder.data('canvas', canvas);
            }
            return canvas;
        },
        
        drawPlotX: function(items, quick) {
            var opts = this.options,
                start = opts.location.start,
                end = opts.location.end,
                cvs_holder = opts._canvas,
                linklayer = null;

            var links = []; // returned at the end of function; so this plugin can't be chained
            
            var colors_ = opts.colors || 'black',
                colors = _.isObject(colors_) 
                                     ? colors_ // if head/tail/line is missing, wildcard/default color will be used (see _getColor)
                                     : { _: colors_ }; // set wildcard if it's either string or function

            var prepad = opts.glyph.prepad,
                    postpad = opts.glyph.postpad,
                    h = opts.glyph.height;

            var canvas = this._createCanvas(items),
                    w = canvas.width();

            // check if quickdraw is requested
            if (!quick) {
                if (opts.glyph.clickable) {
                    linklayer = cvs_holder.data("linkLayer");
                    if (!linklayer) {
                        linklayer = this._createLayer(cvs_holder);
                        cvs_holder.data("linkLayer", linklayer);
                    }
                }
                // reset item placement data, so that they'll be recalculated
                cvs_holder.data("rows", {});
            }

            var ratio = w/(end-start+1),
                    _c = function(x1) { return (x1 - start) * ratio; }; // convert genome location to canvas coordinate

            var groups = [],
                // stores mapping {item local ID -> row number}
                rows = cvs_holder.data("rows"),
                 // used in quickdraw so that we don't need to recompute layout
                cnv_elem = canvas.get(0);

            canvas.hide();
            this._clearCanvas(cnv_elem, linklayer);

            var rowcount = 0, k = 0; // running number
            
            // determine layout
            for (var i = 0; i < items.length; i++, k++) {
                var item = items[i];
                if (rows[k] == null) {
                    rows[k] = this._determineRow(this._measureWidth(cnv_elem, w, item, _c), groups);
                }
                if (rowcount < rows[k]) rowcount = rows[k];
            }

            // resize canvas and redraw
            $(cnv_elem).attr({
                height: (h + prepad + postpad) * (rowcount + 2)
            });

            k = 0; // restart from 0
            for (var i = 0; i < items.length; i++, k++) {
                var item = items[i], r = rows[k];
                this._drawItem(cnv_elem, 0, r * (h + postpad) + prepad * (r + 1), w, h, item, colors, _c, quick);
                if (!quick && this._addLinks) {
                    var link = this._addLinks(linklayer, cnv_elem, r * (h + postpad) + prepad * (r + 1), w, h, postpad, item, _c);
                    links.push([item, link]);
                }
            }
            canvas.show();

            return links;
        },

        // hooks to override
        _prePlot: function(is_quick, callback) { if (callback != null) callback(); },
        _postPlot: function(is_quick, callback) { if (callback != null) callback(); },
        
        // @Override
        _drawPlot: function(values, quick) {
            var opts = this.options,
                loc = opts.location;
            
            if (!values) values = opts._values;
            opts._canvas.css({
                height: opts._canvas.height(),
                width:    opts._canvas.width()
            });
            
            var self = this;
            self._prePlot(quick, function() {
                var links = self.drawPlotX(values, quick);
                self._postPlot(quick, function() {
                    if (quick) return;
                    for (var i = 0; i < links.length; i++) {
                        (function() {
                            var link = links[i][1], item = links[i][0];
                            var which = 'whole';
                            if (item.chrom2 != null && item.chrom != item.chrom2) {
                                which = item.chrom == loc.chrom ? 'head' : 'tail';
                            }
                            link.click(function (ev) { self._trigger("click", ev, { item: item, which: which }); });
                        })();
                    }
                });
            });
        },

        // @Override
        _quickRefresh: function () {
            if (this.options._isHidden) return;
            if (!this.options._prevLocation) return;
            this._drawPlot(null, true);
        },

        // To be overridden by "subclass"
        // The implementation modifies the list directly
        _preprocess: function(items) {},
        
        // To be overridden by "subclass"
        // The implementation must return an array of sorted items
        _sortItems: function(items, start, end, view) { // view: viewed region {chrom,start,end}
            return items; // default: do nothing
            // return items.sort(function(p, q) {});
        },

        // @Override
        _modParams: function(params) {
            if (this.options.source) {
                // HACK: This is a very crude way to say that there's a "source" defined
                // so that the backend will respond differently
                params.srckey = 'hack';
            }
        },

        _alertTooMuch: [
            '<div class="alert alert-error">',
            '<strong> Oh snap!</strong> There are too many items to be displayed.',
            'Please try viewing a smaller region.</div>'
        ].join('\n'),
        
        // @Override
        _fullRefresh: function (forced) {
            var opts = this.options;
            if (opts._isHidden) return;
            if (!opts._dirty && !forced) return;

            // override any options set in codes with options in configuration (part of track's [options] metadata)
            var _tmpOpts = BASIC_recurseval(opts.options);
            opts.options = null;
            $.extend(true, opts, _tmpOpts); // deep copy
            
            var maxpets = opts.limit,
                    l = opts.location.start,
                    r = opts.location.end,
                    params = {
                        tid: opts.track_id, // @deprecated
                        track_id: opts.track_id,
                        chrom: opts.location.chrom,
                        start: l,
                        end: r,
                        max: maxpets + 1, // @deprecated
                        limit: maxpets + 1 // to detect that the limit is exceeded
                    };

            this._modParams(params);
            
            // keep previous values
            opts._prevLocation = $.extend({}, opts.location);

            var self = this;
                
            return $.Deferred(function(def) {
                $.getJSON(opts.url, params, function (data) {
                    opts._canvas.find('div.alert').remove();
                    if (data.length > maxpets) {
                        data = data.splice(0, maxpets); // truncate
                        opts._canvas.prepend($(self._alertTooMuch));
                    }
    
                    if (self._preprocess) self._preprocess(data);
                    if (self._sortItems) data = self._sortItems(data, l, r, { chrom: opts.location.chrom, start: l, end: r }); 
    
                    opts._values = data;
                    self._drawPlot();
                    opts._dirty = false;
                    self._trigger("refresh", null, {
                        self: self.element,
                        start: opts.location.start,
                        end: opts.location.end
                    });
                    def.resolve();
                }).error(function() { 
                    def.reject(); 
                });
            }).promise();
        } //end fullRefresh
    });
})(jQuery);