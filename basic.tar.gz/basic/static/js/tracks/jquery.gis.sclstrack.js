/**
 * Fabi. Aug 2010.
 */
(function ($) {
  var _drawAnchor = $.gis.basic.helpers.plot._drawClusterAnchor;
  var 
    _DEFAULT_GLYPH_HEIGHT = 8,
    _DEFAULT_GLYPH_POSTPAD = 12;

  $.widget("gis.sclstrack", $.gis.b_rowtrack, {

    options: {
      showLabel: false,
      label: '${label} (${score})',
      tooltip: '${chrom}:${start}-${end} (${score})',
      glyph: {
        colors: "black",
        height: _DEFAULT_GLYPH_HEIGHT,
        prepad: 0,
        postpad: _DEFAULT_GLYPH_POSTPAD,
        clickable: true
      }
    },
    
    _preprocess: function(items) {
      for (var i in items) {
        var it = items[i];
        it._text = this._makeLabel(it);
        it._tooltip = this._makeLabel(it, this.options.tooltip);
      }
      this.options.glyph.postpad = this.options.showLabel ? _DEFAULT_GLYPH_POSTPAD : 2;
    },
    
    _sortItems: function(items, start, end) {
      // default sort: score desc, start asc
      return items.sort(function(p,q) {
        var x = q.score-p.score;
        if (x != 0) return x;
        return p.start-q.start;
      });
    },

    _drawItem: function(canvas, x, y, w, h, scls, colors, c) {
      var ctx    = canvas.getContext("2d"),
          hRatio = h / 8,
          cstart = Math.max(1, c(scls.start)),
          cend   = Math.min(w, c(scls.end+1));

      ctx.save();
      ctx.translate(0, y + h / 2);
      ctx.lineWidth = 1;

      ctx.strokeStyle = this._getColor(colors, "outline", scls);
      ctx.fillStyle = this._getColor(colors, "fill", scls);

      var prot = 0;
      if (scls.strand == "+") prot = 1; else if (scls.strand == "-") prot = -1;
      _drawAnchor(ctx, cstart, -3 * hRatio, cend-cstart, 6 * hRatio, prot, prot);

      if (this.options.showLabel) {
        // 5. write symbol/accession
        ctx.fillStyle = this._getColor(colors, "text", scls);
        ctx.font = "normal 9px sans-serif";
        ctx.textAlign = "left";
        ctx.fillText(scls._text, cstart, 6 * hRatio + 6);
      }
      
      ctx.restore();
    },

    _measureWidth: function(canvas, w, scls, c) {
      // determine which part of canvas will be used to draw given scls
      var ctx    = canvas.getContext("2d"),
          cstart = Math.max(1, c(scls.start)),
          cend   = Math.min(w, c(scls.end+1)),
          actualWidth = Math.max(cend-cstart, this.options.showLabel ? ctx.measureText(scls._text).width : 0);

      return { start: cstart, end: cstart + actualWidth };
    },

    _addLinks: function(parent, canvas, y, w, h, postpad, scls, c) {
      // determine which part of canvas will be used to draw given scls
      var ctx  = canvas.getContext("2d");

      var cstart = Math.max(1, c(scls.start)),
          cend   = Math.min(w, c(scls.end+1)),
          actualWidth = Math.max(cend-cstart, this.options.showLabel ? ctx.measureText(scls._text).width : 0);
          left = cstart;

      var elem = $("<div>").css({
        position: "absolute",
        top: y,
        left: left,
        //"background-color": "rgba(255, 0, 0, 0.3)",
        width: actualWidth,
        height: h + postpad,
        cursor: "pointer"
      }).attr({
        title: scls._tooltip
      }).appendTo(parent);
      return elem;
    }
  });
})(jQuery);