/**
 * Abstract track. To be derived by other track widgets.
 * Shows visualized genomic data.
 * Fabi. Jul 2010.
 */
(function ($) {
    var _autoId = 0,
        _slideStart = {},
        _noSlidePlz = false;
    
    var _resizeToFit = function(args) {
        var comp = args.comp, 
            track = args.track,
            opts = comp.options,
	        icon = $(track).find("span:contains('resize')");
        
        if (icon.hasClass("ui-icon-arrowthick-2-e-w")) {
            opts._h = opts._canvas.height();
            h = opts._canvas.find("canvas").height();
        } else {
            h = opts._h; // get previous height
        }
        
        opts._content.css({ height: h });
        opts._canvas.css({ height: h }); // this is actually canvas holder
        comp._adjustTitle(1);
        comp._resize();
    };

    $.widget("gis.abstrack", {
        // CONSTANTS (referred to by tracks subclassing this)
        
        /**
         * DATA
         * _track
         * _canvas
         * _location
         * _dirty (whether the plot has to be redrawn)
         * _values (values to be used for plotting)
         */
        
        // OPTIONS
        options: {
            tid: null, // @deprecated
            track_id: null,
            // used when making AJAX query; to be supplied by caller
            title: "N/A",
            height: 100,
            _isHidden: false
        },
        
        // appear when mouse hovers on track header on the right
        _buttons: [{
            caption: 'Resize track to fit',
            event: 'resize',
            icon: 'ui-icon-arrowthick-2-e-w',
            handler: _resizeToFit
        }, {
            caption: 'Close this track',
            event: 'close',
            icon: 'ui-icon-close',
            handler: function(args) { 
                args.comp.close(); 
            }
        }], //end _buttons
        
        // appear when mouse hovers on track body
        _toolbars: [{
            caption: 'Configure track',
            icon: 'icon-wrench',
            handler: function (self) {
                self._trigger('config', null, { item: self.element });
            }
        }, {
            caption: 'Show table',
            icon: 'icon-th-list',
            handler: function (self) {
                self._trigger('table', null, { item: self.element });
            }
        }], //end _toolbars

        _drawPlot: function (values) {
            // @Overridden
        },
        
        enableSlide: function() { _noSlidePlz = false; },
        disableSlide: function() { _noSlidePlz = true; },

        _createContent: function (trackId) {
            var self = this,
	            opts = this.options,
    	        track = opts._track;
	
            // ---------------------------
            //    TRACK
            // ---------------------------

            track.disableSelection()
                 .bind('contextmenu', function (e) { return false; })
                 .addClass('ui-dialog ui-widget-content ui-corner-all basic-track');
            
            // ---------------------------
            //    TITLE
            // ---------------------------
            
            var trackTitle = $('<div>')
            	.attr({ id: trackId + "_title" })
	            .addClass("basic-title-holder ui-dialog-titlebar ui-helper-clearfix ui-corner-all")
	            .css({
	                left: track.position().left + track.width() + 15, // magic number
	                width: track.height() - 12, // magic number
	                position: 'absolute',
	                bottom: 2
	            })
	            .disableSelection()
	            .appendTo(track);
            
            $('<span>').attr({ title: opts.title })
			           .addClass("basic-title ui-dialog-title")
			           .html(opts.title)
			           .disableSelection()
			           .appendTo(trackTitle);
            
            var buttContainer = $('<div>').css({
                width: 20*this._buttons.length
            }).addClass('buttons').appendTo(trackTitle).hide();
            
            this._addButtons(buttContainer);
            trackTitle.hover(function() { buttContainer.show(); }, 
                             function() { buttContainer.hide(); });

            // ---------------------------
            //    CONTENT
            // ---------------------------
            
            var trackContent = $('<div>').attr({ id: trackId + "_content" })
                .addClass("basic-content ui-dialog-content ui-widget-content")
                .resizable({
                    handles: "s",
                    resize: function() {
                        $("#" + trackId + "_canvas").css({ height: $(this).height() });
                        self._adjustTitle(0);
                        self._resize();
                    },
                    start: self.disableSlide,
                    stop: function() { self.enableSlide(); $("#" + trackId + "_content").css({ width: '' }); }
                }).appendTo(track);

            // ---------------------------
            //    TOOLBAR
            // ---------------------------

            var toolbar = $('<div>').addClass('track-toolbar btn-group').css({
                left: BASIConst.flot.labelWidth + 20, // magic
                'font-size': '100%' // to counter funny effect of font-size=0
            }).hide();
            
            toolbar.mouseenter(function() {
                // cancel auto-hide toolbar
                $(this).css({ opacity: 1 });
                $.schedule('/hide-toolbar/' + trackId, 0, function() {});
            }).mouseleave(function() {
                $(this).css({ opacity: 0.5 });
                $.schedule('/hide-toolbar/' + trackId, 2000, function() { toolbar.hide(); });
            }).appendTo(trackContent);

            // reordering handle
            $('<span>').attr({ title: 'Drag to reorder this track' })
	  		           .tooltip()
			           .click(function() { self.disableSlide(); })
			           .addClass('badge badge-important ordering-handle')
			           .append($('<i>').addClass('icon-move icon-white'))
			           .appendTo(toolbar);

            for (var i in this._toolbars) {
                (function() {
                    var b = self._toolbars[i];
                    $('<button>').attr({ title: b.caption })
                    .addClass('btn').click(function() { b.handler(self); })
                    .append($('<i>').addClass(b.icon)).tooltip()
                    .appendTo(toolbar);
                })();
            }
            
            trackContent.hover(function() {
                $.schedule('/show-toolbar/' + trackId, 300, function() { 
                    toolbar.css({ opacity: 0.5 }).show(); 
                    $.schedule('/hide-toolbar/' + trackId, 2000, function() {
                        toolbar.hide(); // hide in 2 seconds, unless users hover on it
                        $(this).removeClass('resize-guide');
                    });
                });
                $(this).addClass('resize-guide'); // guide for resizing
            }, function() {
                $.schedule('/show-toolbar/' + trackId, 0, function() { toolbar.hide(); });
                $(this).removeClass('resize-guide');
            });
            
            // ---------------------------
            //    CANVAS
            // ---------------------------

            var trackCanvas = $('<div>').attr({ id: trackId + '_canvas' }).css({
                height: opts.height,
                'margin-left': BASIConst.flot.labelWidth + 5, // magic
            }).addClass('basic-canvas')
            .appendTo(trackContent);
            
            // ---------------------------
            //    MISC
            // ---------------------------

            opts._spinner = $("<div>")
                    .addClass("spinner")
                    .css({
                        position: "absolute",
                        left: 8,
                        top: 8,
                        "z-index": 10000
                    }).appendTo(track);
            
            return {
                title: trackTitle,
                content: trackContent,
                canvas: trackCanvas
            };
        },

        /*
         * HORIZONTAL RESIZE 
         */ 
        hresize: function() {
            var opts = this.options,
                track = this.element, 
                title = opts._title,
                gapsize = opts._gapsize; // somehow required for correct h-resize of non-coverage tracks
            
            title.css({
                left: track.position().left + track.width() + 15 // magic number
            });
            
            var canvasHolder = opts._canvas,
                canvasEl = canvasHolder.find('canvas');

            canvasHolder.css({ 
                width: canvasHolder.parent().width() - gapsize // the value is set _once_ on full refresh 
            });
            
            canvasEl.attr({ width: canvasHolder.width() });
            this._fullRefresh(true);
        },

        vresize: function() { // invoked in response to track-resize broadcast
            _resizeToFit({ comp: this, track: this.options._track });
        },
        
        /*
         * VERTICAL RESIZE
         */ 
        _resize: function () {
            // by default, do nothing
            // only coverage-type tracks would want to redraw
        },

        setChromosome: function (chrom, size) {
            this.options.location.chrom = chrom;
            this.options.location.size = size;
        },

        setLocation: function (start, end) {
            var lPos = Math.round(start),
                rPos = Math.round(end);

            var loc = this.options.location,
                l = Math.min(Math.max(1, lPos), loc.size),
                r = Math.min(Math.max(1, rPos), loc.size);

            // boundary checks
            if (r != rPos) {
                l = Math.min(Math.max(1, l + r - rPos), loc.size);
            } else if (l != lPos) {
                r = Math.min(Math.max(1, r + l - lPos), loc.size);
            }

            loc.start = l;
            loc.end = r;
            this.options._dirty = true;
        },

        _start: function(e) {
            // start sliding
            var loc = this.options.location;
            _slideStart = { start: loc.start, end: loc.end };
            this._trigger("start", e, {
                self: this.element,
                start: loc.start,
                end: loc.end
            });
        },

        quickRefresh: _.throttle(function() {
            this._quickRefresh();
        }, 20),

        // @Overridde
        _quickRefresh: function () {},

        _slide: function (e, delta) {
            /*
             * Triggered during panning to allow smooth animation.
             */
            if (delta === 0 || _noSlidePlz) return;
            loc = this.options.location;

            this.setLocation(loc.start - delta, loc.end - delta);
            _slideStart = { start: loc.start, end: loc.end };

            this.quickRefresh();
            this._trigger("slide", e, {
                self: this.element,
                delta: delta,
                start: loc.start,
                end: loc.end
            });
        },

        _stop: function (e) {
            // stop sliding
            var loc = this.options.location;
            if (_slideStart.start === loc.start && _slideStart.end === loc.end) return;
            
            this._trigger("stop", e, {
                self: this.element,
                start: loc.start,
                end: loc.end
            });
        },

        _makePannable: function () {
            var self = this, opts = this.options;
            opts._canvas.mousedown(function(e) {
                if (e.which == 1 || e.which == 3) { // left or right button to drag
                    if (_noSlidePlz) return;
                    self._mouseX = e.pageX;
                    self._mouseWeight = (self.options.location.end - self.options.location.start) / self.options._track.width();
                    self._start(e);
                }
            }).mousemove(function (e) {
                if (!self._mouseX) return;
                var delta = e.pageX - self._mouseX;
                self._mouseX = e.pageX;

                $(this).addClass(delta < 0 ? 'slide-left' : 'slide-right');

                delta *= self._mouseWeight;
                self._slide(e, delta);
            });
            
            opts._track.bind("mouseup mouseleave", function(ev) {
                if (!self._mouseX) return;
                ev.preventDefault();
                self._mouseX = null;
                opts._canvas.removeClass('slide-left slide-right');
                self._stop(ev);
            });
            opts._canvas.scroll(function(ev) {
                if (!self._mouseX) return;
                self._mouseX = null;
                $(this).removeClass('slide-left slide-right');
            });
        },

        _addButtons: function (buttContainer) {
            var self = this,
                    buttons = this._buttons,
                    track = this.options._track;
            
            for (var i = buttons.length - 1; i >= 0; i--) {
                (function () { // use closure because we're in a loop
                    var b = buttons[i];
                    var anchor = $('<a>').attr({
                        title: b.caption
                    }).click(function() {
                        b.handler({ comp: self, track: track, me: this });
                    })
                    .addClass('button')
                    .disableSelection()
                    .appendTo(buttContainer);
                    
                    $('<span>').disableSelection()
                               .addClass('ui-icon ' + b.icon)
                               .html(b.event).appendTo(anchor);
                })();
            }
        },

        _adjustTitle: function(modifier, onfinish) {
            var track = this.element,
                    opts = this.options;
            
            opts._title.css({
                width: track.height() - 12 // magic number
            });
            if (onfinish) onfinish();
        },

        _alertServerError: [
            '<div><div class="alert alert-error">',
            '<strong> Oh snap!</strong> The request for data to the server failed. ',
            'This may be due to configuration errors or missing files.</div></div>'
        ].join('\n'),

        fullRefresh: function(forced) {
            var self = this, opts = this.options;
            opts._spinner.show();
            opts._canvas.find('div.alert').remove();
            this._fullRefresh(forced).always(function() {
                opts._spinner.hide();
                if (! opts._gapsize) {
                    // determine the width difference between _content and _canvas to be used for horizontal resizing
                    opts._gapsize = opts._content.width()-opts._canvas.width();
                }            
            }).fail(function() {
                $(self._alertServerError).css({ 
                    height: opts._track.height(), 
                    'margin-left': BASIConst.flot.labelWidth + 5, 
                    'margin-right': 3
                }).prependTo(opts._canvas); 
            });
        },

        // @Override
        _fullRefresh: function (forced) { /* must return $.Deferred() */ },

        setOptionsConfig: function(config) {
            this.options.options = BASIC_recurseval(config || {});
        },

        setSeriesConfig: function(config) {
            this.options.series = BASIC_recurseval(config || {});
        },

        _init: function () {},

        close: function () {
            var self = this, el = this.element;
            this._trigger("close", null, { item: el });
            
            this.options._track.fadeOut(function () {
                $(this).remove();
                self._trigger("closed", null, { item: el });
            });
        },

        destroy: function () {
            this.options._track.unbind();
        },

        _create: function () {
            var opts = this.options;
            opts._track = $(this.element);
            var trackId = opts._track.attr("id");

            if (!trackId) {
                trackId = "track_" + (_autoId++);
                opts._track.attr({ id: trackId });
            }

            var xyz = this._createContent(trackId);
            opts._content = xyz.content;
            opts._canvas = xyz.canvas;
            opts._title = xyz.title;

            this._makePannable();
            this._adjustTitle(0);

            opts._dirty = true;
        }
    });
})(jQuery);