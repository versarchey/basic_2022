/**
 * Fabi. Mar 2011.
 */
(function ($) {
  var EXTLEN = 5; // length of tags drawn in number of pixels
  var _drawAnchor = $.gis.basic.helpers.plot._drawTagAnchor;

  $.widget("gis.stagtrack", $.gis.b_rowtrack, {

    options: {
      caption: null, // default: no caption
      glyph: {
        colors: "black",
        height: 6,
        prepad: 0,
        postpad: 0,
        hpad: 2, // distance between glyphs (used in intersection)
      }
    },
    
    _drawItem: function(canvas, x, y, w, h, stag, colors, c) {
      var ctx = canvas.getContext("2d"),
          hRatio = h / 8;

      ctx.save();

      ctx.translate(0, y + h / 2);
      ctx.lineWidth = 1;

      ctx.strokeStyle = this._getColor(colors, "arrow", stag.strand);
      var cstart = c(stag.pos), cend;
      var prot = [0, 0];
      if (stag.strand == "+") {
        prot = [0, 1];
        cend = cstart+EXTLEN-1;
      }
      else {
        prot = [-1, 0];
        cend = cstart; cstart -= EXTLEN-1;
      }
      _drawAnchor(ctx, cstart, -3 * hRatio, cend-cstart, 6 * hRatio, prot[0], prot[1]);

      ctx.restore();
    },

    _measureWidth: function(canvas, w, stag, c) {
      var cstart, cend;
      if (stag.strand == "+") {
        cstart = c(stag.pos);
        cend = cstart + EXTLEN-1;
      } else {
        cend = c(stag.pos);
        cstart = cend - EXTLEN+1;
      } 
      return { start: cstart, end: cend };
    }
  });
  
})(jQuery);