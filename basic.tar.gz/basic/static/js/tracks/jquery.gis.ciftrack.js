/**
 * Shows visualized genomic data.
 * Fabi. Jul 2010.
 */
(function ($) {
    function _get(dict, key, altval) {
        return (dict == null) ? altval : (dict[key] || altval);
    }

    // extend from covtrack
    $.widget("gis.ciftrack", $.gis.covtrack, {
        _makeInitialRequest: function (url, source, params) {
            var self = this,
                opts = self.options,
                urls = {};
            
            for (var i in source) {
                var minsupAbs = _get(opts._series, i, {}).abs_minsup,
                        minsupRel = _get(opts._series, i, {}).rel_minsup;
                
                var msupAbs2 = null, msupRel2 = null;
                if (typeof(minsupAbs) === 'object') {
                    msupAbs2 = minsupAbs[1];
                    minsupAbs = minsupAbs[0];
                }
                if (typeof(minsupRel) === 'object') {
                    msupRel2 = minsupRel[1];
                    minsupRel = minsupRel[0];
                }
                
                var tmp = { 
                    abs: { subkey: 'abs', srckey: i, thres: minsupAbs }, // absolute (number of tags)
                    rel: { subkey: 'rel', srckey: i, thres: minsupRel }, // relative (mC/(mC+uC))
                    mix: { subkey: 'mix', srckey: i, thres: minsupRel }    // both conditions (but absThres is fixed during data structure construction)
                };
                
                if (msupAbs2 != null) tmp.abs2 = { subkey: 'abs', srckey: i, thres: msupAbs2 };
                if (msupRel2 != null) tmp.rel2 = { subkey: 'rel', srckey: i, thres: msupRel2 };
                if (msupRel2 != null) tmp.mix2 = { subkey: 'mix', srckey: i, thres: msupRel2 };
                
                urls[i] = {};
                for (var j in tmp) {
                    urls[i][j] = url + '&' + $.param(tmp[j]);
                }
            }
            
            var _defaultFormula = function(abs, rel, mix) {
                return rel;
            };

            var deferred = $.Deferred();
            BASIC_getMultiJSON(urls, params).done(function (xdata) {
                var xvalues = [],
                    l = params.start,
                    r = params.end,
                    w = params.w,
                    step = (r - l) / w;

                var ylog = _get(_get(opts._options, "yaxis", {}), "log");
                for (var k in xdata) {
                    var values = [],
                        data = xdata[k];

                    // modifier
                    var negate = _get(opts._series, k, {}).negate,
                        // translates minsup(abs,rel) to number to be shown on browser
                        formula = BASIC_recurseval(_get(opts._series, k, {}).formula) || _defaultFormula;

                    for (var i = 0; i < w; i++) {
                        var vAbs = data.abs[i],
                            vRel = data.rel[i],
                            vMix = data.mix[i];
                        
                        if (data.abs2 != null) vAbs -= data.abs2[i];
                        if (data.rel2 != null) vRel -= data.rel2[i];
                        if (data.mix2 != null) vMix -= data.mix2[i];
                        var v = formula(vAbs, vRel, vMix);
                        
                        if (ylog && v>0) v = Math.log(v)/Math.log(ylog);
                        if (negate) v = -v;
                        values.push([i * step + l, v]);
                    }

                    xvalues.push($.extend(_get(opts._series, k, {}), { data: values }));
                }

                self.options._xvalues = xvalues;

                self._drawPlot();
                self.options._dirty = false;
                self._trigger("refresh", null, {
                    self: self.element,
                    start: self.options.location.start,
                    end: self.options.location.end
                });

                deferred.resolve();
            }).fail(function() { 
                deferred.reject(); 
            });
            
            return deferred.promise();
        }
    });
})(jQuery);