/**
 * Common functions used by plotters of tracks that render their own canvas
 */
(function ($) {
  if ($.gis.basic == null) $.gis.basic = {};
  if ($.gis.basic.helpers == null) $.gis.basic.helpers = {};
  
  $.gis.basic.helpers.plot = {
    _createCanvas: function(options, canvasHolder) {
      var data = options.data,
          prepad = options.prepad,
          postpad = options.postpad,
          h = options.height;
      
      var canvas = $(canvasHolder).data('canvas');
      
      if (canvas == null) {
        // avoid re-creating canvas if it's already present
        canvas = $("<canvas>").attr({
          width: canvasHolder.width(),
          height: (h + prepad + postpad) * data.length
        }).appendTo(canvasHolder);
        
        canvasHolder.scroll(function () { // must sync link layer with canvas scrolling
          var linkLayer = canvasHolder.find(">div");
          linkLayer.css({ top: canvas.position().top });
        });
        
        canvasHolder.data('canvas', canvas);
      }
  
      return canvas;
    },
    
    _drawHLine: function(ctx, x0, x1, y, pattern) {
      if (x0 > x1) { var tmp = x0; x0 = x1; x1 = tmp; }
      if (! pattern) pattern = [3,2]; // 3px stroke, 2px gap
      
      var p_idx = 0,
          p_len = pattern.length,
          x = x0,
          draw = true;

      ctx.save();
      ctx.lineWidth = 0.5; 
      ctx.beginPath();
      if (x1 - x0 < 8) {
        // special case for short distance
        ctx.moveTo(x0, y);
        ctx.lineTo(x1, y);
      } else {
        while (x < x1) {
          ctx.moveTo(x, y);
          x = Math.min(x + pattern[p_idx], x1);
          if (draw) ctx.lineTo(x, y);
          draw = !draw;
          p_idx += 1;
          if (p_idx >= p_len) p_idx = 0;
        }
      }
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    },

    _drawTagAnchor: function(ctx, x, y, w, h, l_, r_) {
      var h_ = h / 2, w_ = h / 3,
          // whether the sides should protrude or not; possible values: (-1,0,1)
          l = l_ || 0, r = r_ || 0;
      
      var ml1 = l_ == 0 ? 'moveTo' : 'lineTo';
      var ml2 = r_ == 0 ? 'moveTo' : 'lineTo';
      
      ctx.save();
      ctx.clearRect(x, y, w, h);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx[ml1](x + w_ * l, y + h_);
      ctx[ml1](x, y + h);
      ctx.moveTo(x + w_ * l, y + h_);
      ctx.lineTo(x + w + w_ * r, y + h_);
      ctx[ml2](x + w, y);
      ctx.moveTo(x + w + w_ * r, y + h_);
      ctx[ml2](x + w, y + h);
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    },


    _drawClusterAnchor: function(ctx, x, y, w, h, l_, r_) {
      var h_ = h / 2, w_ = h / 3,
          // whether the sides should protrude or not; possible values: (-1,0,1)
          l = l_ || 0, r = r_ || 0; 
      ctx.save();
      ctx.clearRect(x, y, w, h);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + w, y);
      ctx.lineTo(x + w + w_ * r, y + h_);
      ctx.lineTo(x + w, y + h);
      ctx.lineTo(x, y + h);
      ctx.lineTo(x + w_ * l, y + h_);
      ctx.lineTo(x, y);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

  };
})(jQuery);
