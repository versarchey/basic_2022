(function ($) {
  $.widget("gis.closable", {
    options: {
      text: "Close",
      padding: "0.3em 0.5em 0.3em 0.5em"
    },

    _create: function () {
      var self = this,
          el = self.element,
          opts = self.options;

      var div = $(el).wrap("<div>").addClass("ui-widget ui-widget-content").css({
        padding: opts.padding,
        position: "relative" // need this so that the absolute position below can work
      });

      var but = $('<span class="ui-icon ui-icon-closethick">Remove Tab</span>')
      .css({
        position: 'absolute',
        right: -1,
        top: -1,
        cursor: 'pointer',
        'background-color': 'white',
        'border-top': '1px solid #EB8F00',
        'border-right': '1px solid #EB8F00'
      }).appendTo(div).hide().click(function(ev) { // close
        ev.preventDefault();
        ev.stopPropagation();
        div.fadeOut(500, function () {
          self._trigger("close");
          $(div).remove();
        });
      });

      div.addClass('ui-corner-all').css({ border: 'none' })
      .hover(function () {
        $(this).css({ border: "solid 1px #EB8F00" });
        but.show();
      }, function () {
        $(this).css({ border: "none" });
        but.hide();
      });
    }
  });
})(jQuery);